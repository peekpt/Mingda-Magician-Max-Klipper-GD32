# Support for the ST7796S 480x320 FSMC TFT (Mingda Magician Max mod)
#
# The panel is driven through the `fsmc_tft.c` MCU commands: the host keeps a
# character grid and only sends the cells that changed, so very little traffic
# goes over the serial link.
#
# This file may be distributed under the terms of the GNU GPLv3 license.
import glob
import json
import logging
import os
import re
import socket
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from . import tft_icons
from . import tft_thumb

TextGlyphs = {'right_arrow': b'\x1a', 'degrees': b'\xf8'}

# KlipperScreen theme (values converted to RGB565)
COL_BG     = 0x10C3   # #13181C
COL_ACTIVE = 0x426A   # #404E57
COL_C1     = 0xEB20   # #ED6500  (orange)
COL_C2     = 0xB010   # #B10080  (magenta)
COL_C3     = 0x0490   # #009384  (teal)
COL_C4     = 0xA700   # #A7E100  (lime)
COL_WARN   = 0xFD44   # #f9a825
COL_ERR    = 0x98E3   # #981E1F
COL_WHITE  = 0xFFFF
# Top-bar heater state colours
COL_HEAT   = 0xEB20   # #ED6500  orange  -> heating towards the target
COL_OK     = 0x2DE9   # #2DBF4A  green   -> at/over the target (-3C)
COL_COOL   = 0x061A   # #26C6DA  cyan    -> cooling (target 0)
COL_DIM    = 0x39E7   # #3A3A3A  grey    -> disabled rail icons
COL_DIM2   = 0x8C71   # #8C8C8C  lighter grey -> secondary text
COL_PREVIEW = COL_C3  # #009384  teal (theme accent) -> object preview
# Usual 3D axis colours for the position readout.
COL_AXIS_X = 0xF800   # red
COL_AXIS_Y = 0x2DE9   # green
COL_AXIS_Z = 0x2BDF   # #2979FF blue

# Accent colours for the button underlines: the 4 theme accents plus 4 more, so
# each of the 8 grid buttons gets its own colour.
GUI_COLORS = (COL_C1,   # orange   #ED6500
              COL_C2,   # magenta  #B10080
              COL_C3,   # teal     #009384
              COL_C4,   # lime     #A7E100
              0xFF00,   # yellow   #FFE300
              0xF800,   # red      #FF0000
              0x2BDF,   # blue     #2979FF
              0xDEDC)   # light grey / near white #D8DCE0

# Panels: list of (label, icon, action). action is gcode, or ('scr', name),
# ('mv', axis, sign), or None.
GUI_SCREENS = {
    'main': [
        ("Move", "move", ('scr', 'move')),
        ("Temperature", "heatup", ('scr', 'temperature')),
        ("Extruder", "extrude", ('scr', 'extrude')),
        ("Print", "print", ('scr', 'print')),
        ("Calibrate", "probe", ('scr', 'calibrate')),
        ("More", "settings", ('scr', 'more')),
        ("Motors OFF", "power", 'M84'),
        ("Home", "home", 'G28'),
    ],
    # Tuning menus that used to live in main / Extrude / More.
    'calibrate': [
        ("Auto Level", "bedmesh", ('scr', 'mesh')),
        ("Z-Probe", "zprobe", ('scr', 'probe')),
        ("Limits", "limits", ('scr', 'limits')),
        ("Advanced", "cog", ('scr', 'advanced')),
        ("PID hot", "fire", ('pid', 'extruder')),
        ("PID bed", "bed", ('pid', 'heater_bed')),
        ("Back", "back", ('scr', 'main')),
        None,
    ],
    'move': [
        ("Home All", "home", 'G28'),
        ("Y -", "up", ('mv', 'Y', -1)),
        ("Home XY", "home", 'G28 X Y'),
        ("Z +", "up", ('mv', 'Z', 1)),
        ("X -", "left", ('mv', 'X', -1)),
        ("Y +", "down", ('mv', 'Y', 1)),
        ("X +", "right", ('mv', 'X', 1)),
        ("Z -", "down", ('mv', 'Z', -1)),
    ],
    'temperature': [
        ("PLA", "heatup", 'PREHEAT_PLA'),
        ("PETG", "heatup", 'PREHEAT_PETG'),
        ("ABS", "heatup", 'PREHEAT_ABS'),
        ("TPU", "heatup", 'PREHEAT_TPU'),
        ("Cool", "cool", 'M104 S0\nM140 S0'),
        ("Nozzle 200", "fire", 'M104 S200'),
        ("Bed 60", "bed", 'M140 S60'),
        ("Back", "back", ('scr', 'main')),
    ],
    'extrude': [
        ("Load", "load", 'LOAD_FILAMENT'),
        ("Unload", "unload", 'UNLOAD_FILAMENT'),
        ("E +", "edown", ('ex', 1)),
        ("E -", "eup", ('ex', -1)),
        ("Nozzle 200", "fire", 'M104 S200'),
        ("Nozzle 240", "fire", 'M104 S240'),
        ("E 1mm", "extrude", ('ext',)),
    ],
    # 'probe' (Z-Probe) is drawn by _probe_view_ops: see Z_STEPS below.
    'probe': [],
    # 'touch calibration' wizard draws its own overlay.
    'tcal': [],
    # 'macros' is filled from panel_macros.json at runtime.
    'macros': [],
    # 'print' is built dynamically from the virtual SD files (see _print_items)
    'print': [],
    'filament': [
        ("Unload", "unload", ('fil', 'unload')),
        ("Baby", "zoffset", ('baby', 0)),
        ("0.01", "cog", ('bstep',)),
        ("Save", "save", ('bsave',)),
        ("Load", "load", ('fil', 'load')),
        ("Z +", "up", ('baby', 1)),
        ("Z -", "down", ('baby', -1)),
        ("", "", None),
    ],
    'ptune': [],
    'estop': [],
    'power': [
        ("Emergency", "alert", 'M112'),
        ("Klipper", "refresh", 'RESTART'),
        ("Firmware", "console", 'FIRMWARE_RESTART'),
        ("Reboot", "power", ('host', 'reboot')),
        ("Shutdown", "power", ('host', 'shutdown')),
        ("Back", "back", ('scr', 'main')),
    ],
    'network': [],
    'more': [
        ("Save", "save", 'SAVE_CONFIG'),
        ("Filam", "filok", ('fsens',)),
        ("Network", "network", ('scr', 'network')),
        ("Beep", "beep", ('beep',)),
        ("Info", "info", ('scr', 'info')),
        ("Telegram", "tg", ('tgtest',)),
        ("Macros", "script", ('scr', 'macros')),
        ("Touch", "settings", ('scr', 'tcal')),
    ],
}

# Bottom strip: buttons per panel. Value is the step (mm) for step panels, or a
# gcode string for panels with actions.
GUI_STRIP = {
    'move': [('0.1', 0.1), ('0.5', 0.5), ('1', 1.0), ('5', 5.0),
             ('10', 10.0), ('25', 25.0), ('50', 50.0)],
}

# Screens whose button grid is not the default 4 columns x 2 rows
GUI_ROWS = {'print': 2}
GUI_COLS = {}

# Z-Probe: TESTZ steps, cycled by the step toggle button (mm).
Z_STEPS = (0.005, 0.01, 0.1, 1.0)

# Advanced (extruder) and machine limit screens: POPUP_ITEMS keys per card.
ADV_KEYS = ('pa', 'smooth', 'shx', 'shy')
LIM_KEYS = ('vel', 'accel', 'scv', 'cruise')

# kind -> (printer status key, SET_VELOCITY_LIMIT argument)
_LIM_MAP = {'vel': ('max_velocity', 'VELOCITY'),
            'accel': ('max_accel', 'ACCEL'),
            'scv': ('square_corner_velocity', 'SQUARE_CORNER_VELOCITY'),
            'cruise': ('minimum_cruise_ratio', 'MINIMUM_CRUISE_RATIO')}

# key -> (config section, option, format) for the GRAVAR button
_SAVE_MAP = {'pa': ('extruder', 'pressure_advance', '%.4f'),
             'smooth': ('extruder', 'pressure_advance_smooth_time', '%.4f'),
             'vel': ('printer', 'max_velocity', '%.1f'),
             'accel': ('printer', 'max_accel', '%.1f'),
             'scv': ('printer', 'square_corner_velocity', '%.2f'),
             'cruise': ('printer', 'minimum_cruise_ratio', '%.3f')}

# Generic adjustment popups (one implementation for every info icon).
#   kind: 'temp' reads <src>.target, 'factor' reads gcode_move.<key>,
#         'fan' reads fan.speed, 'baby' is the live Z offset.
POPUP_ITEMS = {
    'etemp': dict(icon='fire', name='Nozzle', units='C', kind='temp',
                  src='extruder', steps=(1., 5., 10.), default=5.,
                  lo=0., hi=270.),
    'btemp': dict(icon='bed', name='Bed', units='C', kind='temp',
                  src='heater_bed', steps=(1., 5., 10.), default=5.,
                  lo=0., hi=120.),
    'fan': dict(icon='fan', name='Fan', units='%', kind='fan',
                steps=(10., 25., 50.), default=25., lo=0., hi=100.),
    'flow': dict(icon='extrude', name='Flow', units='%', kind='factor',
                 key='extrude_factor', steps=(1., 5.), default=1.,
                 lo=50., hi=200.),
    'speed': dict(icon='speed', name='Speed', units='%', kind='factor',
                  key='speed_factor', steps=(5., 10.), default=5.,
                  lo=25., hi=200.),
    'baby': dict(icon='zoffset', name='Baby', units='mm', kind='baby',
                 steps=(0.005, 0.01, 0.1, 0.5), default=0.01,
                 lo=-5., hi=5., live=True, save=True),
    # --- Avancadas (extrusor + input shaper) ---
    'pa': dict(icon='speed', name='Pressure Advance', units='', kind='pa',
               steps=(0.002, 0.005, 0.01, 0.02, 0.05), default=0.005,
               lo=0., hi=1.5, live=True, dec=3),
    'smooth': dict(icon='clock20', name='Smooth Time', units='s',
                   kind='smooth', steps=(0.005, 0.01, 0.02), default=0.01,
                   lo=0.005, hi=0.2, live=True, dec=3),
    'shx': dict(icon='refresh', name='Shaper X', units='Hz', kind='shx',
                steps=(1., 2., 5.), default=1., lo=0., hi=200., live=True,
                dec=1),
    'shy': dict(icon='refresh', name='Shaper Y', units='Hz', kind='shy',
                steps=(1., 2., 5.), default=1., lo=0., hi=200., live=True,
                dec=1),
    # --- Limites da maquina ---
    'vel': dict(icon='speed', name='Velocity', units='mm/s', kind='vel',
                steps=(10., 25., 50., 100.), default=10., lo=10., hi=1000.,
                live=True, dec=0),
    'accel': dict(icon='move', name='Accel', units='mm/s2',
                  kind='accel', steps=(100., 500., 1000., 5000.),
                  default=500., lo=100., hi=50000., live=True, dec=0),
    'scv': dict(icon='limits', name='Sq Corner', units='mm/s',
                kind='scv', steps=(0.5, 1., 5.), default=1., lo=0.1, hi=50.,
                live=True, dec=1),
    'cruise': dict(icon='fan', name='Min Cruise', units='',
                   kind='cruise', steps=(0.02, 0.05, 0.1), default=0.05,
                   lo=0., hi=0.95, live=True, dec=2),
}

# Friendly titles for the top bar (otherwise the screen id is shown)
GUI_TITLES = {'ptune': 'Tune', 'filament': 'Filament',
              'estop': 'Confirm', 'mesh': 'Auto Bed Level', 'probe': 'Z-Probe',
              'meshadj': 'Adjust', 'advanced': 'Advanced',
              'limits': 'Limits', 'calibrate': 'Calibrate', 'pid': 'PID',
              'info': 'Info', 'filout': 'Filament',
              'wifilist': 'WiFi', 'wifikey': 'WiFi',
              'tcal': 'Touch', 'macros': 'Macros'}

# Sentinel stored in the grid for a cell holding an icon (drawn by write_glyph).
ICON = 0x100


def _mk_bmp(n, fn):
    # n x n 1-bit bitmap (MSB first, row-major) from a predicate fn(i, j, n).
    rb = (n + 7) // 8
    out = bytearray()
    for j in range(n):
        bits = 0
        for i in range(n):
            bits = (bits << 1) | (1 if fn(i, j, n) else 0)
        bits <<= (rb * 8 - n)
        for k in range(rb):
            out.append((bits >> ((rb - 1 - k) * 8)) & 0xFF)
    return (n, n, bytes(out))


def _pause_fn(i, j, n):
    if not (0.18 * n <= j < 0.82 * n):
        return False
    return (0.30 * n <= i < 0.42 * n) or (0.58 * n <= i < 0.70 * n)


def _play_fn(i, j, n):
    h = abs(j - 0.5 * n)
    if h >= 0.32 * n:
        return False
    return 0.26 * n <= i < 0.30 * n + 0.44 * n * (1.0 - h / (0.32 * n))


def _x_fn(i, j, n):
    if not (0.16 * n <= i < 0.84 * n and 0.16 * n <= j < 0.84 * n):
        return False
    return abs(i - j) <= 0.08 * n or abs(i - (n - 1 - j)) <= 0.08 * n


def _dot_fn(i, j, n):
    c = (n - 1) / 2.0
    dx, dy = i - c, j - c
    return dx * dx + dy * dy <= (c + 0.35) ** 2


def _ring_fn(i, j, n):
    c = (n - 1) / 2.0
    dx, dy = i - c, j - c
    r2 = dx * dx + dy * dy
    return (c - 1.7) ** 2 <= r2 <= (c + 0.35) ** 2


def _bedslinger_fn(i, j, n):
    # Cartesian bed slinger seen from the front: a gantry with the tool head
    # and the bed plate sticking out of the frame below it (the bed is the
    # part that moves in Y - a CoreXY icon looks like a closed cube).
    u = i / (n - 1.0)
    v = j / (n - 1.0)
    # top gantry beam
    if 0.03 <= v <= 0.13 and 0.02 <= u <= 0.98:
        return True
    # uprights
    if 0.13 <= v <= 0.60 and (0.02 <= u <= 0.11 or 0.89 <= u <= 0.98):
        return True
    # tool head hanging from the gantry
    if 0.13 <= v <= 0.30 and 0.40 <= u <= 0.60:
        return True
    # nozzle tip (the gap under it is what makes it read as a printer)
    if 0.30 <= v <= 0.42 and 0.46 <= u <= 0.54:
        return True
    # moving bed plate - wider than the frame
    if 0.60 <= v <= 0.69 and 0.00 <= u <= 1.00:
        return True
    # bed carriage
    if 0.69 <= v <= 0.77 and 0.28 <= u <= 0.72:
        return True
    # base / bed rails
    if 0.77 <= v <= 0.84 and 0.10 <= u <= 0.90:
        return True
    return False


def _hourglass_fn(i, j, n):
    # Simple hourglass: solid shape that narrows towards the middle.
    m = 0.12 * n
    if not (m <= i < n - m):
        return False
    if j < 0.13 * n or j >= 0.87 * n:
        return True
    c = 0.5 * n
    d = abs(j - c) / (0.37 * n)
    hw = (n * 0.44) * d + 1.0
    return abs(i - c) <= hw


# Icons we generate locally (not part of the MDI set).
EXTRA_ICONS = {
    # Our printer is a bed slinger, not a CoreXY cube: replace the MDI
    # 'print' icon everywhere it is used (menus + boot splash).
    # Printer icon: the SVG supplied by the user (2041x2048), cropped,
    # 60 px box-filtered into 64x64 and packed 1 bit/pixel.
    'print': (64, 64, bytes.fromhex(
        '0000000000000000000000000000000001e000000000078003f0000000000fc0'
        '03f1000ff0008fc003f3800ff001cfc003f3800ff001cfc003ffff0ff0ffeff0'
        '3fffff8ff1fffffc3fffff8ff1fffffc1fffff8ff1fffff803f3800ff001cfc0'
        '03f3800ff001cfc003f3000ff000cfc003f0000ff0000fc003f00003e0000fc0'
        '03f0000180000fc003f0000180000fc003f0000180000fc003f0000180000fc0'
        '03f0000000000fc003f0000000000fc003f0000000000fc003f0000180000fc0'
        '03f00003c0000fc003f00003c0000fc003f00003c0000fc003f0000780000fc0'
        '03f001ff80000fc003f003ff00000fc003f007fe00000fc003f0078000000fc0'
        '03f0070000000fc003f0070000000fc003f0078000000fc003f007ffffe00fc0'
        '03f003fffff00fc003f000fffff80fc003f0000000780fc003f0000000380fc0'
        '03f00000003c0fc003f01ffffffc0fc003f03ffffffc0fc003f03ffffffc0fc0'
        '03f03ffffffc0fc003f03ffffffc0fc003f03ffffffc0fc003f03ffffffc0fc0'
        '03f03ffffffc0fc003f01ffffffc0fc003f01ffffff80fc003f0000000000fc0'
        '03f0000000000fc003f0000000000fc01ffffffffffffff83ffffffffffffffc'
        '3ffffffffffffffc3ffffffffffffffc3ffffffffffffffc1ffffffffffffff8'
        '00fe000000007f00007e000000007e0000000000000000000000000000000000'
    )),
    # Mingda brand mark (the user's logo), Floyd-Steinberg dithered at
    # 108 px so the folded faces still read in the boot splash.
    'mingda': (108, 108, bytes.fromhex(
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000002000000000000000000000000000b00000000000000000000000000'
        '15a000000000000000000000000056d000000000000000000000000153680000'
        '00000000000000000002aadc00000000000000000000000a576b800000000000'
        '00000000002aa9bec0000000000000000000005556d560000000000000000000'
        '01529377b8000000000000000000029555ad6c0000000000000000000a5556f7'
        'b70000000000000000002aaaab5adbc000000000000000002aa925b76d600000'
        '000000000001555555dadbb80000001040000002a94aaab76d6e000000506000'
        '0001552aabddb7b0000000b02c0000004aaa556b6d6800000360aa0000002955'
        '4bbdbb80000005b0528000001552aad6d68000001ed05540000002aaab6dba00'
        '00006b6055500000015555b6d4000001bdb04aac0000004a4adbb0000002d6e0'
        '54a50000002aab6d4000000b6b5055548000001555b780000016dde052aaa000'
        '0002ab6c0000006db6b04a955000000155d8000001b76dd05555280000004b60'
        '000002daf7605552aa0000002a9000000d6f5ab0552aa58000000b40000037b5'
        'efd054aa95500000040000005adeb5604aaa6aa0000000000001ef6b5b705555'
        '555a000000000006b5bdeda0554a94a400000000000bbad6b6e052a952958000'
        '0000003d6f75db504a5555556000000000d7b5aeb7e05555555528000000017a'
        'db77dd50554a95555400000007ad6dbab6e05554aaa9550000000ad7b6d6db50'
        '52aaa925554000003d7adb7b6de04a5555554aa00000d7af6ed6db50554aa555'
        '295400016af5bb6db6e055549555555200075f5ad6db6db055555529552a801a'
        'f5af7b6dded052aaaaa55555202f5af5adb6b5b04a52d5554aaaa0f5ef5eeedb'
        'db60554ab4aaa9555baeb5b5b52d6ed055556d555524a575db6edaabb5b05555'
        '76aa555556deadb5aaad6ee052aaada54aaa936b76ded557bb504a55776aaaaa'
        'abb5dbb5555ad6e055495ada5494aadeb6ed552dbbb05555ef6d52aaab6bddb5'
        '54ab6d605554b5b7555555bd6b5552aedbb052aadb6daaa92ad6ddd54d55b6d0'
        '4a556dbad55555bb6b5532aeedb0554ab6ef75254b6dbd54caab5b6055556db5'
        'ad5555d6d52aaa9deed05552db5b76aaab7b6aa52a56b5b052aab6edadaa55ad'
        'aaaaa95bdee04a556db6f6e956db55555556b5b0554adb6f5b56ab6d54aaaaad'
        'db6055556edaedfaa5b552949556b6d0555575b75b57556aaaaaa95bdbb052aa'
        'aeedeeddabaaaaaaa52d6ed04a52db5b5b6aeaaa55525556b560554ab6f6edbf'
        '5aa54aaaaaabdfb055556dadb6d5b4955495555d6ad055557776db7ae0555555'
        '54abbb6054aaadaf6daf402aaaa92a96d6d04aa576f5b6f50004955552adbb70'
        '55555b5d6dac0002a9254aaedda0552aedd7bb70000155555555b6f052a95b7a'
        'd6c000002aaaaaaedb504aa6eeadbb40000012a9552b6dd055555bd6ed000000'
        '0a552aaddb60552ab57b5a000000014aa4aeb6b054a96f57b000000000aaaaab'
        'ddd05555bafac00000000055555d6b604aaad75700000000000a554bbdb05555'
        '7aec8000000000054a5d6b601549575a0000000000015556dd800a556de80000'
        '00000000aaabb68002aadb50000000000000295d6a0001556d00000000000000'
        '0aa7b400002ab600000000000000055ad00000156a0000000000000002968000'
        '0002d000000000000000005b00000002a000000000000000002c000000008000'
        '0000000000000010000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000'
    )),
    # Z-Probe: proximity sensor icon supplied by the user (cap + lens +
    # three sonar arcs), 60 px box-filtered into 64x64, 1 bit/pixel.
    'zprobe': (64, 64, bytes.fromhex(
        '00000000000000000000000000000000000fffffffffe000003ffffffffff800'
        '00fffffffffffe0001ffffffffffff0001ffffffffffff0003ffffffffffff80'
        '07ffffffffffffc007ffffffffffffc007ffffffffffffc00fffffffffffffe0'
        '0fffffffffffffe00ffffff01fffffe00fffff0001ffffe00ffffc00007fffe0'
        '0ffff800003fffe00fffe003800fffe00fffc03ff807ffe007ffc0fffe07ffc0'
        '07ff81ffff03ffc00fff03ffff81ffe00ffe07ffffc0ffe00ffe0fffffe0ffe0'
        '0ffc1ffffff07fe00ffc1ffffff07fe00ffc3ffffff87fe00ff83ffffff83fe0'
        '00003ffffff8000000003ffffff8000000003ffffff8000000003ffffff80000'
        '00003ffffff8000000003ffffff8000000003ffffff8000000003ffffff80000'
        '00001ffffff0000000001ffffff0000000000fffffe0000000018fffffe30000'
        '000387ffffc380000021c3ffff8708000070e1ffff0e1c000038f07ffc1e3800'
        '0e38781ff03c38e00e1c3c00007870e0070e1f0001f0e1c0070f07c007c1e1c0'
        '038783ffff83c38001c3c0fffe07870000e1e00fe00f0e0000f07800003c1e00'
        '00783e0000f83c00003c0fc007e07800001e03ffff80f0000007807ffc03c000'
        '0003e000000f80000001f800003f000000007f0001fc000000001ff01ff00000'
        '000003ffff8000000000003ff800000000000000000000000000000000000000'
    )),
    # Telegram: paper plane.
    'tg': (64, 64, bytes.fromhex(
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000020000000000000003c00000000000000'
        '3f000000000000003fc00000000000003ff00000000000003ffe000000000000'
        '3fff8000000000003fffe000000000003ffff800000000003ffffe0000000000'
        '3fffffc0000000003ffffff0000000003ffffffc000000003fffffff80000000'
        '3fffffffe00000003ffffffff80000003ffffffffe0000003fffffffffc00000'
        '3ffffffffff000003ffffffffffc000003ffffffffff00000007ffffffffc000'
        '00001ffffffff8000000007ffffffe0000000000ffffff800000000003fffff0'
        '00000000000ffff80000000001fffff000000001ffffffc0000001fffffffe00'
        '0000fffffffff800007fffffffffc0003fffffffffff00003ffffffffff80000'
        '3fffffffffe000003fffffffff0000003ffffffffc0000003fffffffe0000000'
        '3fffffff800000003ffffffc000000003ffffff0000000003fffff8000000000'
        '3ffffe00000000003ffff000000000003fffc000000000003fff000000000000'
        '3ff80000000000003fe00000000000003f000000000000003c00000000000000'
        '2000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
    )),
    # Beep: speaker with sound waves.
    'beep': (64, 64, bytes.fromhex(
        '0000000000000000000000000000000000000000000000000000000000000000'
        '0000000000000000000000020000000000000006000000000000000e00000000'
        '0000001e000030000000001e000078000000003e00003c000000007e00001e00'
        '000000fe00000f00000001fe00000f00000003fe00000780000007fe000803c0'
        '00000ffe001c01c000001ffe001e01e000003ffe000f00e000007ffe000780f0'
        '0000fffe0003c0700001fffe0003c0700001fffe0201e0783ffffffe0700e038'
        '3ffffffe0780e0383ffffffe0780f03c3ffffffe03c0701c3ffffffe01c0701c'
        '3ffffffe01e0701c3ffffffe00e0701c3ffffffe00e0701c3ffffffe00e0701c'
        '3ffffffe00e0701c3ffffffe00e0701c3ffffffe01e0701c3ffffffe01c0701c'
        '3ffffffe03c0701c3ffffffe0780f03c3ffffffe0780e0383ffffffe0700e038'
        '0001fffe0201e0780001fffe0003c0700000fffe0003c07000007ffe000780f0'
        '00003ffe000f00e000001ffe001e01e000000ffe001c01c0000007fe000803c0'
        '000003fe00000780000001fe00000f00000000fe00000f000000007e00001e00'
        '0000003e00003c000000001e000078000000001e000030000000000e00000000'
        '0000000600000000000000020000000000000000000000000000000000000000'
        '0000000000000000000000000000000000000000000000000000000000000000'
    )),
    # Filament present: spool (user's SVG).
    'filok': (64, 64, bytes.fromhex(
        '00000000000000000000000000000000003c000000007800007e00000000fc00'
        '00ff00000001fe0000ff00000001fe0000ff00000001fe0000ff00000001fe00'
        '00ff3c387871fe0000ff7e7cfcf9fe0000ff7efefcfdfe0000ff7efefdfdfe00'
        '00ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe00'
        '00ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe00'
        '00ff7efefdfdfe0000ff7efefdfdfe00007f7efefdfdfc00007f7efefdfdfc00'
        '007f7efefdfdfc00003f7efefdfdf800003f7efefdfdf800003f7efefdfdf800'
        '003f7efefdfdf800003f7efefdfdf800003f7efefdfdf800007f7efefdfdfc00'
        '007f7efefdfdfc00007f7efefdfdfc0000ff7efefdfdfe0000ff7efefdfdfe00'
        '00ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe00'
        '00ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe0000ff7efefdfdfe00'
        '00ff7efefdfdfe0000ff7efefdfdfe0000ff3e7c7dfdfe0000ff1c3839fdfe00'
        '00ff000001fdfe0000ff000001fdfe0000ff000001fdfe0000ff000001fdfe00'
        '007e000001fcfc00003c000001fc78000000000001fc00000000000001fc0000'
        '0000000001fc00000000000001fc00000000000001fc00000000000000fc0000'
        '0000000000f80000000000000070000000000000000000000000000000000000'
    )),
    # Filament runout: broken line with a cross (user's SVG).
    'filnout': (64, 64, bytes.fromhex(
        '0000000000000000000000000000000000000007c000000000000007c0000000'
        '00000007c000000000000007c000000000000007c000000000000007c0000000'
        '00000007c000000000000007c000000000000007c000000000000007c0000000'
        '00000007c000000000000007c000000000000007c000000000000007c0000000'
        '00000007c000000000000007c000000000000007c000000000000007c0000000'
        '00000007c000000000000007c000000000000007c000000000000007c0000000'
        '00000007c00000000000010001000000000003c007800000000007e00fc00000'
        '000007f01fc00000000003f83f800000000001fc7f000000000000fefe000000'
        '0000007ffc0000000000003ff80000000000001ff00000000000000fe0000000'
        '0000001ff00000000000003ff80000000000007ffc000000000000fefe000000'
        '000001fc7f000000000003f83f800000000007f01fc00000000007e00fc00000'
        '000003c007800000000001000100000000000007c000000000000007c0000000'
        '0000000000000000000000000000000000000007c00000000000000000000000'
        '0000000000000000000000070000000000000000000000000000000000000000'
        '000000000000000000000007c000000000000000000000000000003ff8000000'
        '0000003ff80000000000003ff800000000000000000000000000000000000000'
    )),
    'pause48': _mk_bmp(48, _pause_fn),
    'play48': _mk_bmp(48, _play_fn),
    'x48': _mk_bmp(48, _x_fn),
    'hourglass20': _mk_bmp(20, _hourglass_fn),
    'dot10': _mk_bmp(10, _dot_fn),
    'dot12': _mk_bmp(12, _dot_fn),
    'dot22': _mk_bmp(22, _dot_fn),
    'dot16': _mk_bmp(16, _dot_fn),
    'ring16': _mk_bmp(16, _ring_fn),
    'dot18': _mk_bmp(18, _dot_fn),
    'dot30': _mk_bmp(30, _dot_fn),
}


def _make_corner(r, fx, fy):
    # r x r quarter-disk bitmap (1 = inside), MSB-first, row-major.
    rowbytes = (r + 7) // 8
    data = bytearray()
    for j in range(r):
        val = 0
        for i in range(r):
            ii = (r - 1 - i) if fx else i
            jj = (r - 1 - j) if fy else j
            dx = ii - (r - 0.5)
            dy = jj - (r - 0.5)
            val = (val << 1) | (1 if dx * dx + dy * dy <= (r - 0.5) ** 2 else 0)
        val <<= (rowbytes * 8 - r)
        for k in range(rowbytes):
            data.append((val >> ((rowbytes - 1 - k) * 8)) & 0xFF)
    return (r, r, bytes(data))

# ST7796S init sequence (register, [data...]) - from Marlin st7796s.h
INIT_SEQ = [
    (0xF0, [0xC3]), (0xF0, [0x96]),
    (0x3A, [0x55]),
    (0xB4, [0x01]),
    (0xB7, [0xC6]),
    (0xC1, [0x15]),
    (0xC2, [0xAF]),
    (0xC5, [0x22]),
    (0xC6, [0x00]),
    (0xE8, [0x40, 0x8A, 0x00, 0x00, 0x29, 0x19, 0xA5, 0x33]),
    (0xE0, [0xF0, 0x04, 0x08, 0x09, 0x08, 0x15, 0x2F, 0x42,
            0x46, 0x28, 0x15, 0x16, 0x29, 0x2D]),
    (0xE1, [0xF0, 0x04, 0x09, 0x09, 0x08, 0x15, 0x2E, 0x46,
            0x46, 0x28, 0x15, 0x15, 0x29, 0x2D]),
    (0x13, []),
    (0x53, [0x24]),
    (0xF0, [0x3C]), (0xF0, [0x69]),
    (0x29, []),
]


class ST7796:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.mcu = self.printer.lookup_object('mcu')
        gcode = self.printer.lookup_object('gcode')
        gcode.register_command('TFT_FILL', self.cmd_TFT_FILL,
                               desc="Fill the TFT with a solid R,G,B colour")
        gcode.register_command('TFT_TEST', self.cmd_TFT_TEST,
                               desc="Draw a TFT diagnostic pattern")
        gcode.register_command('TFT_LIMITS', self.cmd_TFT_LIMITS,
                               desc="Draw edge/padding test frames")
        gcode.register_command('TFT_LINES', self.cmd_TFT_LINES,
                               desc="Draw alternating vertical b/w stripes")
        gcode.register_command('TFT_FILLV', self.cmd_TFT_FILLV,
                               desc="Fill the TFT with a colour as vertical strips")
        gcode.register_command('TFT_TOUCH', self.cmd_TFT_TOUCH,
                               desc="Read the XPT2046 touch raw values")
        gcode.register_command('TFT_TOUCH_DEBUG', self.cmd_TFT_TOUCH_DEBUG,
                               desc="Toggle logging of touch raw values")
        gcode.register_command('TFT_PANEL', self.cmd_TFT_PANEL,
                               desc="Write ST7796 registers live (DIC/VCOM/INVON)")
        gcode.register_command('TFT_SPLIT', self.cmd_TFT_SPLIT,
                               desc="Compare big-rect vs narrow-strip fills")
        gcode.register_command('TFT_GUI', self.cmd_TFT_GUI,
                               desc="Force a full GUI redraw")
        gcode.register_command('TFT_NET', self.cmd_TFT_NET,
                               desc="Show network info / send SSDP announce")
        # Wrap BED_MESH_CALIBRATE / G29 so the display can show the probing map.
        self._mesh_base = None
        self._g29_base = None
        self._mesh_hooked = False
        self._mesh_arm = 0.
        self._mesh_run = 0
        self._mesh_t = 0.
        self._mesh_lmk = 0x7FFFFFFF     # state currently drawn on the panel
        self._mesh_ldone = 0x7FFFFFFF
        self._mesh_ltv = None
        self._mesh_lbr = None
        # ETA (time to finish) smoothing
        self._eta_hist = []
        # Object preview (slicer thumbnail)
        self._prev_bits = None
        self._prev_key = 0
        self._prev_file = None
        self._prev_until = 0.
        self._prev_toggle = False
        self._prev_pending = False
        # Auto recovery after the board reboots (SD firmware update)
        self._mcu_file = os.path.expanduser(
            '~/printer_data/config/.mcu_recover')
        self._mcu_fix_at = 0.
        # Manual mesh point adjustment
        self._adj_orig = []
        self._adj_cur = []
        self._adj_i = 0
        self._adj_j = 0
        self._adj_delta = 0.
        self._adj_at = False
        self._adj_step_i = 1
        self._adj_lstate = None
        self._adj_lval = None
        self._adj_lpt = None
        self._adj_lstep = None
        self._adj_lsave = None
        self._mesh_hook()
        # Touch (XPT2046)
        self.gcode = gcode
        self.touch_enable = config.getboolean('touch', True)
        self.touch_threshold = config.getint('touch_threshold', 200, minval=0)
        self.touch_swap = config.getboolean('touch_swap_xy', False)
        self.touch_inv_x = config.getboolean('touch_invert_x', False)
        self.touch_inv_y = config.getboolean('touch_invert_y', False)
        self.touch_swipe = config.getint('touch_swipe_min', 50, minval=1)
        self.touch_long = config.getfloat('touch_long_ms', 700., above=0.) / 1000.
        self.touch_short_tap = config.getboolean('touch_short_tap', False)
        # KlipperScreen-like GUI mode
        self.gui = config.getboolean('gui', False)
        self.gui_bg = int(config.get('gui_bg', '0x1082'), 0) & 0xFFFF
        self.gui_bar_bg = int(config.get('gui_bar_bg', '0x2124'), 0) & 0xFFFF
        self.gui_btn_bg = int(config.get('gui_btn_bg', '0x3186'), 0) & 0xFFFF
        self.gui_accent = int(config.get('gui_accent', '0x07FF'), 0) & 0xFFFF
        self.gui_label = int(config.get('gui_label', '0xFFFF'), 0) & 0xFFFF
        self.gui_icon = int(config.get('gui_icon', '0xFFFF'), 0) & 0xFFFF
        self.raw_x_min = config.getint('raw_x_min', 200)
        self.raw_x_max = config.getint('raw_x_max', 1900)
        self.raw_y_min = config.getint('raw_y_min', 200)
        self.raw_y_max = config.getint('raw_y_max', 1900)
        self.gui_status_fg = int(config.get('gui_status_fg', '0xFFFF'), 0) & 0xFFFF
        self.gui_radius = config.getint('gui_radius', 8, minval=0, maxval=16)
        # Button icons are drawn from the 64px bitmaps; scale them down for a
        # lighter look (and much less serial traffic).
        self.gui_icon_scale = config.getfloat('gui_icon_scale', 0.4,
                                             minval=0.15, maxval=1.0)
        self.gui_btn_gap = config.getint('gui_btn_gap', 8, minval=0, maxval=40)
        self._icon_cache = {}
        # Temperature history for the printing screen graph (sampled in the bars)
        self._t_hist = []
        self._t_last = 0.
        self._last_ps_state = 'ready'
        self._zmax_v = 0.
        self._net_cache = None
        self._net_t = 0.
        self._ui_live_t = 0.
        self._gui_beat = 0.
        self._gui_err = None
        self._gui_err_until = 0.
        self._ic_ids = {}
        self._ic_bytes = 0
        # Only cache icons up to this many bytes (the first firmware build
        # truncated the length to 8 bits, so >255 byte icons were not drawn).
        self._ic_max = config.getint('icon_cache_max', 250, minval=0)
        self._touch_evt = False
        self.cmd_idef = self.cmd_idraw = self.cmd_str = self.cmd_tcfg = None
        gcode.register_output_handler(self._gui_output)
        self._ptune = 'flow'
        self._card_cols = {}
        self._fil_unloaded = False
        self._BSTEPS = (0.005, 0.01, 0.1, 0.5)
        self._zstep_i = 1
        self._pid_heater = None
        self._pid_samples = []
        self._pid_t0 = 0.
        self._pid_last = 0.
        self._pid_active = False
        self._pid_done = False
        self._fil_lost = False
        self._notice = None
        self._notice_icon = 'filnout'
        self._ps_prev = None
        # WiFi setup / on-screen keyboard
        self._wifi_nets = []
        self._wifi_page = 0
        self._wifi_busy = False
        self._wifi_out = None
        self._kb_text = ''
        self._kb_title = ''
        self._kb_mode = 'text'
        self._kb_back = 'network'
        self._kb_ssid = ''
        self._kb_shift = False
        self._kb_sym = False
        self._kb_show = False
        self._err_shown = None
        self._upd_n = 0
        self._upd_next = 0.
        self._upd_busy = False
        self._choice = None
        self._macros_cache = (0., [])
        self._tcal = None
        self._bstep_i = 1
        self._baby_dirty = False
        self._popup = None
        self._popup_val = None
        self._popup_step = 1.
        self._popup_save = False
        self._popup_applied = 0.
        self._baby_base = 0.
        # Baby step persisted outside printer.cfg: saved to a small file and
        # re-applied at the start of every print (no SAVE_CONFIG restart).
        self._baby_saved = 0.
        self._baby_file = os.path.expanduser(
            '~/printer_data/config/baby_z.txt')
        # Bed mesh probing map
        self._mesh_active = False
        self._mesh_done = -1
        self._mesh_prev = None
        self._mesh_prev_screen = 'print'
        try:
            old = gcode.ready_gcode_handlers  # noqa
        except Exception:
            old = None
        self._corners = (_make_corner(self.gui_radius, False, False),
                         _make_corner(self.gui_radius, True, False),
                         _make_corner(self.gui_radius, False, True),
                         _make_corner(self.gui_radius, True, True))
        self.gui_screen = 'main'
        self._gui_steps = (0.1, 0.5, 1.0, 5.0, 10.0, 25.0, 50.0)
        self._gui_step = 1.0
        self._ext_steps = (1.0, 5.0, 10.0)
        self._ext_step = 1.0
        self.gui_beep = config.getboolean('gui_beep', True)
        # Refuse filament moves below this nozzle temperature (0 disables).
        self.extrude_min_temp = config.getfloat('extrude_min_temp', 180.,
                                                minval=0.)
        self.filament_sensor = config.get('filament_sensor', 'filament_sensor')
        # Optional version stamp drawn in the top bar (debug aid)
        self.gui_version = config.get('gui_version', '').strip()
        self._gui_msg = None
        self._gui_msg_until = 0.
        self._gui_action_active = False
        self._gui_ops = None
        self.cmd_bmp = None
        self.cmd_rrect = None
        self._gui_next = 0.
        self._gui_pending = None
        self._gui_last = None
        self.query_touch = None
        self.menu = None
        self.touch_debug = False
        self._mon = None
        gcode.register_command('TFT_TOUCH_MON', self.cmd_TFT_TOUCH_MON,
                               desc="Sample touch raw values for T seconds")
        self._touched = False
        self._t0 = 0.
        self._x0 = self._y0 = self._xl = self._yl = 0
        self.touch_timer = self.printer.get_reactor().register_timer(
            self._touch_event)
        self.cols = config.getint('cols', 20, minval=4, maxval=60)
        self.rows = config.getint('rows', 4, minval=1, maxval=20)
        self.scale = config.getint('scale', 3, minval=1, maxval=8)
        self.fg = int(config.get('fg_color', '0xFFFF'), 0) & 0xFFFF
        self.bg = int(config.get('bg_color', '0x0000'), 0) & 0xFFFF
        self.icon_color = int(config.get('icon_color', '0x07FF'), 0) & 0xFFFF
        self.bar_color = int(config.get('bar_color', '0x07E0'), 0) & 0xFFFF
        self.bar_bg = int(config.get('bar_bg', '0x0000'), 0) & 0xFFFF
        rc = config.get('row_colors', '').strip()
        self.row_colors = ([int(v, 0) & 0xFFFF for v in rc.split(',')
                            if v.strip()] if rc else None)
        # MADCTL: MV(0x20)|RGB. Try 0xA0 / 0x68 / 0x28 if colours/orientation
        # look wrong.
        self.madctl = int(config.get('madctl', '0x28'), 0) & 0xFF
        # Panel tuning (sent by the host, so no reflash needed to experiment)
        self.init_invert = config.getboolean('init_invert', False)
        self.init_dic = int(config.get('init_dic', '0x00'), 0) & 0xFF
        self.init_vcom = int(config.get('init_vcom', '0x22'), 0) & 0xFF
        self.init_vcomofs = int(config.get('init_vcomofs', '0x00'), 0) & 0xFF
        self.init_gamma = config.getboolean('init_gamma', True)
        # The MCU initialises the panel itself at power-on, so the host can
        # skip its software reset (it would wipe the boot splash).
        self.init_reset = config.getboolean('init_reset', True)
        # Boot splash drawn by the MCU (keep it on screen while Klipper boots).
        self.splash = config.getboolean('splash', True)
        self.splash_time = config.getfloat('splash_time', 0.9, minval=0.0)
        self.cmd_splash = None
        self.width = config.getint('width', 480, minval=1)
        self.height = config.getint('height', 320, minval=1)
        # Command lookups happen in init(): the MCU command dictionary is only
        # available after the klippy:connect stage.
        self.cmd_cmd = self.cmd_data = self.cmd_rect = self.cmd_char = None
        self.cmd_icon = None
        self.enabled = False
        self.cell_w = self.width // self.cols
        self.cell_h = self.height // self.rows
        self.vpad = max(0, (self.cell_h - 16 * self.scale) // 2)
        self.icons = {}
        self.grid = [[ord(' ')] * self.cols for _ in range(self.rows)]
        self.shown = [[ord(' ')] * self.cols for _ in range(self.rows)]
        # Virtual SD file browser (Print panel)
        self._sd_page = 0
        self._sd_files_cache = []
        self._sd_cache_t = 0.
        self._sd_per_page = 6
        self._sd_sel = 0
        self._sd_top = 0
        self._sd_vis = 12
        # Track real homing/probing so the display stays off the serial link.
        # (Must not rely on print_stats: a print file starts with G28.)
        self._homing = 0
        self._homing_t = 0.
        # After any GUI action that may move (print/move/home) keep the display
        # silent for a short grace window: the first moves of a print start are
        # short-buffered and a 7 KB redraw on the wire delays them ~15 ms.
        self._gui_grace_until = 0.
        self.printer.register_event_handler("homing:homing_move_begin",
                                            self._homing_begin)
        self.printer.register_event_handler("homing:homing_move_end",
                                            self._homing_end)
        self.printer.register_event_handler("klippy:connect", self._on_connect)
    # --- display framework interface ---
    def set_glyphs(self, glyphs):
        self.icons = glyphs
    def get_dimensions(self):
        return (self.cols, self.rows)
    def init(self):
        self.cmd_cmd = self.mcu.try_lookup_command("tft_cmd reg=%c")
        self.cmd_data = self.mcu.try_lookup_command("tft_data val=%hu")
        self.cmd_rect = self.mcu.try_lookup_command(
            "tft_rect x=%hu y=%hu w=%hu h=%hu color=%hu")
        self.cmd_char = self.mcu.try_lookup_command(
            "tft_char x=%hu y=%hu scale=%c ch=%c fg=%hu bg=%hu")
        self.cmd_icon = self.mcu.try_lookup_command(
            "tft_icon x=%hu y=%hu w=%hu h=%hu fg=%hu bg=%hu data=%*s")
        # Optional fast paths (new firmware): icon cache, string draws and
        # event driven touch.
        self.cmd_idef = self.mcu.try_lookup_command(
            "tft_idef id=%c w=%hu h=%hu off=%hu data=%*s")
        self.cmd_idraw = self.mcu.try_lookup_command(
            "tft_idraw id=%c x=%hu y=%hu fg=%hu bg=%hu")
        self.cmd_str = self.mcu.try_lookup_command(
            "tft_str x=%hu y=%hu scale=%c text=%*s fg=%hu bg=%hu")
        self.cmd_tcfg = self.mcu.try_lookup_command(
            "tft_touch_cfg threshold=%hu period=%hu")
        self.cmd_splash = self.mcu.try_lookup_command("tft_splash")
        # HOST LOST watchdog on the MCU: ping it every few seconds
        self.cmd_ping = self.mcu.try_lookup_command("tft_ping")
        self._ping_next = 0.
        self.cmd_ireset = self.mcu.try_lookup_command("tft_ireset")
        if None in (self.cmd_cmd, self.cmd_data, self.cmd_rect, self.cmd_char):
            logging.info("st7796: MCU has no tft_* commands (flash the display"
                         " firmware); display disabled for now")
            return
        self.enabled = True
        reactor = self.printer.get_reactor()
        mcu = self.mcu
        print_time = mcu.estimated_print_time(reactor.monotonic())
        c1 = mcu.print_time_to_clock(print_time + 0.12)
        c2 = mcu.print_time_to_clock(print_time + 0.24)
        c3 = mcu.print_time_to_clock(print_time + 0.36)
        if self.init_reset:
            self.cmd_cmd.send([0x01])             # SWRESET (now)
        self.cmd_cmd.send([0x11], minclock=c1)    # SLPOUT (+120ms)
        self.cmd_cmd.send([0x36], minclock=c2)    # MADCTL
        self.cmd_data.send([self.madctl], minclock=c2)
        seq = [
            (0xF0, [0xC3]), (0xF0, [0x96]),
            (0x3A, [0x55]),
            (0xB4, [self.init_dic]),
            (0xB7, [0xC6]),
            (0xC1, [0x15]),
            (0xC2, [0xAF]),
            (0xC5, [self.init_vcom]),
            (0xC6, [self.init_vcomofs]),
        ]
        if self.init_gamma:
            seq += [
                (0xE8, [0x40, 0x8A, 0x00, 0x00, 0x29, 0x19, 0xA5, 0x33]),
                (0xE0, [0xF0, 0x04, 0x08, 0x09, 0x08, 0x15, 0x2F, 0x42,
                        0x46, 0x28, 0x15, 0x16, 0x29, 0x2D]),
                (0xE1, [0xF0, 0x04, 0x09, 0x09, 0x08, 0x15, 0x2E, 0x46,
                        0x46, 0x28, 0x15, 0x15, 0x29, 0x2D]),
            ]
        seq += [(0x13, []), (0x53, [0x24]), (0xF0, [0x3C]), (0xF0, [0x69])]
        if self.init_invert:
            seq.append((0x21, []))     # INVON
        seq.append((0x29, []))         # DISPON
        for reg, data in seq:
            self.cmd_cmd.send([reg], minclock=c2)
            for d in data:
                self.cmd_data.send([d], minclock=c2)
        self.cmd_rect.send([0, 0, self.width, self.height, self.bg],
                           minclock=c2)
        # Ask the MCU to (re)draw the boot splash now that its init commands
        # have gone through, and hold it before drawing the GUI.
        splash = bool(self.splash and self.cmd_splash is not None)
        if splash:
            self.cmd_splash.send([], minclock=c3)
            logging.info("st7796: boot splash repintado pelo MCU (%.1fs)"
                         % self.splash_time)
        elif self.splash:
            logging.info("st7796: boot splash pedido mas o MCU nao tem"
                         " tft_splash (firmware antigo)")
        self.grid = [[ord(' ')] * self.cols for _ in range(self.rows)]
        self.shown = [[ord(' ')] * self.cols for _ in range(self.rows)]
        try:
            self.query_touch = self.mcu.lookup_query_command(
                "tft_touch",
                "tft_touch_result x=%hu y=%hu z=%hu xr=%hu yr=%hu")
        except Exception:
            self.query_touch = None
            logging.info("st7796: touch query not available")
        # Event driven touch: the MCU samples the panel and reports changes, so
        # the host never has to poll (no blocking queries on the serial link).
        if self.cmd_tcfg is not None and self.query_touch is not None:
            try:
                self.cmd_tcfg.send([int(self.touch_threshold), 25000])
                self.mcu.register_serial_response(
                    self._touch_report,
                    "tft_touch_result x=%hu y=%hu z=%hu xr=%hu yr=%hu")
                self._touch_evt = True
                logging.info("st7796: event driven touch enabled")
            except Exception:
                self._touch_evt = False
                logging.exception("st7796: event driven touch setup failed")
        self.cmd_bmp = self.mcu.try_lookup_command(
            "tft_bmp x=%hu y=%hu w=%hu rows=%c rowoff=%c fg=%hu bg=%hu"
            " data=%*s")
        self.cmd_rrect = self.mcu.try_lookup_command(
            "tft_rrect x=%hu y=%hu w=%hu h=%hu r=%c color=%hu")
        if self.gui and self.cmd_bmp is not None:
            # Draw after the panel init commands (which are scheduled ~0.24 s
            # out) so the init doesn't wipe the GUI. With the boot splash the
            # first frame waits a bit longer.
            delay = 0.36 + self.splash_time if splash else 0.30
            self._gui_pending = reactor.monotonic() + delay
        if self.gui or (self.query_touch is not None and self.touch_enable):
            reactor.update_timer(self.touch_timer, reactor.NOW)
    def clear(self):
        if self.gui:
            return
        self.grid = [[ord(' ')] * self.cols for _ in range(self.rows)]
    def flush(self):
        if not self.enabled or self.gui:
            return
        for r in range(self.rows):
            grow = self.grid[r]
            srow = self.shown[r]
            for c in range(self.cols):
                if grow[c] != srow[c]:
                    if grow[c] != ICON:
                        self._draw_cell(c, r, grow[c])
                    # else: icon already drawn by write_glyph this cycle
                    srow[c] = grow[c]
    def write_text(self, x, y, data):
        if self.gui:
            return
        if y < 0 or y >= self.rows:
            return
        for i, ch in enumerate(bytearray(data)):
            col = x + i
            if 0 <= col < self.cols:
                self.grid[y][col] = ch
    def write_glyph(self, x, y, glyph_name):
        if self.gui:
            return 0
        ch = TextGlyphs.get(glyph_name)
        if ch is not None:
            self.write_text(x, y, ch)
            return 1
        gd = self.icons.get(glyph_name)
        if gd is not None:
            icon = gd.get('icon16x16')
            if icon is not None and self.cmd_icon is not None and self.enabled:
                high, low = icon
                buf = bytearray()
                for i in range(16):
                    row = (high[i] << 8) | low[i]
                    buf.append((row >> 8) & 0xFF)
                    buf.append(row & 0xFF)
                isz = min(self.cell_w, self.cell_h)
                self._cover_cell(x, y)
                self.cmd_icon.send([x * self.cell_w,
                                    y * self.cell_h + (self.cell_h - isz) // 2,
                                    isz, isz, self.icon_color, self.bg,
                                    bytes(buf)])
                if 0 <= y < self.rows and 0 <= x < self.cols:
                    self.grid[y][x] = ICON
            else:
                self.write_text(x, y, b' ')
            return 1
        return 0
    def write_graphics(self, x, y, data):
        # Progress bar: data = [0xff] + [byte]*14 + [0xff], the byte holds the
        # 8 horizontal pixels of this bar slice.
        if (not self.enabled or self.gui
                or not (0 <= y < self.rows and 0 <= x < self.cols)):
            return
        b = data[1] & 0xFF if len(data) > 1 else 0
        bar_h = max(4, self.cell_h // 2)
        px = x * self.cell_w
        py = y * self.cell_h + (self.cell_h - bar_h) // 2
        filled = (self.cell_w * bin(b).count('1') + 4) // 8
        self.cmd_rect.send([px, py, self.cell_w, bar_h, self.bar_bg])
        if filled > 0:
            self.cmd_rect.send([px, py, filled, bar_h, self.bar_color])
    # --- diagnostics ---
    def _rgb565(self, r, g, b):
        return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | ((b & 0xF8) >> 3)
    def cmd_TFT_FILL(self, gcmd):
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        r = gcmd.get_int('R', 0, minval=0, maxval=255)
        g = gcmd.get_int('G', 0, minval=0, maxval=255)
        b = gcmd.get_int('B', 0, minval=0, maxval=255)
        color = self._rgb565(r, g, b)
        self.cmd_rect.send([0, 0, self.width, self.height, color])
        msg = gcmd.get('MSG', '')
        if msg:
            self._gui_text_center(0, self.width, self.height // 2, msg[:56],
                                  0xFFFF, color, 1)
    def cmd_TFT_TEST(self, gcmd):
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        w2 = self.width // 2
        h2 = self.height // 2
        self.cmd_rect.send([0, 0, w2, h2, 0xF800])    # red
        self.cmd_rect.send([w2, 0, w2, h2, 0x07E0])   # green
        self.cmd_rect.send([0, h2, w2, h2, 0x001F])   # blue
        self.cmd_rect.send([w2, h2, w2, h2, 0xFFFF])  # white
        for i, ch in enumerate(b'ABCDEFGHIJ'):
            self.cmd_char.send([i * self.cell_w, h2 + self.vpad,
                                self.scale, ch, 0x0000, 0xFFFF])
    def cmd_TFT_LIMITS(self, gcmd):
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        w, h = self.width, self.height
        W, K = 0xFFFF, 0x0000
        self.cmd_rect.send([0, 0, w, h, K])            # clear black
        # outer 1px frame, touching the panel edges
        self.cmd_rect.send([0, 0, w, 1, W])
        self.cmd_rect.send([0, h - 1, w, 1, W])
        self.cmd_rect.send([0, 0, 1, h, W])
        self.cmd_rect.send([w - 1, 0, 1, h, W])
        # inner 1px frame, 5px padding
        self.cmd_rect.send([5, 5, w - 10, 1, W])
        self.cmd_rect.send([5, h - 6, w - 10, 1, W])
        self.cmd_rect.send([5, 5, 1, h - 10, W])
        self.cmd_rect.send([w - 6, 5, 1, h - 10, W])
    def cmd_TFT_LINES(self, gcmd):
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        w, h = self.width, self.height
        period = gcmd.get_int('W', 20, minval=1, maxval=w)
        for i, x in enumerate(range(0, w, period)):
            color = 0xFFFF if (i & 1) == 0 else 0x0000
            self.cmd_rect.send([x, 0, min(period, w - x), h, color])
    def cmd_TFT_FILLV(self, gcmd):
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        w, h = self.width, self.height
        step = gcmd.get_int('W', 20, minval=1, maxval=w)
        r = gcmd.get_int('R', 0, minval=0, maxval=255)
        g = gcmd.get_int('G', 0, minval=0, maxval=255)
        b = gcmd.get_int('B', 0, minval=0, maxval=255)
        color = self._rgb565(r, g, b)
        for x in range(0, w, step):
            self.cmd_rect.send([x, 0, min(step, w - x), h, color])
    # --- panel/scan-line diagnostics (host only, no reflash) ---
    def cmd_TFT_PANEL(self, gcmd):
        # Write ST7796 display registers live, to hunt panel banding/stripes.
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        out = []
        dic = gcmd.get_int('DIC', None)
        if dic is not None:
            self.cmd_cmd.send([0xB4])
            self.cmd_data.send([dic & 0xFF])
            out.append("DIC=0x%02X" % (dic & 0xFF))
        vcom = gcmd.get_int('VCOM', None)
        if vcom is not None:
            self.cmd_cmd.send([0xC5])
            self.cmd_data.send([vcom & 0xFF])
            out.append("VCOM=0x%02X" % (vcom & 0xFF))
        ofs = gcmd.get_int('VCOM_OFS', None)
        if ofs is not None:
            self.cmd_cmd.send([0xC6])
            self.cmd_data.send([ofs & 0xFF])
            out.append("VCM_OFS=0x%02X" % (ofs & 0xFF))
        invon = gcmd.get_int('INVON', None)
        if invon is not None:
            self.cmd_cmd.send([0x21 if invon else 0x20])
            out.append("INVON=%d" % (1 if invon else 0))
        gcmd.respond_info("tft panel: " + (", ".join(out) if out else "no change"))
    def cmd_TFT_SPLIT(self, gcmd):
        # Left half = one big rect, right half = many narrow rects, same colour.
        # If only the left half shows the lines, the fill method is to blame;
        # if both do, it is the panel.
        if not self.enabled:
            raise gcmd.error("st7796 display not enabled")
        c = gcmd.get_int('C', 0x1418, minval=0, maxval=0xFFFF)
        w = gcmd.get_int('W', 1, minval=1, maxval=self.width)
        self.cmd_rect.send([0, 0, self.width, self.height, 0x0000])
        half = self.width // 2
        self.cmd_rect.send([0, 0, half, self.height, c])
        x = half
        while x < self.width:
            n = min(w, self.width - x)
            self.cmd_rect.send([x, 0, n, self.height, c])
            x += n
        self._gui_text(6, 6, "1 RECT", 0xFFFF, c)
        self._gui_text(half + 6, 6, "STRIPS W=%d" % w, 0xFFFF, c)
    def cmd_TFT_NET(self, gcmd):
        if gcmd.get_int('ANNOUNCE', 0):
            info = self._net_info()
            ip = self._net_announce()
            gcmd.respond_info("announce (SSDP) -> %s" % ip)
        i = self._net_info()
        gcmd.respond_info("net: ssid=%s ip=%s sinal=%s host=%s"
                          % (i['ssid'], i['ip'], i['qual'], i['host']))
    def cmd_TFT_GUI(self, gcmd):
        if not self.gui:
            return
        scr = gcmd.get('SCREEN', None)
        if scr == 'meshadj':
            self._adj_open(self.printer.get_reactor().monotonic())
            return
        if scr:
            self.gui_screen = scr
        self._gui_pending = self.printer.get_reactor().monotonic()
    # --- touch (XPT2046 -> Klipper menu gestures) ---
    def _get_menu(self):
        if self.menu is None:
            disp = self.printer.lookup_object('display', None)
            if disp is not None:
                self.menu = getattr(disp, 'menu', None)
        return self.menu
    def _touch_event(self, eventtime):
        self._mcu_recover(eventtime)
        if self.printer.is_shutdown():
            # Klipper stopped (shutdown): show why and offer a restart
            try:
                self._err_panel(eventtime)
            except Exception:
                pass
            return eventtime + 0.5
        self._err_shown = None
        try:
            self._fil_watch(eventtime)
            self._print_watch(eventtime)
        except Exception:
            logging.exception("st7796: watch failed")
        try:
            self._upd_check(eventtime)
        except Exception:
            pass
        if self.cmd_ping is None:
            if not getattr(self, '_ping_warned', False):
                self._ping_warned = True
                logging.warning("st7796: MCU has no tft_ping - watchdog off")
        elif eventtime >= self._ping_next:
            # tiny command (2 bytes), sent even while the panel is muted, so
            # the MCU can tell the Pi is still alive
            self._ping_next = eventtime + 3.
            if not getattr(self, '_ping_logged', False):
                self._ping_logged = True
                logging.info("st7796: tft_ping enviado (watchdog MCU)")
            try:
                self.cmd_ping.send([])
            except Exception:
                logging.exception("st7796: tft_ping falhou")
        if self.gui and self._disp_quiet(eventtime):
            # Printer is homing/moving: stay off the link. During homing/probing
            # stay completely silent (trsync timing), otherwise send a tiny
            # heartbeat (clock + hourglass) so the screen doesn't look frozen.
            if (self._mesh_run > 0 and not self._homing
                    and not self._gui_ops and eventtime >= self._gui_beat):
                # Leveling: keep the screen alive - temperatures while heating,
                # the map while travelling between probe points. Never during a
                # probe move (_homing): that is when trsync timing is critical.
                self._gui_beat = eventtime + 0.3
                try:
                    self._mesh_update(eventtime)
                except Exception:
                    logging.exception("st7796: mesh update failed")
                return eventtime + 0.1
            if not self._homing and eventtime >= self._gui_beat:
                self._gui_beat = eventtime + 1.0
                try:
                    self._gui_clock(eventtime)
                except Exception:
                    pass
            return eventtime + 0.06
        if self._gui_pending is not None:
            if eventtime >= self._gui_pending:
                self._gui_pending = None
                if self.gui and self.gui_screen == 'meshadj':
                    self._adj_update(eventtime)
                else:
                    self._gui_render(eventtime)
        if self.query_touch is None:
            return eventtime + 0.2
        if self._touch_evt:
            # The MCU samples the panel itself (tft_touch_cfg) and only reports
            # changes - nothing to poll, so no blocking query. The periodic GUI
            # work (bars, print-start detection) still has to run here.
            if self.gui:
                self._gui_periodic(eventtime)
            return eventtime + 0.05
        try:
            resp = self.query_touch.send([])
        except Exception:
            return eventtime + 0.1
        self._touch_sample(resp.get('x', 0), resp.get('y', 0),
                           resp.get('z', 0), eventtime)
        return eventtime + (0.03 if self.gui else 0.04)
    def _touch_report(self, params):
        # Unsolicited tft_touch_result from the MCU (event driven touch).
        try:
            et = self.printer.get_reactor().monotonic()
            self._touch_sample(params.get('x', 0), params.get('y', 0),
                               params.get('z', 0), et)
        except Exception:
            logging.exception("st7796: touch report failed")
    def _gui_periodic(self, eventtime):
        # Print-start detection + periodic bars (runs from the touch timer and
        # from touch events).
        try:
            st = self.printer.lookup_object('print_stats').get_status(
                eventtime)['state']
        except Exception:
            st = 'ready'
        if st != self._last_ps_state:
            self._last_ps_state = st
            if st in ('printing', 'paused'):
                # A print just started: jump to the printing screen and apply
                # the saved baby step.
                self.gui_screen = 'print'
                self._gui_defer(eventtime, 0.05)
                self._baby_apply_saved()
                self._preview_start(eventtime)
        if eventtime >= self._gui_next:
            self._gui_next = eventtime + 0.5
            self._gui_bars(eventtime)
        if self._prev_pending and self._prev_bits is not None:
            self._prev_pending = False
            self._preview_drop_cache()
            self._gui_defer(eventtime, 0.05)
        if (self.gui and self.gui_screen == 'mesh' and not self._gui_ops
                and eventtime >= self._mesh_t):
            # Leveling screen: only redraw what changed (temperatures / probe
            # map) - a full repaint every second flickers.
            self._mesh_t = eventtime + (0.3 if self._mesh_run > 0 else 1.0)
            try:
                self._mesh_update(eventtime)
            except Exception:
                logging.exception("st7796: mesh update failed")
    def _touch_sample(self, x, y, z, eventtime):
        if self.touch_debug:
            self._dbg_i = (getattr(self, '_dbg_i', 0) + 1) % 4
            if self._dbg_i == 0:
                self.gcode.respond_info("raw x=%d y=%d z=%d" % (x, y, z))
        if self._mon is not None:
            m = self._mon
            m['zmin'] = min(m['zmin'], z)
            if z >= 40:  # only sample x/y while actually touching
                m['xmin'] = min(m['xmin'], x); m['xmax'] = max(m['xmax'], x)
                m['ymin'] = min(m['ymin'], y); m['ymax'] = max(m['ymax'], y)
                if z > m['zmax']:
                    m['zmax'] = z; m['xz'] = x; m['yz'] = y
            if eventtime >= m['end']:
                self.gcode.respond_info(
                    "touch mon: z %d..%d | x %d..%d | y %d..%d | at max z"
                    " x=%d y=%d" % (m['zmin'], m['zmax'], m['xmin'],
                                    m['xmax'], m['ymin'], m['ymax'],
                                    m['xz'], m['yz']))
                self._mon = None
            return
        if self.gui:
            self._gui_periodic(eventtime)
            if z >= self.touch_threshold:
                if not self._touched:
                    self._touched = True
                    self._x0, self._y0 = x, y
                self._xl, self._yl = x, y
            elif self._touched:
                self._touched = False
                if (abs(self._xl - self._x0) < self.touch_swipe
                        and abs(self._yl - self._y0) < self.touch_swipe):
                    self._gui_tap((self._x0 + self._xl) // 2,
                                  (self._y0 + self._yl) // 2, eventtime)
            return
        if z >= self.touch_threshold:
            if self.touch_debug:
                self.gcode.respond_info("touch raw x=%d y=%d z=%d" % (x, y, z))
            if not self._touched:
                self._touched = True
                self._t0 = eventtime
                self._x0, self._y0 = x, y
            self._xl, self._yl = x, y
        elif self._touched:
            self._touched = False
            self._handle_gesture(eventtime)
    def _handle_gesture(self, eventtime):
        dt = eventtime - self._t0
        dx = self._xl - self._x0
        dy = self._yl - self._y0
        if self.touch_swap:
            dx, dy = dy, dx
        if self.touch_inv_x:
            dx = -dx
        if self.touch_inv_y:
            dy = -dy
        sw = self.touch_swipe
        key = None
        if abs(dx) < sw and abs(dy) < sw:
            if dt >= self.touch_long:
                key = 'click'            # long press selects
            elif self.touch_short_tap:
                key = 'click'            # (optional) short tap also selects
            else:
                key = None               # ignore short taps (resistive noise)
        elif abs(dy) >= abs(dx):
            if dy > 0:
                key = 'fast_down' if abs(dy) > 2 * sw else 'down'
            else:
                key = 'fast_up' if abs(dy) > 2 * sw else 'up'
        elif dx < 0:
            key = 'back'
        if key is None:
            return
        menu = self._get_menu()
        if menu is not None:
            logging.info("st7796: touch gesture -> %s", key)
            menu.key_event(key, eventtime)
    def cmd_TFT_TOUCH(self, gcmd):
        if self.query_touch is None:
            raise gcmd.error("st7796 touch not available")
        r = self.query_touch.send([])
        gcmd.respond_info("touch x=%d y=%d z=%d (raw xr=%d yr=%d)"
                          % (r.get('x', 0), r.get('y', 0), r.get('z', 0),
                             r.get('xr', 0), r.get('yr', 0)))
    def cmd_TFT_TOUCH_DEBUG(self, gcmd):
        self.touch_debug = not self.touch_debug
        gcmd.respond_info("touch debug %s"
                          % ("on" if self.touch_debug else "off"))
    def cmd_TFT_TOUCH_MON(self, gcmd):
        if self.query_touch is None:
            raise gcmd.error("st7796 touch not available")
        t = gcmd.get_float('T', 5., above=0.)
        now = self.printer.get_reactor().monotonic()
        self._mon = {'end': now + t, 'zmin': 9999, 'zmax': 0,
                     'xmin': 9999, 'xmax': 0, 'ymin': 9999, 'ymax': 0,
                     'xz': 0, 'yz': 0}
        gcmd.respond_info("touch mon: sampling %.0fs - touch the screen now" % t)
    # --- KlipperScreen-like GUI ---
    TOP_H = 30
    RAIL_W = 36
    STRIP_H = 34
    MESH_X0 = RAIL_W + 14
    MESH_Y0 = TOP_H + 16
    ADJ_X0 = 288      # manual mesh adjustment: grid centroid
    ADJ_Y0 = 66
    ADJ_SPAN = 156
    ADJ_STEPS = (0.005, 0.01, 0.1)
    def _gc(self, i):
        return GUI_COLORS[i % len(GUI_COLORS)]
    def _gui_text(self, x, y, text, fg, bg, scale=1):
        data = text.encode('latin-1')
        if self.cmd_str is not None:
            # One command per chunk of text (far less serial overhead).
            for i in range(0, len(data), 32):
                self.cmd_str.send([x + i * 8 * scale, y, scale,
                                   bytes(data[i:i + 32]), fg, bg])
            return
        for i, ch in enumerate(data):
            self.cmd_char.send([x + i * 8 * scale, y, scale, ch, fg, bg])
    def _gui_text_center(self, x0, w, y, text, fg, bg, scale=1):
        tw = len(text) * 8 * scale
        self._gui_text(x0 + max(0, (w - tw) // 2), y, text, fg, bg, scale)
    @staticmethod
    def _resample(data, w, h, nw, nh):
        # Box-filter downscale of a 1-bit bitmap (MSB first, row-major).
        rowbytes = (w + 7) // 8
        nrb = (nw + 7) // 8
        out = bytearray()
        for j in range(nh):
            j0 = j * h // nh
            j1 = max(j0 + 1, (j + 1) * h // nh)
            bits = 0
            for i in range(nw):
                i0 = i * w // nw
                i1 = max(i0 + 1, (i + 1) * w // nw)
                on = tot = 0
                for sj in range(j0, j1):
                    base = sj * rowbytes
                    for si in range(i0, i1):
                        tot += 1
                        idx = base + (si >> 3)
                        if idx < len(data) and data[idx] & (0x80 >> (si & 7)):
                            on += 1
                bits = (bits << 1) | (1 if tot and on * 2 >= tot else 0)
            bits <<= (nrb * 8 - nw)
            for k in range(nrb):
                out.append((bits >> ((nrb - 1 - k) * 8)) & 0xFF)
        return bytes(out)
    def _scaled_icon(self, name):
        ent = EXTRA_ICONS.get(name)
        if ent is not None:
            return ent            # locally generated, already the right size
        ent = tft_icons.ICONS.get(name)
        if ent is None:
            return None
        s = self.gui_icon_scale
        if s >= 0.999:
            return ent
        key = (name, s)
        res = self._icon_cache.get(key)
        if res is not None:
            return res
        w, h, data = ent
        nw = max(4, int(round(w * s)))
        nh = max(4, int(round(h * s)))
        res = (nw, nh, self._resample(data, w, h, nw, nh))
        self._icon_cache[key] = res
        return res
    def _icon_at(self, name, size):
        ent = EXTRA_ICONS.get(name) or tft_icons.ICONS.get(name)
        if ent is None:
            return None
        w, h, data = ent
        if w == size and h == size:
            return ent
        key = ('@', name, size)
        res = self._icon_cache.get(key)
        if res is not None:
            return res
        res = (size, size, self._resample(data, w, h, size, size))
        self._icon_cache[key] = res
        return res
    def _icon_id(self, key, icon):
        # Cache a bitmap on the MCU (if supported) and return its id.
        if self.cmd_idraw is None or self.cmd_idef is None or key is None:
            return None
        i = self._ic_ids.get(key)
        if i is not None:
            return i if i >= 0 else None
        w, h, data = icon
        size = ((w + 7) // 8) * h
        if (size < 24 or size > self._ic_max or len(self._ic_ids) >= 60
                or self._ic_bytes + size > 22000):
            self._ic_ids[key] = -1
            return None
        i = len(self._ic_ids)
        try:
            for off in range(0, size, 32):
                self.cmd_idef.send([i, w, h, off,
                                    bytes(data[off:off + 32])])
        except Exception:
            logging.exception("st7796: icon upload failed")
            self._ic_ids[key] = -1
            return None
        self._ic_ids[key] = i
        self._ic_bytes += size
        return i
    def _draw_bmp(self, icon, x, y, fg, bg, key=None):
        if icon is None or self.cmd_bmp is None:
            return
        if key is not None and self.cmd_idraw is not None:
            i = self._icon_id(key, icon)
            if i is not None:
                self.cmd_idraw.send([i, x, y, fg, bg])
                return
        w, h, data = icon
        rowbytes = (w + 7) // 8
        rows_per = max(1, 40 // rowbytes)
        for off in range(0, h, rows_per):
            rows = min(rows_per, h - off)
            chunk = data[off * rowbytes:(off + rows) * rowbytes]
            self.cmd_bmp.send([x, y, w, rows, off, fg, bg, bytes(chunk)])
    def _gui_icon(self, name, x, y, fg, bg):
        self._draw_bmp(self._scaled_icon(name), x, y, fg, bg, ('s', name))
    def _gui_icon_at(self, name, x, y, fg, bg, size):
        self._draw_bmp(self._icon_at(name, size), x, y, fg, bg, (name, size))
    def _bmp_at(self, bmp, x, y, fg, bg, key=None):
        w, h, data = bmp
        if w <= 0 or h <= 0 or self.cmd_bmp is None:
            return
        self._draw_bmp(bmp, x, y, fg, bg, key)
    def _gui_round(self, x, y, w, h, color, bg=None):
        # bg: colour the corners are cleared to (the surface behind the box).
        # Without it a box drawn on another box gets dark notches at the
        # corners.
        self.cmd_rect.send([x, y, w, h, color])
        r = self.gui_radius
        if r <= 0 or self.cmd_bmp is None:
            return
        if bg is None:
            bg = self.gui_bg
        tl, tr, bl, br = self._corners
        self._bmp_at(tl, x, y, color, bg, ('corner', 0))
        self._bmp_at(tr, x + w - r, y, color, bg, ('corner', 1))
        self._bmp_at(bl, x, y + h - r, color, bg, ('corner', 2))
        self._bmp_at(br, x + w - r, y + h - r, color, bg, ('corner', 3))
    # --- virtual SD file browser ---
    def _sd_dir(self):
        try:
            vsd = self.printer.lookup_object('virtual_sdcard')
            return getattr(vsd, 'sdcard_dirname', None)
        except Exception:
            return None
    def _sd_files(self):
        # [(name, mtime)] newest first.
        now = self.printer.get_reactor().monotonic()
        if now - self._sd_cache_t < 3.:
            return self._sd_files_cache
        self._sd_cache_t = now
        d = self._sd_dir()
        entries = []
        if d and os.path.isdir(d):
            try:
                for n in os.listdir(d):
                    if n.lower().rsplit('.', 1)[-1] not in ('gcode', 'gco',
                                                            'g'):
                        continue
                    try:
                        m = os.stat(os.path.join(d, n)).st_mtime
                    except OSError:
                        m = 0.
                    entries.append((n, m))
            except OSError:
                entries = []
        entries.sort(key=lambda e: -e[1])
        self._sd_files_cache = entries
        return entries
    # Vertical list geometry: the list fills the button area, with up/down/print
    # buttons in a strip on the right.
    RIGHT_W = 80
    LIST_PITCH = 26
    def _list_area(self):
        return (self.RAIL_W, self.TOP_H, self.width - self.RIGHT_W,
                self.height - self.STRIP_H)
    def _list_rows(self):
        x0, y0, x1, y1 = self._list_area()
        pitch = self.LIST_PITCH
        n = max(1, (y1 - y0) // pitch)
        files = self._sd_files()
        self._sd_vis = n
        self._sd_sel = max(0, min(max(0, len(files) - 1), self._sd_sel))
        if self._sd_sel < self._sd_top:
            self._sd_top = self._sd_sel
        if self._sd_sel >= self._sd_top + n:
            self._sd_top = self._sd_sel - n + 1
        self._sd_top = max(0, min(self._sd_top, max(0, len(files) - n)))
        out = []
        for i in range(n):
            k = self._sd_top + i
            if k >= len(files):
                break
            out.append((x0, y0 + i * pitch, x1 - x0, pitch, k, files[k][0]))
        return out
    def _list_btns(self):
        x0, y0, x1, y1 = self._list_area()
        bw = bh = 64
        bx = x1 + (self.RIGHT_W - bw) // 2
        gap = 6
        total = 3 * bh + 2 * gap
        by = y0 + max(0, (y1 - y0 - total) // 2)
        kinds = ('up', 'down', 'print')
        return [(bx, by + i * (bh + gap), bw, bh, k)
                for i, k in enumerate(kinds)]
    def _screen_items(self):
        if self.gui_screen == 'print':
            return []
        if self.gui_screen == 'macros':
            return self._macro_items()
        return GUI_SCREENS.get(self.gui_screen, [])
    def _gui_buttons(self):
        cols = GUI_COLS.get(self.gui_screen, 4)
        rows = GUI_ROWS.get(self.gui_screen, 2)
        x0, y0 = self.RAIL_W, self.TOP_H
        x1, y1 = self.width, self.height - self.STRIP_H
        bw = (x1 - x0) // cols
        bh = (y1 - y0) // rows
        screen = self._screen_items()
        out = []
        for idx in range(cols * rows):
            item = screen[idx] if idx < len(screen) else None
            out.append((x0 + (idx % cols) * bw, y0 + (idx // cols) * bh,
                        bw, bh, idx, item))
        return out
    def _gui_rail(self):
        back = {'meshadj': 'mesh', 'advanced': 'calibrate',
                'limits': 'calibrate', 'pid': 'calibrate',
                'info': 'more', 'filout': 'print',
                'wifilist': 'network', 'wifikey': 'network'}.get(
                    self.gui_screen)
        if back is None:
            back = ('scr', 'print') if self.gui_screen in ('ptune',
                                                           'filament') \
                else ('scr', 'main')
        else:
            back = ('scr', back)
        items = [('back24', back), ('home24', ('scr', 'main')),
                 ('files24', ('scr', 'print')), ('alert24', ('scr', 'power'))]
        n = len(items)
        area = self.height - self.STRIP_H - self.TOP_H
        step = min(56, (area - 40) // max(1, n - 1))
        total = (n - 1) * step + 24
        y0 = self.TOP_H + (area - total) // 2
        return [(6, y0 + i * step, name, action,
                 # Back/Home are meaningless on the main screen: dim + inert.
                 self.gui_screen == 'main' and action == ('scr', 'main'))
                for i, (name, action) in enumerate(items)]
    def _gui_strip(self):
        items = GUI_STRIP.get(self.gui_screen)
        if not items:
            return []
        n = len(items)
        x0 = self.RAIL_W
        w = (self.width - x0) // n
        y = self.height - self.STRIP_H
        return [(x0 + i * w + 2, y + 3, w - 5, self.STRIP_H - 6, lab, val)
                for i, (lab, val) in enumerate(items)]
    def _temp_color(self, cur, tgt):
        # orange while heating, green once at target, blue when cooling/off
        if tgt <= 0.:
            return COL_COOL
        if cur >= tgt - 3.:
            return COL_OK
        return COL_HEAT
    def _gui_heater(self, icon, iy, tx, st):
        cur = st['temperature']
        tgt = st['target']
        col = self._temp_color(cur, tgt)
        self._gui_icon_at(icon, tx - 28, iy, col, self.gui_bar_bg, 20)
        self._gui_text(tx, 7, ("%d>%d" % (cur, tgt)).ljust(7), col,
                       self.gui_bar_bg, 1)
    def _filament_status(self, eventtime):
        try:
            st = self.printer.lookup_object(
                'filament_switch_sensor ' + self.filament_sensor).get_status(
                    eventtime)
            return bool(st.get('enabled')), bool(st.get('filament_detected'))
        except Exception:
            return None, None
    def _gui_topbar(self, eventtime, fill=True):
        bg = self.gui_bar_bg
        if fill:
            self.cmd_rect.send([0, 0, self.width, self.TOP_H, bg])
        ps = self._print_status(eventtime)
        printing = ps is not None and ps['state'] in ('printing', 'paused')
        if self.gui_screen == 'print' and printing:
            # While printing the top bar shows the file name instead of the
            # temperatures (those are in the info panel).
            fname = os.path.basename(ps.get('filename') or '') or '-'
            self._gui_text(6, 7, (fname + ' ' * 26)[:26], COL_WHITE, bg, 1)
        else:
            try:
                nb = self.printer.lookup_object('extruder').get_status(
                    eventtime)
                bd = self.printer.lookup_object('heater_bed').get_status(
                    eventtime)
            except Exception:
                return
            self._gui_heater('nozzle', 9, 34, nb)
            self._gui_heater('bed', 7, 120, bd)
        if self.gui_screen != 'print':
            # Centre the real title (the old code padded it to 14 chars,
            # which pushed the visible text left of the middle).
            title = GUI_TITLES.get(self.gui_screen,
                                   self.gui_screen.capitalize())[:14]
            self._gui_text_center(0, self.width, 7, title, COL_WHITE, bg, 1)
        ctxt, ccol = self._clock_text(eventtime)
        self._gui_text(self.width - 68, 7, ctxt, ccol, bg, 1)
        if self.gui_version:
            self._gui_text(self.width - 170, 7,
                           (self.gui_version + ' ' * 8)[:8], COL_DIM, bg, 1)
        if self._upd_n:
            self._gui_icon_at('refresh', self.width - 152, 7, COL_WARN, bg, 16)
        # Filament runout indicator: green = filament ok, red = runout,
        # grey = sensor disabled/unavailable.
        en, det = self._filament_status(eventtime)
        fcol = COL_DIM
        if en and det:
            fcol = COL_OK
        elif en and not det:
            fcol = COL_ERR
        ficon = 'filok' if (not en or det) else 'filnout'
        self._gui_icon_at(ficon, self.width - 124, 6, fcol, bg, 20)
        # WiFi: white while associated, grey when there is no link
        wcol = COL_WHITE if self._wifi_link() else COL_DIM
        self._gui_icon_at('network', self.width - 102, 8, wcol, bg, 18)
        # Hourglass: dark grey normally, WHITE while the touch will not respond
        # (display muted during homing/moves or while a GUI action runs).
        self._draw_hourglass(self._disp_quiet(eventtime))
    def _gui_busy(self, text="PLEASE WAIT"):
        # Centred overlay while a blocking action mutes the panel. Drawn
        # directly (not queued) and wiped by the redraw that follows the
        # action, so it disappears on its own.
        w = min(360, self.width - self.RAIL_W - 40)
        h = 84
        x = self.RAIL_W + (self.width - self.RAIL_W - w) // 2
        y = self.TOP_H + (self.height - self.STRIP_H - self.TOP_H - h) // 2
        self._gui_round(x, y, w, h, self.gui_bar_bg)
        self._gui_icon_at('hourglass20', x + 14, y + (h - 20) // 2, COL_WARN,
                          self.gui_bar_bg, 20)
        self._gui_text(x + 46, y + (h - 32) // 2, text, COL_WHITE,
                       self.gui_bar_bg, 2)
        self.cmd_rect.send([x + 46, y + h - 12, w - 60, 4, COL_WARN])
    def _draw_hourglass(self, dead):
        self._gui_icon_at('hourglass20', self.width - 22, 11,
                          COL_WHITE if dead else COL_DIM, self.gui_bar_bg,
                          11)
    def _eta_left(self, eventtime):
        # Seconds left (smoothed) while printing, else None.
        try:
            ps = self.printer.lookup_object('print_stats').get_status(
                eventtime)
            if ps.get('state') not in ('printing', 'paused'):
                self._eta_hist = []
                return None
            prog = float(self.printer.lookup_object(
                'virtual_sdcard').get_status(eventtime).get('progress') or 0.)
            dur = float(ps.get('print_duration') or 0.)
        except Exception:
            return None
        if prog < 0.02 or dur < 30.:
            return None
        left = dur * (1. - prog) / prog
        self._eta_hist.append(left)
        if len(self._eta_hist) > 6:
            self._eta_hist.pop(0)
        return sum(self._eta_hist) / len(self._eta_hist)

    def _clock_text(self, eventtime):
        # Time of day from the host (the Pi runs NTP). The print time and the
        # ETA live on the print screen, so the bar stays a plain clock.
        try:
            return time.strftime('%H:%M'), COL_WHITE
        except Exception:
            return "--:--", COL_DIM

    def _gui_clock(self, eventtime):
        # Minimal heartbeat while the display is muted: just the clock + the
        # hourglass (~60 bytes), so the screen does not look frozen.
        txt, col = self._clock_text(eventtime)
        self._gui_text(self.width - 68, 7, txt, col, self.gui_bar_bg, 1)
        self._draw_hourglass(True)
    # --- bed mesh probing map ---------------------------------------------
    def _mesh_hook(self):
        # bed_mesh (and the BED_MESH_CALIBRATE / G29 macros) may be configured
        # after this section, so also retry once the printer is fully built.
        if self._mesh_base is None:
            try:
                base = self.gcode.register_command('BED_MESH_CALIBRATE', None)
            except Exception:
                base = None
            if base is not None:
                self._mesh_base = base
                try:
                    self.gcode.register_command('BED_MESH_CALIBRATE',
                                                self._cmd_mesh_calibrate)
                    logging.info("st7796: BED_MESH_CALIBRATE hooked (probe map)")
                except Exception:
                    logging.exception("st7796: cannot hook BED_MESH_CALIBRATE")
        if self._g29_base is None:
            try:
                base = self.gcode.register_command('G29', None)
            except Exception:
                base = None
            if base is not None:
                self._g29_base = base
                try:
                    self.gcode.register_command('G29', self._cmd_g29)
                    logging.info("st7796: G29 hooked (leveling notice)")
                except Exception:
                    logging.exception("st7796: cannot hook G29")

    def _mesh_notice(self, secs=1800.):
        # Warn the user that leveling heats the bed and the hotend.
        self._gui_msg = ("Nivelamento: aquece cama e bico. Limpa o bico"
                         " antes de continuar!")
        self._gui_msg_until = (
            self.printer.get_reactor().monotonic() + secs)

    def _cmd_g29(self, gcmd):
        if self._g29_base is None:
            return
        reactor = self.printer.get_reactor()
        prev = self.gui_screen
        self._mesh_run += 1
        try:
            self._mesh_notice()
            self._mesh_forget()
            mn, mx, cx, cy = self._mesh_geo()
            logging.info("st7796: nivelamento %dx%d de %s a %s",
                         cx, cy, tuple(mn), tuple(mx))
            if self.gui:
                self.gui_screen = 'mesh'
                self._gui_render(reactor.monotonic())
        except Exception:
            logging.exception("st7796: g29 notice failed")
        try:
            self._g29_base(gcmd)
        finally:
            self._mesh_run = max(0, self._mesh_run - 1)
            if self.gui:
                self.gui_screen = prev or 'print'
                self._gui_defer(reactor.monotonic(), 0.3)
            self._gui_msg = None
            self._gui_msg_until = 0.

    def _cmd_mesh_calibrate(self, gcmd):
        if self._mesh_base is None:
            return
        reactor = self.printer.get_reactor()
        prev = self.gui_screen
        self._mesh_active = True
        self._mesh_run += 1
        self._mesh_done = -1
        self._mesh_arm = 0.
        self._mesh_forget()
        mn, mx, cx, cy = self._mesh_geo()
        logging.info("st7796: nivelamento %dx%d de %s a %s",
                     cx, cy, tuple(mn), tuple(mx))
        try:
            self._mesh_notice(240.)
        except Exception:
            pass
        if self.gui:
            self.gui_screen = 'mesh'
            self._gui_render(reactor.monotonic())
        try:
            self._mesh_base(gcmd)
        finally:
            self._mesh_active = False
            self._mesh_run = max(0, self._mesh_run - 1)
            if self.gui:
                self.gui_screen = prev or 'print'
                self._gui_defer(reactor.monotonic(), 0.3)

    def _mesh_geo(self):
        # (mesh_min, mesh_max, cols, rows) of the configured bed mesh. The
        # bed_mesh status only reports mesh_min/mesh_max once a mesh is loaded
        # (it returns 0,0 before that), so always take them from the config -
        # those are the tool coordinates the probe will actually visit.
        mn, mx, cx, cy = (0., 0.), (300., 300.), 4, 4
        try:
            cfg = self.printer.lookup_object('configfile').get_status(0)[
                'settings'].get('bed_mesh', {})
            mn = tuple(float(v) for v in cfg.get('mesh_min', mn))
            mx = tuple(float(v) for v in cfg.get('mesh_max', mx))
            pc = cfg.get('probe_count', (4, 4))
            cx, cy = max(2, int(pc[0])), max(2, int(pc[1]))
        except Exception:
            pass
        return mn, mx, cx, cy

    def _mesh_cur(self, eventtime):
        try:
            st = self.printer.lookup_object('toolhead').get_status(eventtime)
            pos = st['position']
        except Exception:
            return None
        return float(pos[0]), float(pos[1])

    def _mesh_pts(self, mn, mx, cx, cy, x0=None, y0=None, span=None):
        # [(screen_x, screen_y, probe index, col, row)] - the probe order is
        # serpentine, the on-screen layout is the plain grid.
        x0 = self.MESH_X0 if x0 is None else x0
        y0 = self.MESH_Y0 if y0 is None else y0
        span = 60 * (max(cx, cy) - 1) + 16 if span is None else span
        out = []
        for j in range(cy):
            for m in range(cx):
                i = m if j % 2 == 0 else cx - 1 - m
                sx = x0 + int(i * (span - 16) / (cx - 1))
                sy = y0 + int((cy - 1 - j) * (span - 16) / (cy - 1))
                out.append((sx, sy, j * cx + m, i, j))
        return out

    def _mesh_marker(self, pts, mn, mx, cx, cy, eventtime):
        # index of the point the head is closest to (-1 when not probing)
        if not self._mesh_active:
            return -1
        pos = self._mesh_cur(eventtime)
        if pos is None:
            return -1
        hx, hy = pos
        best = None
        for (sx, sy, idx, i, j) in pts:
            px = mn[0] + (mx[0] - mn[0]) * i / max(1, cx - 1)
            py = mn[1] + (mx[1] - mn[1]) * j / max(1, cy - 1)
            d = (px - hx) ** 2 + (py - hy) ** 2
            if best is None or d < best[0]:
                best = (d, idx)
        return best[1] if best else -1

    def _mesh_point_ops(self, ops, sx, sy, idx, mk, done):
        # clear the cell first (the marker is bigger than a dot)
        ops.append(lambda sx=sx, sy=sy: self.cmd_rect.send(
            [sx - 13, sy - 13, 26, 26, COL_BG]))
        if idx == mk:
            # point being probed: white circle with a black square in it
            ops.append(lambda sx=sx, sy=sy: self._bmp_at(
                EXTRA_ICONS['dot22'], sx - 11, sy - 11, COL_WHITE, COL_BG,
                ('dot22', 0)))
            ops.append(lambda sx=sx, sy=sy: self.cmd_rect.send(
                [sx - 5, sy - 5, 10, 10, 0x0000]))
        elif idx <= done:
            ops.append(lambda sx=sx, sy=sy: self._bmp_at(
                EXTRA_ICONS['dot16'], sx - 8, sy - 8, COL_ERR, COL_BG,
                ('dot16', 0)))
        else:
            ops.append(lambda sx=sx, sy=sy: self._bmp_at(
                EXTRA_ICONS['ring16'], sx - 8, sy - 8, COL_ACTIVE, COL_BG,
                ('ring16', 0)))

    def _mesh_progress_ops(self, ops, done, total):
        y = self.MESH_Y0 + 60 * 3 + 24
        ops.append(lambda y=y: self.cmd_rect.send(
            [self.RAIL_W + 16, y, 168, 16, COL_BG]))
        lab = "Point %d / %d" % (done + 1, total)
        ops.append(lambda y=y, lab=lab: self._gui_text(
            self.RAIL_W + 16, y, lab, COL_WHITE, COL_BG, 1))

    def _mesh_temp_state(self, eventtime):
        try:
            ex = self.printer.lookup_object('extruder').get_status(eventtime)
            bd = self.printer.lookup_object('heater_bed').get_status(eventtime)
        except Exception:
            return None
        return tuple(("%d/%d" % (st['temperature'], st['target']),
                      self._temp_color(st['temperature'], st['target']))
                     for st in (ex, bd))

    def _mesh_temp_ops(self, ops, eventtime):
        tv = self._mesh_temp_state(eventtime)
        if tv is None:
            return
        tx = self.width - 202
        for k, (icon, (lbl, col)) in enumerate(zip(('nozzle', 'bed'), tv)):
            ty = self.TOP_H + 44 + k * 36
            ico = self._icon_at(icon, 22)
            ops.append(lambda tx=tx, ty=ty: self.cmd_rect.send(
                [tx, ty, 104, 24, COL_BG]))
            ops.append(lambda i=ico, tx=tx, ty=ty, c=col, ic=icon:
                       self._draw_bmp(i, tx, ty, c, COL_BG, ('mticon', ic, 22)))
            ops.append(lambda tx=tx, ty=ty, c=col, s=lbl: self._gui_text(
                tx + 30, ty + 3, s, c, COL_BG, 1))
        self._mesh_ltv = tv

    def _mesh_btns(self):
        bw, bh = 104, 88
        y = self.TOP_H + 156
        x0 = self.width - 2 * bw - 20
        return [(x0, y, bw, bh, 'start'), (x0 + bw + 12, y, bw, bh, 'cancel')]

    def _mesh_adj_btn(self):
        return (self.width - 228, self.TOP_H + 108, 220, 42)

    def _mesh_btn_ops(self, ops, eventtime):
        running = self._mesh_run > 0
        armed = running and eventtime < self._mesh_arm
        # manual point adjustment (only when the printer is not leveling)
        ax, ay, aw, ah = self._mesh_adj_btn()
        alab, afg, abg = (("ADJUST", COL_DIM, self.gui_btn_bg) if running
                          else ("ADJUST", COL_WHITE, self.gui_btn_bg))
        ops.append(lambda ax=ax, ay=ay, aw=aw, ah=ah, abg=abg:
                   self._gui_round(ax, ay, aw, ah, abg))
        ops.append(lambda ax=ax, ay=ay, aw=aw, afg=afg, abg=abg:
                   self._gui_icon_at('cog', ax + 12, ay + 7, afg, abg, 28))
        ops.append(lambda ax=ax, ay=ay, aw=aw, ah=ah, alab=alab, afg=afg,
                   abg=abg: self._gui_text_center(
                       ax, aw, ay + (ah - 16) // 2, alab, afg, abg, 1))
        for (x, y, w, h, kind) in self._mesh_btns():
            if kind == 'start':
                icon = 'play48'
                lab, fg, bg = "START", (COL_DIM if running else COL_WHITE), \
                    self.gui_btn_bg
            else:
                icon = 'x48'
                lab = ("CONFIRM" if armed else "ABORT") \
                    if running else "CANCEL"
                fg, bg = COL_WHITE, self.gui_btn_bg
            ops.append(lambda x=x, y=y, w=w, h=h, bg=bg: self._gui_round(
                x, y, w, h, bg))
            ops.append(lambda x=x, y=y, w=w, icon=icon, fg=fg, bg=bg:
                       self._gui_icon_at(icon, x + (w - 44) // 2, y + 8,
                                         fg, bg, 44))
            ops.append(lambda x=x, y=y, w=w, h=h, lab=lab, fg=fg, bg=bg:
                       self._gui_text_center(x, w, y + h - 36, lab, fg, bg, 1))
            acc = COL_OK if kind == 'start' else COL_ERR
            ops.append(lambda x=x, y=y, w=w, h=h, acc=acc: self.cmd_rect.send(
                [x + 10, y + h - 12, w - 20, 5, acc]))
        self._mesh_lbr = (running, armed)

    def _mesh_view_ops(self, ops, eventtime):
        # Full draw of the leveling screen.
        mn, mx, cx, cy = self._mesh_geo()
        pts = self._mesh_pts(mn, mx, cx, cy)
        mk = self._mesh_marker(pts, mn, mx, cx, cy, eventtime)
        if mk > self._mesh_done:
            self._mesh_done = mk
        done = self._mesh_done
        ops.append(lambda: self._gui_text_center(
            self.width - 224, 216, self.TOP_H + 12, "CHECK THE NOZZLE",
            COL_WARN, COL_BG, 1))
        ops.append(lambda: self._gui_text_center(
            self.width - 224, 216, self.TOP_H + 30, "IS DIRTY (CLEAN FIRST)",
            COL_WARN, COL_BG, 1))
        for (sx, sy, idx, i, j) in pts:
            self._mesh_point_ops(ops, sx, sy, idx, mk, done)
        self._mesh_progress_ops(ops, done, len(pts))
        self._mesh_temp_ops(ops, eventtime)
        self._mesh_btn_ops(ops, eventtime)
        self._mesh_lmk, self._mesh_ldone = mk, done

    def _mesh_forget(self):
        # The last redraw was dropped halfway: next update redraws everything.
        self._mesh_lmk = 0x7FFFFFFF
        self._mesh_ldone = 0x7FFFFFFF
        self._mesh_ltv = None
        self._mesh_lbr = None

    def _mesh_update(self, eventtime):
        # Incremental redraw: only the points/temps that actually changed, so
        # the panel does not flicker while leveling.
        mn, mx, cx, cy = self._mesh_geo()
        pts = self._mesh_pts(mn, mx, cx, cy)
        mk = self._mesh_marker(pts, mn, mx, cx, cy, eventtime)
        done = self._mesh_done
        if mk > done:
            done = mk
        ops = []
        lmk, ldone = self._mesh_lmk, self._mesh_ldone
        changed = set()
        if lmk != mk:
            if 0 <= lmk:
                changed.add(lmk)
            if 0 <= mk:
                changed.add(mk)
        if done > ldone:
            for k in range(max(0, ldone + 1), done + 1):
                changed.add(k)
        elif done < ldone:
            for k in range(max(0, done + 1), ldone + 1):
                changed.add(k)
        for (sx, sy, idx, i, j) in pts:
            if idx in changed:
                self._mesh_point_ops(ops, sx, sy, idx, mk, done)
        if done != ldone:
            self._mesh_progress_ops(ops, done, len(pts))
        tv = self._mesh_temp_state(eventtime)
        if tv is not None and tv != self._mesh_ltv:
            self._mesh_temp_ops(ops, eventtime)
        running = self._mesh_run > 0
        if (running, running and eventtime < self._mesh_arm) != self._mesh_lbr:
            self._mesh_btn_ops(ops, eventtime)
        self._mesh_done = done
        self._mesh_lmk, self._mesh_ldone = mk, done
        if ops:
            self._gui_enqueue(ops)

    # --- manual mesh point adjustment -------------------------------------
    def _adj_geo(self):
        m = self._adj_cur
        if not m or not m[0]:
            return 0, 0
        return len(m[0]), len(m)

    def _adj_pts(self):
        cols, rows = self._adj_geo()
        _, _, cx, cy = self._mesh_geo()
        cx_n, cy_n = cols or cx, rows or cy
        out = []
        for j in range(cy_n):
            for i in range(cx_n):
                sx = self.ADJ_X0 + int(i * self.ADJ_SPAN / max(1, cx_n - 1))
                sy = self.ADJ_Y0 + int((cy_n - 1 - j) * self.ADJ_SPAN
                                       / max(1, cy_n - 1))
                out.append((sx, sy, i, j))
        return out

    def _adj_xy(self, i, j):
        cols, rows = self._adj_geo()
        mn, mx, cx, cy = self._mesh_geo()
        cx_n, cy_n = cols or cx, rows or cy
        return (mn[0] + (mx[0] - mn[0]) * i / max(1, cx_n - 1),
                mn[1] + (mx[1] - mn[1]) * j / max(1, cy_n - 1))

    def _adj_mesh(self):
        try:
            bm = self.printer.lookup_object('bed_mesh')
            return bm, bm.get_mesh()
        except Exception:
            return None, None

    def _adj_dirty(self):
        for j, row in enumerate(self._adj_cur):
            for i, v in enumerate(row):
                if abs(v - self._adj_orig[j][i]) > 1e-9:
                    return True
        return False

    def _adj_open(self, eventtime):
        _, mesh = self._adj_mesh()
        try:
            m = mesh.get_probed_matrix() if mesh is not None else None
        except Exception:
            m = None
        if not m or not m[0]:
            self._gui_warn("No bed mesh - run Auto Level first")
            return
        self._adj_orig = [list(r) for r in m]
        self._adj_cur = [list(r) for r in m]
        cols, rows = self._adj_geo()
        self._adj_i, self._adj_j = (cols - 1) // 2, (rows - 1) // 2
        self._adj_delta = 0.
        self._adj_at = False
        self._adj_forget()
        self.gui_screen = 'meshadj'
        self.gcode.respond_info("GUI ajuste da malha %dx%d (ponto %d,%d)"
                                % (cols, rows, self._adj_i + 1,
                                   self._adj_j + 1))
        self._gui_render(eventtime)

    def _adj_forget(self):
        self._adj_lstate = None
        self._adj_lval = None
        self._adj_lstep = None
        self._adj_lsave = None

    def _adj_apply(self):
        bm, mesh = self._adj_mesh()
        if mesh is None:
            return
        try:
            mesh.build_mesh([list(r) for r in self._adj_cur])
            bm.set_mesh(mesh)
        except Exception:
            logging.exception("st7796: falha ao aplicar o ajuste da malha")

    def _adj_move(self, i, j, eventtime):
        self._adj_i, self._adj_j = i, j
        self._adj_delta = self._adj_cur[j][i] - self._adj_orig[j][i]
        x, y = self._adj_xy(i, j)
        self._adj_at = True
        # Up, over, then down to the mesh surface for that point.
        self.gcode.respond_info("GUI ajuste: ponto %d,%d -> X%.1f Y%.1f"
                                % (i + 1, j + 1, x, y))
        self._gui_run_action(
            "G90\nG1 Z3 F600\nG1 X%.2f Y%.2f F3000\nG1 Z0 F150" % (x, y))
        self._adj_forget()

    def _adj_nudge(self, sign, eventtime):
        if not self._adj_at:
            self._gui_warn("Tap a grid point first")
            return
        step = self.ADJ_STEPS[self._adj_step_i] * sign
        j, i = self._adj_j, self._adj_i
        d = max(-1.0, min(1.0, self._adj_delta + step))
        if abs(d - self._adj_delta) < 1e-9:
            self._gui_warn("Adjustment limit (+/-1.0mm)")
            return
        self._adj_delta = d
        self._adj_cur[j][i] = self._adj_orig[j][i] + d
        self._adj_apply()
        self.gcode.respond_info("GUI ajuste (%d,%d) %+.3f" % (i + 1, j + 1, d))
        # Re-issue Z0: the nozzle moves by exactly the correction.
        self._gui_run_action("G1 Z0 F180")
        self._adj_forget()

    def _adj_save(self, eventtime):
        if not self._adj_dirty():
            self._gui_warn("Nothing to save")
            return
        self._gui_msg = "A gravar a malha da cama (SAVE_CONFIG)..."
        self._gui_msg_until = self.printer.get_reactor().monotonic() + 60.
        self.gcode.respond_info("GUI: gravar a malha ajustada")
        self._gui_run_action("BED_MESH_PROFILE SAVE=default\nSAVE_CONFIG")
        self._adj_forget()

    def _adj_point_ops(self, ops, sx, sy, i, j, sel):
        ops.append(lambda sx=sx, sy=sy: self.cmd_rect.send(
            [sx - 22, sy - 22, 44, 44, COL_BG]))
        adj = abs(self._adj_cur[j][i] - self._adj_orig[j][i]) > 1e-9
        if sel:
            ops.append(lambda sx=sx, sy=sy: self._bmp_at(
                EXTRA_ICONS['dot22'], sx - 11, sy - 11, COL_WHITE, COL_BG,
                ('dot22', 0)))
            ops.append(lambda sx=sx, sy=sy: self.cmd_rect.send(
                [sx - 5, sy - 5, 10, 10, 0x0000]))
        elif adj:
            ops.append(lambda sx=sx, sy=sy: self._bmp_at(
                EXTRA_ICONS['dot16'], sx - 8, sy - 8, COL_ERR, COL_BG,
                ('dot16', 0)))
        else:
            ops.append(lambda sx=sx, sy=sy: self._bmp_at(
                EXTRA_ICONS['ring16'], sx - 8, sy - 8, COL_ACTIVE, COL_BG,
                ('ring16', 0)))

    def _adj_state(self):
        st = {}
        if not self._adj_cur or not self._adj_cur[0]:
            return st
        for (sx, sy, i, j) in self._adj_pts():
            if i == self._adj_i and j == self._adj_j:
                st[(i, j)] = 'sel'
            elif abs(self._adj_cur[j][i] - self._adj_orig[j][i]) > 1e-9:
                st[(i, j)] = 'adj'
            else:
                st[(i, j)] = 'plain'
        return st

    def _adj_info_ops(self, ops):
        x, y = self._adj_xy(self._adj_i, self._adj_j)
        ops.append(lambda: self.cmd_rect.send([36, 30, 212, 114, COL_BG]))
        ops.append(lambda: self._gui_text(42, 34, "ADJUST", COL_ACTIVE,
                                          COL_BG, 1))
        ops.append(lambda: self._gui_text(
            42, 52, "POINT %d,%d" % (self._adj_i + 1, self._adj_j + 1),
            COL_WHITE, COL_BG, 1))
        ops.append(lambda x=x, y=y: self._gui_text(
            42, 68, "X%.0f  Y%.0f" % (x, y), COL_ACTIVE, COL_BG, 1))
        lab = "%+.3f" % self._adj_delta
        col = COL_OK if abs(self._adj_delta) < 1e-9 else COL_WARN
        ops.append(lambda lab=lab, col=col: self._gui_text(
            42, 90, lab, col, COL_BG, 3))
        self._adj_lval = (self._adj_i, self._adj_j, self._adj_delta)

    def _adj_pm_ops(self, ops):
        ops.append(lambda: self._gui_text(42, 208, "STEP", COL_ACTIVE,
                                          COL_BG, 1))
        for (x, icon) in ((40, 'down'), (144, 'up')):
            bg = self.gui_btn_bg
            ops.append(lambda x=x, bg=bg: self._gui_round(x, 146, 96, 52, bg))
            iw = (self._icon_at(icon, 34) or (0, 0))[0]
            ops.append(lambda x=x, icon=icon, iw=iw, bg=bg:
                       self._gui_icon_at(icon, x + (96 - iw) // 2, 155,
                                         COL_WHITE, bg, 34))

    def _adj_step_ops(self, ops):
        for k, val in enumerate(self.ADJ_STEPS):
            x = 40 + k * 70
            sel = (k == self._adj_step_i)
            bg = self.gui_btn_bg
            fg = COL_WHITE if sel else COL_ACTIVE
            lab = "%g" % val
            ops.append(lambda x=x, bg=bg: self._gui_round(x, 224, 66, 44, bg))
            ops.append(lambda x=x, lab=lab, fg=fg, bg=bg:
                       self._gui_text_center(x, 66, 238, lab, fg, bg, 1))
            if sel:
                ops.append(lambda x=x: self.cmd_rect.send(
                    [x + 6, 260, 54, 4, COL_OK]))
        self._adj_lstep = self._adj_step_i

    def _adj_save_ops(self, ops):
        x, y, w, h = 256, 244, 214, 36
        dirty = self._adj_dirty()
        bg = self.gui_btn_bg
        fg = COL_WHITE if dirty else COL_DIM
        iw = (self._icon_at('save', 24) or (0, 0))[0]
        ops.append(lambda x=x, y=y, w=w, h=h, bg=bg: self._gui_round(
            x, y, w, h, bg))
        ops.append(lambda x=x, y=y, iw=iw, fg=fg, bg=bg: self._gui_icon_at(
            'save', x + 16, y + 6, fg, bg, 24))
        ops.append(lambda x=x, y=y, fg=fg, bg=bg: self._gui_text(
            x + 52, y + 8, "SAVE", fg, bg, 1))
        if dirty:
            ops.append(lambda x=x, y=y, w=w, h=h: self.cmd_rect.send(
                [x + 10, y + h - 8, w - 20, 4, COL_OK]))
        self._adj_lsave = dirty

    def _adj_view_ops(self, ops, eventtime):
        st = self._adj_state()
        for (sx, sy, i, j) in self._adj_pts():
            self._adj_point_ops(ops, sx, sy, i, j, st[(i, j)] == 'sel')
        self._adj_info_ops(ops)
        self._adj_pm_ops(ops)
        self._adj_step_ops(ops)
        self._adj_save_ops(ops)
        self._adj_lstate = st

    def _adj_update(self, eventtime):
        # only redraw what changed - a full repaint would flicker
        ops = []
        st = self._adj_state()
        old = self._adj_lstate or {}
        for (sx, sy, i, j) in self._adj_pts():
            if old.get((i, j)) != st[(i, j)]:
                self._adj_point_ops(ops, sx, sy, i, j, st[(i, j)] == 'sel')
        if (self._adj_i, self._adj_j, self._adj_delta) != self._adj_lval:
            self._adj_info_ops(ops)
        if self._adj_lstep != self._adj_step_i:
            self._adj_step_ops(ops)
        if self._adj_lsave != self._adj_dirty():
            self._adj_save_ops(ops)
        self._adj_lstate = st
        if ops:
            self._gui_enqueue(ops)

    def _adj_tap(self, sx, sy, eventtime):
        if not self._adj_cur or not self._adj_cur[0]:
            return False
        best = None
        for (px, py, i, j) in self._adj_pts():
            d = max(abs(sx - px), abs(sy - py))
            if d <= 22 and (best is None or d < best[0]):
                best = (d, i, j)
        if best is not None:
            self._adj_move(best[1], best[2], eventtime)
            return True
        if 40 <= sx < 136 and 146 <= sy < 198:
            self._adj_nudge(-1, eventtime)
            return True
        if 144 <= sx < 240 and 146 <= sy < 198:
            self._adj_nudge(1, eventtime)
            return True
        for k in range(len(self.ADJ_STEPS)):
            x = 40 + k * 70
            if x <= sx < x + 66 and 224 <= sy < 268:
                self._adj_step_i = k
                self.gcode.respond_info("GUI passo %g" % self.ADJ_STEPS[k])
                self._adj_update(eventtime)
                return True
        if 256 <= sx < 470 and 244 <= sy < 280:
            self._adj_save(eventtime)
            return True
        return False

    # --- object preview (slicer thumbnail) ---------------------------------
    PREVIEW_SIZE = 168
    PREVIEW_SHOW_S = 8.

    def _sdcard_path(self):
        try:
            p = self.printer.lookup_object(
                'virtual_sdcard').get_status(0).get('file_path')
            return p if p and os.path.exists(p) else None
        except Exception:
            return None

    def _preview_start(self, eventtime):
        # A print (re)started: decode the thumbnail in the background.
        path = self._sdcard_path()
        if not path or path == self._prev_file:
            return
        self._prev_file = path
        self._prev_bits = None
        self._prev_toggle = False
        self._prev_until = eventtime + self.PREVIEW_SHOW_S
        try:
            threading.Thread(target=self._preview_worker, args=(path,),
                             daemon=True).start()
            logging.info("st7796: preview de %s a ser preparado",
                         os.path.basename(path))
        except Exception:
            logging.exception("st7796: nao consegui lancar o preview")

    def _preview_worker(self, path):
        try:
            bw, bh, bits = tft_thumb.thumbnail_bitmap(path,
                                                      self.PREVIEW_SIZE)
        except Exception:
            logging.exception("st7796: falha ao ler o thumbnail")
            return
        if not bits or bw != self.PREVIEW_SIZE:
            logging.info("st7796: %s sem thumbnail utilizavel",
                         os.path.basename(path))
            return
        try:
            st = os.stat(path)
            key = (os.path.basename(path), int(st.st_mtime), int(st.st_size))
        except Exception:
            key = (path, 0, 0)
        self._prev_bits = (bits, bw, bh)
        self._prev_pending = True
        self._prev_key = hash(key) & 0x7FFFFFFF
        logging.info("st7796: preview pronto (%dx%d)", bw, bh)

    def _preview_drop_cache(self):
        # A new preview means the MCU icon pool must be reset, otherwise the
        # per-preview bitmaps pile up (the pool is only 24 KiB).
        if self.cmd_ireset is None:
            return
        try:
            self.cmd_ireset.send([])
            self._ic_ids = {}
            self._ic_bytes = 0
        except Exception:
            logging.exception("st7796: tft_ireset falhou")

    def _preview_active(self, eventtime):
        if not self._prev_bits:
            return False
        if self._prev_toggle:
            return True
        return 0. < self._prev_until and eventtime < self._prev_until

    def _preview_rect(self):
        x = self.RAIL_W + 24
        return (x, self.TOP_H + 8, self.PREVIEW_SIZE, self.PREVIEW_SIZE)

    def _prev_show(self):
        # The preview is always on while printing (no toggle any more).
        return bool(self._prev_bits)

    def _row_ops(self, ops, x, y, w, h, key, eventtime):
        it = POPUP_ITEMS[key]
        val, col = self._panel_value(key, eventtime)
        ops.append(lambda x=x, y=y, w=w, col=col: self.cmd_rect.send(
            [x - 6, y, w + 6, h, COL_BG]))
        ops.append(lambda x=x, y=y, h=h, col=col: self.cmd_rect.send(
            [x, y + 4, 6, h - 8, col]))
        ops.append(lambda x=x, y=y, it=it: self._gui_text(
            x + 14, y + 6, (it['name'] + ' ' * 12)[:12], COL_WHITE, COL_BG,
            1))
        if val:
            ops.append(lambda x=x, y=y, w=w, val=val, col=col:
                       self._gui_text(x + w - len(val) * 8, y + 6, val, col,
                                      COL_BG, 1))
        self._card_cols[key] = (val, col)

    def _print_3col_ops(self, ops, eventtime, values_only=False):
        x, y, w, h = self._print_img_rect()
        ops.append(lambda x=x, y=y, w=w, h=h: self.cmd_rect.send(
            [x, y, w, h, COL_BG]))
        if self._prev_bits:
            bits, bw, bh = self._prev_bits
            bx = x + max(0, (w - bw) // 2)
            by = y + max(0, (h - bh) // 2)
            ops.append(lambda bx=bx, by=by, bits=bits, bw=bw, bh=bh:
                       self._bmp_at((bw, bh, bits), bx, by, COL_PREVIEW,
                                    COL_BG, ('prev', self._prev_key)))
        else:
            ops.append(lambda x=x, y=y, w=w, h=h: self.cmd_rect.send(
                [x, y + h // 2 - 1, w, 1, COL_DIM]))
            ops.append(lambda x=x, y=y, w=w: self._gui_text_center(
                x, w, y + h // 2 + 6, "no preview", COL_DIM, COL_BG, 1))
        # middle column: the info list
        for (rx, ry, rw, rh, key) in self._print_list_rows():
            if values_only:
                it = POPUP_ITEMS[key]
                val, col = self._panel_value(key, eventtime)
                if self._card_cols.get(key) == (val, col):
                    continue
            self._row_ops(ops, rx, ry, rw, rh, key, eventtime)
        # progress bar + position under the image
        prog = 0.
        try:
            prog = float(self.printer.lookup_object(
                'virtual_sdcard').get_status(eventtime).get('progress') or 0.)
        except Exception:
            prog = 0.
        if not prog:
            try:
                prog = float(self._print_status(eventtime).get('progress')
                             or 0.)
            except Exception:
                prog = 0.
        prog = min(1., max(0., prog))
        px, py, pw, ph = self._print_bar_rect()
        n = max(4, pw // 8 - 2)
        f = int(round(prog * n))
        bx0 = px + (pw - n * 8) // 2
        if f > 0:
            ops.append(lambda bx0=bx0, py=py, f=f: self._gui_text(
                bx0, py, "\xdb" * f, COL_C1, COL_BG, 1))
        if n - f > 0:
            ops.append(lambda bx0=bx0, py=py, f=f, n=n: self._gui_text(
                bx0 + f * 8, py, "\xb0" * (n - f), COL_ACTIVE, COL_BG, 1))
        pct = "%d%%" % int(round(prog * 100))
        ops.append(lambda bx0=bx0, py=py, n=n, pct=pct: self._gui_text(
            bx0 + max(0, (n * 8 - len(pct) * 8) // 2), py, pct, COL_WHITE,
            COL_BG, 1))
        try:
            gp = self.printer.lookup_object(
                'gcode_move').get_status(eventtime)['gcode_position']
            parts = (("X%.1f" % float(gp[0]), COL_AXIS_X),
                     ("Y%.1f" % float(gp[1]), COL_AXIS_Y),
                     ("Z%.1f" % float(gp[2]), COL_AXIS_Z))
        except Exception:
            parts = (("X-", COL_AXIS_X), ("Y-", COL_AXIS_Y),
                     ("Z-", COL_AXIS_Z))
        ps = self._print_status(eventtime) or {}
        info = ps.get('info') or {}
        lay, tot = info.get('current_layer'), info.get('total_layer')
        ltxt = ("LAYER %s/%s" % (lay, tot)) if lay else ""
        dur = ps.get('print_duration') or 0
        ttxt = "TIME %d:%02d" % (dur // 3600, (dur // 60) % 60)
        ly = py + 22
        tx = px
        for txt, col in parts:
            ops.append(lambda tx=tx, ly=ly, txt=txt, col=col:
                       self._gui_text(tx, ly, txt, col, COL_BG, 1))
            tx += len(txt) * 8 + 4
        ops.append(lambda px=px, ly=ly, ttxt=ttxt: self._gui_text(
            px, ly + 18, ttxt, COL_ACTIVE, COL_BG, 1))
        left = self._eta_left(eventtime)
        # estimated wall-clock finish, next to the position
        if left is not None:
            try:
                etxt = time.strftime(
                    'ENDS %H:%M', time.localtime(time.time() + left))
            except Exception:
                etxt = None
            if etxt:
                ops.append(lambda etxt=etxt: self._gui_text(
                    px + 156, ly, etxt, COL_C4, COL_BG, 1))
        # time / left / layer on the second line
        mx = px + 80
        my = ly + 18
        if left is not None:
            ftxt = "LEFT %d:%02d" % (int(left) // 3600,
                                      (int(left) // 60) % 60)
            ops.append(lambda mx=mx, my=my, ftxt=ftxt: self._gui_text(
                mx, my, ftxt, COL_WARN, COL_BG, 1))
        if ltxt:
            ops.append(lambda px=px, my=my, ltxt=ltxt: self._gui_text(
                px + 160, my, ltxt, COL_C3, COL_BG, 1))

    # --- Avancadas / Limites: 2x2 cards + GRAVAR ---------------------------
    def _card_rects(self):
        x0, y0 = self.RAIL_W + 8, self.TOP_H + 8
        w = (self.width - x0 - 16) // 2
        h = (self.height - self.STRIP_H - y0 - 8 - 38) // 2
        return [(x0 + (i % 2) * (w + 8), y0 + (i // 2) * (h + 8), w, h)
                for i in range(4)]

    def _cards_save_rect(self):
        x0 = self.RAIL_W + 8
        return (x0, self.height - self.STRIP_H - 38,
                self.width - x0 - 16, 30)

    def _big_card_ops(self, ops, x, y, w, h, key, idx, eventtime):
        it = POPUP_ITEMS[key]
        val = self._key_value(key, eventtime)
        col = self._gc(idx)
        ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
            x, y, w, h, self.gui_btn_bg))
        ico = self._icon_at(it['icon'], 34)
        ops.append(lambda ico=ico, x=x, y=y, h=h, col=col, ic=it['icon']:
                   self._draw_bmp(ico, x + 14, y + (h - 34) // 2, col,
                                  self.gui_btn_bg, ('mticon', ic, 34)))
        name = it['name'] + ((" " + it['units']) if it.get('units') else "")
        ops.append(lambda x=x, y=y, name=name: self._gui_text(
            x + 60, y + 20, name, COL_ACTIVE, self.gui_btn_bg, 1))
        lab = self._fmt_val(it, val)
        ops.append(lambda x=x, y=y, lab=lab, col=col: self._gui_text(
            x + 60, y + 44, lab, col, self.gui_btn_bg, 2))
        ops.append(lambda x=x, y=y, w=w, h=h, col=col: self.cmd_rect.send(
            [x + 12, y + h - 12, w - 24, 5, col]))

    def _cards_save_ops(self, ops, keys):
        x, y, w, h = self._cards_save_rect()
        ready = any(k in _SAVE_MAP for k in keys)
        bg = self.gui_btn_bg
        fg = COL_WHITE if ready else COL_DIM
        iw = (self._icon_at('save', 20) or (0, 0))[0]
        ops.append(lambda x=x, y=y, w=w, h=h, bg=bg: self._gui_round(
            x, y, w, h, bg))
        ops.append(lambda x=x, y=y, iw=iw, fg=fg, bg=bg: self._gui_icon_at(
            'save', x + 14, y + 5, fg, bg, 20))
        ops.append(lambda x=x, y=y, fg=fg, bg=bg: self._gui_text(
            x + 44, y + 7, "SAVE to printer.cfg", fg, bg, 1))

    def _cards_view_ops(self, ops, keys, eventtime):
        if self._popup is not None:
            # modal: the adjustment panel takes over the cards area
            ops.append(lambda: self.cmd_rect.send(
                [self.RAIL_W, self.TOP_H, self.width - self.RAIL_W,
                 self.height - self.TOP_H - self.STRIP_H, COL_BG]))
            self._popup_view_ops(ops, eventtime)
            return
        for i, (x, y, w, h) in enumerate(self._card_rects()):
            if i < len(keys):
                self._big_card_ops(ops, x, y, w, h, keys[i], i, eventtime)
        self._cards_save_ops(ops, keys)

    def _cards_save(self, keys, eventtime):
        cf = self.printer.lookup_object('configfile')
        n = 0
        for k in keys:
            ent = _SAVE_MAP.get(k)
            if ent is None:
                continue
            v = self._key_value(k, eventtime)
            if v is None:
                continue
            cf.set(ent[0], ent[1], ent[2] % v)
            n += 1
        if not n:
            self._gui_warn("Nothing to save here")
            return
        self._gui_msg = "A gravar %d valores - SAVE_CONFIG..." % n
        self._gui_msg_until = self.printer.get_reactor().monotonic() + 60.
        self.gcode.respond_info("GUI: a gravar %d valores no printer.cfg" % n)
        self._gui_run_action("SAVE_CONFIG")

    def _cards_tap(self, sx, sy, keys, eventtime):
        if self._popup is not None:
            self._popup_tap(sx, sy, eventtime)
            return True
        for i, (x, y, w, h) in enumerate(self._card_rects()):
            if i < len(keys) and x <= sx < x + w and y <= sy < y + h:
                self.gcode.respond_info("GUI: ajuste %s"
                                        % POPUP_ITEMS[keys[i]]['name'])
                self._popup_open(keys[i], eventtime)
                return True
        x, y, w, h = self._cards_save_rect()
        if x <= sx < x + w and y <= sy < y + h:
            self._cards_save(keys, eventtime)
            return True
        return False

    # --- inline adjustment panel (drawn where the info tiles are) --------
    def _baby_load(self):
        try:
            with open(self._baby_file) as f:
                self._baby_saved = float(f.read().strip() or 0.)
        except Exception:
            self._baby_saved = 0.
        return self._baby_saved

    def _baby_store(self, val):
        try:
            with open(self._baby_file, 'w') as f:
                f.write("%.4f\n" % val)
            self._baby_saved = val
            return True
        except Exception:
            logging.exception("st7796: could not save baby step")
            return False

    def _baby_apply_saved(self):
        if abs(self._baby_saved) < 0.0005:
            return
        script = "SET_GCODE_OFFSET Z=%.4f" % self._baby_saved
        self.gcode.respond_info("GUI: aplicar baby step guardado (%s)"
                                % script)
        self._gui_run_action(script)

    def _popup_state(self):
        return POPUP_ITEMS.get(self._popup)

    def _popup_area(self):
        # Keep clear of the right hand button column (132px + margin).
        x0 = self.RAIL_W + 2
        y0 = self.TOP_H + 2
        return x0, y0, (self.width - 148) - x0, 2 * 104

    def _read_kind(self, it, eventtime):
        k = it['kind']
        try:
            if k == 'temp':
                return float(self.printer.lookup_object(
                    it['src']).get_status(eventtime)['target'])
            if k == 'factor':
                gm = self.printer.lookup_object(
                    'gcode_move').get_status(eventtime)
                return float(gm.get(it['key']) or 1.) * 100.
            if k == 'fan':
                return float(self.printer.lookup_object('fan').get_status(
                    eventtime).get('speed') or 0.) * 100.
            if k == 'baby':
                gp = self.printer.lookup_object(
                    'gcode_move').get_status(eventtime)['gcode_position']
                return float(gp[2]) - self._baby_base
            if k in ('pa', 'smooth'):
                st = self.printer.lookup_object('extruder').get_status(
                    eventtime)
                return float(st.get('pressure_advance' if k == 'pa'
                                    else 'smooth_time') or 0.)
            if k in ('shx', 'shy'):
                st = self.printer.lookup_object('input_shaper').get_status(
                    eventtime)
                return float(st.get('shaper_freq_x' if k == 'shx'
                                    else 'shaper_freq_y') or 0.)
            if k in _LIM_MAP:
                st = self.printer.lookup_object('toolhead').get_status(
                    eventtime)
                return float(st.get(_LIM_MAP[k][0]) or 0.)
        except Exception:
            return None
        return None

    def _popup_read(self, eventtime):
        it = self._popup_state()
        if it is None:
            return None
        return self._read_kind(it, eventtime)

    def _key_value(self, key, eventtime):
        it = POPUP_ITEMS.get(key)
        return None if it is None else self._read_kind(it, eventtime)

    def _fmt_val(self, it, val):
        if it is None or val is None:
            return "-"
        k = it['kind']
        if k == 'baby':
            return "%+.3f" % val
        if k == 'temp':
            return "%d" % round(val)
        if k in ('factor', 'fan'):
            return "%d%%" % round(val)
        dec = it.get('dec', 3)
        return ("%%.%df%%s" % dec) % (val, it.get('units', ''))

    def _popup_fmt(self, val):
        return self._fmt_val(self._popup_state(), val)

    def _popup_apply(self, val):
        it = self._popup_state()
        if it is None or val is None:
            return None
        k = it['kind']
        if k == 'temp':
            return ("M104 S%d" if it['src'] == 'extruder'
                    else "M140 S%d") % round(val)
        if k == 'factor':
            return ("M221 S%d" if it['key'] == 'extrude_factor'
                    else "M220 S%d") % round(val)
        if k == 'fan':
            return "M106 S%d" % int(round(val * 255. / 100.))
        if k == 'baby':
            return "SET_GCODE_OFFSET Z_ADJUST=%+.3f MOVE=1" % val
        try:
            if k in ('pa', 'smooth'):
                st = self.printer.lookup_object('extruder').get_status(0)
                pa = float(st.get('pressure_advance') or 0.)
                sm = float(st.get('smooth_time') or 0.)
                if k == 'pa':
                    pa += val
                else:
                    sm += val
                self._popup_val = pa if k == 'pa' else sm
                return ("SET_PRESSURE_ADVANCE ADVANCE=%.4f SMOOTH_TIME=%.4f"
                        % (pa, sm))
            if k in ('shx', 'shy'):
                st = self.printer.lookup_object(
                    'input_shaper').get_status(0)
                key = 'shaper_freq_x' if k == 'shx' else 'shaper_freq_y'
                f = float(st.get(key) or 0.) + val
                self._popup_val = f
                return "SET_INPUT_SHAPER SHAPER_FREQ_%s=%.1f" % (
                    'X' if k == 'shx' else 'Y', f)
            if k in _LIM_MAP:
                skey, arg = _LIM_MAP[k]
                st = self.printer.lookup_object('toolhead').get_status(0)
                v = float(st.get(skey) or 0.) + val
                self._popup_val = v
                return "SET_VELOCITY_LIMIT %s=%.4f" % (arg, v)
        except Exception:
            logging.exception("st7796: falha a aplicar %s", k)
        return None

    def _popup_btns(self):
        # [-][+][step][OK|Save] across the lower half of the panel area
        x0, y0, w, h = self._popup_area()
        bw = (w - 5 * 8) // 4
        bh = 54
        by = y0 + h - bh - 8
        kinds = ('minus', 'plus', 'step', 'save' if self._popup_save
                 else 'ok')
        return [(x0 + 8 + i * (bw + 8), by, bw, bh, k)
                for i, k in enumerate(kinds)]

    def _popup_view_ops(self, ops, eventtime):
        it = self._popup_state()
        if it is None:
            return
        x0, y0, w, h = self._popup_area()
        iw = (self._icon_at(it['icon'], 44) or (0, 0))[0]
        ops.append(lambda iw=iw: self._gui_icon_at(
            it['icon'], x0 + 14, y0 + 14, COL_WHITE, COL_BG, 44))
        ops.append(lambda: self._gui_text(x0 + 74, y0 + 18, it['name'],
                                          COL_WHITE, COL_BG, 1))
        val = self._popup_val if self._popup_val is not None \
            else self._popup_read(eventtime)
        ops.append(lambda val=val: self._gui_text(x0 + 74, y0 + 38,
                                                  self._popup_fmt(val),
                                                  COL_C1, COL_BG, 3))
        if it.get('live'):
            ops.append(lambda: self._gui_text(
                x0 + 74, y0 + 92, "(live - saved %+.3f)"
                % self._baby_saved, COL_DIM, COL_BG, 1))
        for (bx, by, bw, bh, what) in self._popup_btns():
            if what in ('minus', 'plus'):
                self._sign_btn(ops, bx, by, bw, bh,
                               "+" if what == 'plus' else "-",
                               self._gc(0 if what == 'plus' else 1))
            elif what == 'step':
                bg = self.gui_btn_bg
                ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, bg=bg:
                           self._gui_round(bx, by, bw, bh, bg))
                ops.append(lambda bx=bx, bw=bw, by=by, bh=bh, bg=bg:
                           self._gui_text_center(
                               bx, bw, by + (bh - 16) // 2,
                               "%g" % self._popup_step, COL_WHITE, bg, 1))
            else:
                # OK -> check mark (with a green line), Save -> floppy disk
                if what == 'save':
                    icon, bg, acc = 'save', self.gui_btn_bg, COL_OK
                else:
                    icon, bg, acc = 'check', self.gui_btn_bg, COL_OK
                isz = 30
                iw = (self._icon_at(icon, isz) or (0, 0))[0]
                ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, bg=bg:
                           self._gui_round(bx, by, bw, bh, bg))
                ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, icon=icon,
                           bg=bg, isz=isz, iw=iw: self._gui_icon_at(
                               icon, bx + (bw - iw) // 2,
                               by + (bh - isz) // 2, COL_WHITE, bg, isz))
                if acc is not None:
                    ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, acc=acc:
                               self.cmd_rect.send([bx + 10, by + bh - 11,
                                                   bw - 20, 5, acc]))

    def _popup_open(self, key, eventtime):
        it = POPUP_ITEMS.get(key)
        if it is None:
            return
        self._popup = key
        self._popup_step = it['default']
        self._popup_val = None
        self._popup_save = bool(it.get('save'))
        self._popup_applied = 0.
        if it.get('live'):
            try:
                gp = self.printer.lookup_object(
                    'gcode_move').get_status(0)['gcode_position']
                self._baby_base = float(gp[2])
            except Exception:
                self._baby_base = 0.
        self._gui_render(eventtime)

    def _popup_close(self, eventtime, cancel=False):
        it = self._popup_state()
        if cancel and it is not None and it.get('live') and self._popup_applied:
            script = "SET_GCODE_OFFSET Z_ADJUST=%+.3f MOVE=1" % (
                -self._popup_applied)
            self.gcode.respond_info("GUI: cancelar baby step (%s)" % script)
            self._gui_run_action(script)
        self._popup = None
        self._popup_val = None
        self._popup_applied = 0.
        self._gui_render(eventtime)

    def _popup_tap(self, sx, sy, eventtime):
        it = self._popup_state()
        if it is None:
            return False
        for (bx, by, bw, bh, what) in self._popup_btns():
            if not (bx <= sx < bx + bw and by <= sy < by + bh):
                continue
            if what in ('minus', 'plus'):
                sign = 1. if what == 'plus' else -1.
                if it.get('live'):
                    amt = self._popup_step * sign
                    cur = self._popup_val
                    if cur is None:
                        cur = self._popup_read(eventtime)
                    if cur is None or cur + amt < it['lo'] \
                            or cur + amt > it['hi']:
                        return True
                    script = self._popup_apply(amt)
                    self._popup_applied += amt
                    self.gcode.respond_info("GUI %s %+.3f" % (it['name'], amt))
                    self._gui_run_action(script)
                    self._gui_render(eventtime)
                else:
                    cur = self._popup_val
                    if cur is None:
                        cur = self._popup_read(eventtime)
                    if cur is None:
                        return True
                    self._popup_val = max(
                        it['lo'], min(it['hi'], cur + self._popup_step * sign))
                    self._gui_render(eventtime)
                return True
            if what == 'step':
                vals = it['steps']
                if len(vals) > 1:
                    i = vals.index(self._popup_step) \
                        if self._popup_step in vals else 0
                    self._popup_step = vals[(i + 1) % len(vals)]
                    self._gui_render(eventtime)
                return True
            if what == 'ok':
                val = self._popup_val
                if val is not None:
                    script = self._popup_apply(val)
                    if script:
                        self.gcode.respond_info("GUI %s: %s" % (it['name'],
                                                                script))
                        self._gui_run_action(script)
                self._popup_close(eventtime)
                return True
            if what == 'save':
                total = self._baby_saved + self._popup_applied
                ok = self._baby_store(total)
                self._popup_applied = 0.
                self.gcode.respond_info(
                    "GUI: baby step guardado %+.3f (%s) - aplica-se no inicio de"
                    " cada impressao" % (total,
                                         "ok" if ok else "ERRO a gravar"))
                self._gui_msg = "Baby step guardado %+.3f" % total
                self._gui_msg_until = (
                    self.printer.get_reactor().monotonic() + 6.)
                self._popup_close(eventtime)
                return True
        return False

    def _gui_output(self, msg):
        # Klipper prefixes gcode errors with "!!" - keep the last one so it can
        # be shown on the panel.
        try:
            if msg.startswith('!!'):
                self._gui_err = msg[2:].strip()[:56]
                self._gui_err_until = (
                    self.printer.get_reactor().monotonic() + 15.)
                self._gui_next = 0.
        except Exception:
            pass
    def _gui_bottombar(self, eventtime, fill=True):
        bg = self.gui_bar_bg
        y = self.height - self.STRIP_H
        if fill:
            self.cmd_rect.send([0, y, self.width, self.STRIP_H, bg])
        strip = self._gui_strip()
        if strip:
            for (x, yy, w, h, lab, val) in strip:
                sel = isinstance(val, float) and abs(val - self._gui_step) < 1e-6
                bg = COL_ACTIVE if sel else self.gui_btn_bg
                self._gui_round(x, yy, w, h, bg)
                self._gui_text_center(x, w, yy + (h - 16) // 2, lab,
                                      COL_WHITE, bg, 1)
        else:
            msg = ''
            fg = COL_WHITE
            now = self.printer.get_reactor().monotonic()
            if self._gui_err and now < self._gui_err_until:
                msg, fg = "ERRO: " + self._gui_err, COL_ERR
            elif self._gui_msg and now < self._gui_msg_until:
                msg, fg = self._gui_msg, COL_WARN
            else:
                ds = self.printer.lookup_object('display_status', None)
                if ds is not None:
                    msg = ds.get_status(eventtime).get('message', '') or ''
                if not msg:
                    try:
                        ps = self.printer.lookup_object('print_stats', None)
                        if ps is not None:
                            msg = str(ps.get_status(eventtime).get('state',
                                                                   ''))
                    except Exception:
                        msg = ''
            m = str(msg)[:56]
            self._bot_max = max(getattr(self, '_bot_max', 0), len(m))
            self._gui_text_center(0, self.width, y + 9,
                                  (' ' + m.center(self._bot_max + 2) + ' ')
                                  [:(self._bot_max + 4)], fg, bg, 1)
    def _gui_bars(self, eventtime):
        if self._popup is not None:
            return              # modal popup covers everything: leave it alone
        sampled = False
        now = self.printer.get_reactor().monotonic()
        if now - self._t_last >= 2.:
            self._t_last = now
            try:
                e = self.printer.lookup_object('extruder').get_status(
                    eventtime)['temperature']
                b = self.printer.lookup_object('heater_bed').get_status(
                    eventtime)['temperature']
            except Exception:
                e = b = 0.
            self._t_hist.append((e, b))
            if len(self._t_hist) > 60:
                self._t_hist.pop(0)
            sampled = True
        if self._gui_ops:
            return
        if (sampled and self._popup is None and self.gui_screen == 'print'
                and self._print_view(eventtime)):
            # Refresh just the info panel (icons/values), not the whole screen.
            pop = []
            self._print_view_ops(pop, eventtime, values_only=True)
            self._gui_enqueue(pop)
            return
        self._gui_enqueue([lambda et=eventtime: self._gui_topbar(et, False),
                           lambda et=eventtime: self._gui_bottombar(et,
                                                                    False)])
    def _gui_enqueue(self, ops):
        # Drain the draw commands a few at a time (see _gui_drain): sending a
        # whole redraw synchronously blocks the reactor for ~50ms, which starves
        # the move queue and makes the MCU shut down with "Timer too close".
        if not ops:
            return
        self._gui_ops = ops
        self.printer.get_reactor().register_callback(self._gui_drain)
    def _gui_drain(self, eventtime):
        reactor = self.printer.get_reactor()
        ops = self._gui_ops
        if not ops:
            self._gui_ops = None
            return reactor.NEVER
        if self._disp_quiet(eventtime) and not self._mesh_can_draw():
            # Homing/moving started mid-redraw: drop it and redraw when idle.
            self._gui_ops = None
            self._mesh_forget()
            self._gui_defer(eventtime, 0.4)
            return reactor.NEVER
        t0 = reactor.monotonic()
        while ops:
            try:
                ops.pop(0)()
            except Exception:
                # e.g. the serial link is closing (shutdown/restart): drop the
                # rest of the redraw instead of taking klippy down.
                logging.exception("st7796: display draw failed")
                self._gui_ops = None
                return reactor.NEVER
            if reactor.monotonic() - t0 >= 0.010:
                break
            if self.gui_screen == 'mesh' and self._mesh_run > 0 \
                    and self._homing:
                # a probe move just started: stop the map update instantly
                self._gui_ops = None
                self._mesh_forget()
                return reactor.NEVER
        if ops:
            reactor.register_callback(self._gui_drain)
        else:
            self._gui_ops = None
            self._ui_live_t = reactor.monotonic()
        return reactor.NEVER
    def _mesh_can_draw(self):
        # The leveling screen keeps refreshing while G29 runs (heating, and the
        # travels between probe points). It still goes completely silent for the
        # probe moves themselves (_homing) - that is where trsync is critical.
        return (bool(self.gui) and self.gui_screen == 'mesh'
                and self._mesh_run > 0 and not self._homing)

    def _gui_defer(self, eventtime, delay=0.2):
        t = eventtime + delay
        if self._gui_pending is None or t < self._gui_pending:
            self._gui_pending = t
    def _homing_begin(self, hmove):
        self._homing += 1
        self._homing_t = self.printer.get_reactor().monotonic()
        logging.info("st7796: homing begin - display muted (depth %d)",
                     self._homing)
    def _homing_end(self, hmove):
        self._homing = max(0, self._homing - 1)
        self._homing_t = self.printer.get_reactor().monotonic()
        logging.info("st7796: homing end - display resumed (depth %d)",
                     self._homing)
    # Klipper shuts down when it loses the MCU. That is exactly what happens
    # when the board is flashed from the SD card: the bootloader takes over,
    # updates the firmware and reboots the board on its own. Nothing can be
    # drawn or touched on the panel while the MCU is unconfigured, so instead
    # of an on-screen button we simply bring Klipper back by ourselves.
    # Lost link, or an MCU shutdown with no reason - i.e. the board went away
    # (rebooted / was taken over by the SD bootloader). "Command request" (M112)
    # and real MCU errors are deliberately *not* matched.
    _MCU_RE = re.compile(r"Lost communication with MCU"
                         r"|MCU '\w+' shutdown:\s*(?:\n|$)")

    def _mcu_budget(self):
        # (attempts in the last hour, seconds since the last attempt)
        try:
            with open(self._mcu_file) as f:
                last, n = [float(x) for x in f.read().split()]
        except Exception:
            last, n = 0., 0.
        if n >= 3 and time.time() - last < 3600.:
            return n, time.time() - last
        if time.time() - last < 45.:
            return n, time.time() - last
        return n, time.time() - last

    def _mcu_mark(self):
        try:
            with open(self._mcu_file) as f:
                last, n = [float(x) for x in f.read().split()]
        except Exception:
            last, n = 0., 0.
        try:
            with open(self._mcu_file, 'w') as f:
                f.write("%f %d" % (time.time(), n + 1))
        except Exception:
            logging.exception("st7796: nao consegui escrever %s"
                              % self._mcu_file)

    def _mcu_recover(self, eventtime):
        if not self.printer.is_shutdown():
            return
        n, age = self._mcu_budget()
        if n >= 3 and age < 3600.:
            return                      # already tried enough: give up
        if age < 45. and n:
            return                      # never hammer the machine
        try:
            msg, cat = self.printer.get_state_message()
        except Exception:
            return
        if cat != 'shutdown' or not self._MCU_RE.search(msg or ""):
            return
        self._mcu_mark()
        logging.info("st7796: MCU perdido (%.60s) - FIRMWARE_RESTART automatico"
                     " (tentativa %d)", msg.splitlines()[0], n + 1)
        try:
            self.gcode.run_script_from_command("FIRMWARE_RESTART")
        except Exception:
            logging.exception("st7796: FIRMWARE_RESTART automatico falhou")

    def _on_connect(self):
        self._mesh_hook()
        try:
            os.remove(self._mcu_file)   # recovered: reset the budget
        except Exception:
            pass
        self._homing = 0
        self._baby_load()
        if self._baby_saved:
            logging.info("st7796: baby step guardado %+.3f", self._baby_saved)
    def _disp_quiet(self, eventtime):
        # True => do not talk to the MCU at all (no touch poll, no redraw). While
        # the printer runs short-buffered motion (homing / probing / manual move)
        # display traffic delays the trsync_state replies and the MCU shuts down
        # with "Timer too close". Printing has a deep move buffer, so redraws are
        # allowed then - but a G28/G29 inside a print still sets _homing.
        if self._gui_action_active:
            if self.gui_screen == 'pid':
                return False          # live PID graph: keep sampling/drawing
            return not self._mesh_can_draw()
        if self._homing:
            if eventtime - self._homing_t > 300.:   # safety: stale counter
                self._homing = 0
            else:
                return True
        if eventtime < self._gui_grace_until:
            return True                 # just after a GUI action that may move
        try:
            ps = self.printer.lookup_object('print_stats').get_status(eventtime)
            printing = ps['state'] in ('printing', 'paused')
        except Exception:
            printing = False
        try:
            th = self.printer.lookup_object('toolhead')
            st = th.get_status(eventtime)
            buf = st['print_time'] - st['estimated_print_time']
        except Exception:
            return False
        if buf <= 0.001:
            return False                # idle: safe to draw
        # Moves pending. A steady print keeps a deep (1-2 s) buffer, so a redraw
        # is harmless there; a shallow buffer (print start, manual moves) is not.
        return (not printing) or buf < 1.0
    def _gui_list_ops(self, ops):
        x0, y0, x1, y1 = self._list_area()
        ops.append(lambda: self.cmd_rect.send([x0, y0, x1 - x0, y1 - y0,
                                               COL_BG]))
        for (rx, ry, rw, rh, k, name) in self._list_rows():
            bg = COL_ACTIVE if k == self._sd_sel else COL_BG
            ops.append(lambda rx=rx, ry=ry, rw=rw, rh=rh, bg=bg:
                       self.cmd_rect.send([rx, ry + 2, rw, rh - 4, bg]))
            if k == self._sd_sel:
                ops.append(lambda rx=rx, ry=ry, rh=rh:
                           self.cmd_rect.send([rx, ry + 2, 4, rh - 4,
                                               COL_C1]))
            ops.append(lambda rx=rx, ry=ry, rh=rh, name=name, bg=bg:
                       self._gui_text(rx + 12, ry + (rh - 16) // 2,
                                      name[:44], COL_WHITE, bg, 1))
        for (bx, by, bw, bh, kind) in self._list_btns():
            isz = 34                    # smaller icon, centred in the square
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh:
                       self._gui_round(bx, by, bw, bh, self.gui_btn_bg))
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, kind=kind, isz=isz:
                       self._gui_icon_at(kind, bx + (bw - isz) // 2,
                                         by + (bh - isz) // 2, COL_WHITE,
                                         self.gui_btn_bg, isz))
            if kind == 'print':
                lcol = COL_OK              # green accent line for print
            elif kind == 'down':
                lcol = COL_C3
            else:
                lcol = COL_C1
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, lcol=lcol:
                       self.cmd_rect.send([bx + 10, by + bh - 9, bw - 20, 4,
                                           lcol]))
    def _list_press(self, kind, eventtime):
        if kind == 'up':
            self._sd_sel = max(0, self._sd_sel - 1)
        elif kind == 'down':
            n = len(self._sd_files())
            self._sd_sel = min(max(0, n - 1), self._sd_sel + 1)
        elif kind == 'print':
            files = self._sd_files()
            if files:
                self._choice_open(files[self._sd_sel][0], eventtime)
            return
        self._gui_render(eventtime)
        self._gui_run_action("M300 S600 P12" if self.gui_beep else None)
    # --- printing screen: progress + temperature graphs + pause/stop ---
    def _print_status(self, eventtime):
        try:
            return self.printer.lookup_object('print_stats').get_status(
                eventtime)
        except Exception:
            return None
    def _print_view(self, eventtime):
        ps = self._print_status(eventtime)
        return ps is not None and ps['state'] in ('printing', 'paused')
    def _print_btns(self):
        # Right column: Pause/Continue (idx 2) + Cancel (idx 3).
        bw = 132
        x = self.width - bw - 8
        y0 = self.TOP_H + 10
        h = 108
        return [(x, y0, bw, h, 2), (x, y0 + h + 12, bw, h, 3)]

    def _print_img_rect(self):
        # Left column: the object preview, scaled to fit.
        return (self.RAIL_W + 4, self.TOP_H + 6, 162, 162)

    def _print_list_rows(self):
        # Middle column: the info items as a list (colour stripe + value).
        x = self.RAIL_W + 170
        y0 = self.TOP_H + 6
        return [(x, y0 + i * 28, 128, 28, k)
                for i, k in enumerate(self._PRINT_KEYS)]

    def _print_bar_rect(self):
        # Progress bar, under the image AND the info list.
        x, y, w, h = self._print_img_rect()
        lx, ly, lw, lh, _key = self._print_list_rows()[0]
        return (x, y + h + 10, (lx + lw) - x, 16)
    _PRINT_KEYS = ('etemp', 'btemp', 'fan', 'flow', 'speed', 'baby')
    def _print_panel(self):
        # (x, y, w, h, index, popup key) for the 3x2 tappable info tiles.
        x0 = self.RAIL_W + 2
        x1 = self.width - 100
        y0 = self.TOP_H + 2
        tw = (x1 - x0) // 3
        th = 88
        return [(x0 + (i % 3) * tw, y0 + (i // 3) * th, tw, th, i, k)
                for i, k in enumerate(self._PRINT_KEYS)]
    def _panel_value(self, key, eventtime):
        it = POPUP_ITEMS[key]
        try:
            if it['kind'] == 'temp':
                st = self.printer.lookup_object(
                    it['src']).get_status(eventtime)
                return ("%d/%d" % (st['temperature'], st['target']),
                        self._temp_color(st['temperature'], st['target']))
            if it['kind'] == 'factor':
                gm = self.printer.lookup_object(
                    'gcode_move').get_status(eventtime)
                return ("%d%%" % int(round(float(
                    gm.get(it['key']) or 1.) * 100)), COL_C4)
            if it['kind'] == 'fan':
                v = float(self.printer.lookup_object('fan').get_status(
                    eventtime).get('speed') or 0.) * 100.
                return ("%d%%" % int(round(v)), COL_C3)
            if it['kind'] == 'baby':
                gp = self.printer.lookup_object(
                    'gcode_move').get_status(eventtime)['gcode_position']
                return ("%.2f" % float(gp[2]), COL_C1)
        except Exception:
            pass
        return ("-", COL_DIM)
    def _graph_ops(self, ops, gx, gy, gw, gh, series, tgt, color, label, cur):
        ops.append(lambda gx=gx, gy=gy, gw=gw, gh=gh:
                   self.cmd_rect.send([gx, gy, gw, gh, self.gui_bar_bg]))
        mx = max(120.0, tgt + 20.0, (max(series) + 20.0) if series else 120.0)
        if tgt > 0:
            ty = gy + gh - 1 - int(min(1.0, tgt / mx) * (gh - 2))
            ops.append(lambda ty=ty: self.cmd_rect.send([gx, ty, gw, 1,
                                                         COL_ACTIVE]))
        n = len(series)
        if n:
            cw = max(2, gw // n)
            for i, v in enumerate(series):
                h = int(min(1.0, v / mx) * (gh - 2))
                if h <= 0:
                    continue
                x = gx + i * gw // n
                yy = gy + gh - 1 - h
                ops.append(lambda x=x, yy=yy, h=h, cw=cw:
                           self.cmd_rect.send([x, yy, cw, h, color]))
        ops.append(lambda gx=gx, gy=gy, label=label, cur=cur, tgt=tgt:
                   self._gui_text(gx + 4, gy + 2, "%s %d>%d" % (label, cur,
                                                                tgt),
                                  COL_WHITE, self.gui_bar_bg, 1))
    def _zmax(self):
        if self._zmax_v:
            return self._zmax_v
        try:
            s = self.printer.lookup_object('configfile').get_status(0)[
                'settings']
            self._zmax_v = float(s['stepper_z']['position_max'])
        except Exception:
            self._zmax_v = 0.
        return self._zmax_v
    def _info_line(self, ops, x, y, xr, lab, val, col):
        # Vertical colour bar, label, right aligned value.
        ops.append(lambda x=x, y=y, col=col: self.cmd_rect.send(
            [x, y + 6, 5, 22, col]))
        ops.append(lambda x=x, y=y, lab=lab: self._gui_text(
            x + 14, y + 9, lab, COL_WHITE, COL_BG, 1))
        if val:
            vw = len(val) * 8
            ops.append(lambda xr=xr, y=y, val=val, vw=vw, col=col:
                       self._gui_text(xr - vw, y + 9, val, col, COL_BG, 1))
    def _card_ops(self, ops, cx, cy, cw, ch, icon, val, col, draw_icon=True):
        # Small coloured icon, the value centred underneath and a coloured
        # accent line - same style as the menu buttons.
        top = cy + max(0, (ch - 50) // 2)
        if draw_icon:
            sc = self._icon_at(icon, 22)
            iw = sc[0] if sc else 0
            ops.append(lambda cx=cx, top=top, cw=cw, icon=icon, iw=iw, col=col:
                       self._gui_icon_at(icon, cx + (cw - iw) // 2, top, col,
                                         COL_BG, 22))
        if val:
            ops.append(lambda cx=cx, top=top, cw=cw, val=val, col=col:
                       self._gui_text_center(cx, cw, top + 26,
                                             str(val).center(9), col, COL_BG,
                                             1))
    def _print_view_ops(self, ops, eventtime, values_only=False):
        ps = self._print_status(eventtime)
        if ps is None:
            return
        if self._popup is not None:
            # adjustment panel takes over the whole content area
            ops.append(lambda: self.cmd_rect.send(
                [self.RAIL_W, self.TOP_H, self.width - self.RAIL_W,
                 self.height - self.TOP_H - self.STRIP_H, COL_BG]))
            self._popup_view_ops(ops, eventtime)
        else:
            self._print_3col_ops(ops, eventtime, values_only)
        self._print_btns_ops(ops, ps)

    def _print_btns_ops(self, ops, ps):
        # Right column: Pause/Continue (idx 2) + Cancel (idx 3)
        paused = ps['state'] == 'paused'
        for (x, y, w, h, idx) in self._print_btns():
            acc = self._gc(idx)
            if idx == 2:
                self._btn_ops(ops, x, y, w, h,
                              'play48' if paused else 'pause48',
                              "Resume" if paused else "Pause", accent=acc)
            else:
                self._btn_ops(ops, x, y, w, h, 'x48', "Cancel", COL_WHITE,
                              accent=COL_ERR)
    def _gui_render(self, eventtime):
        if self._gui_ops:
            if self.gui_screen == 'pid' and self._pid_active:
                self._gui_defer(eventtime, 0.3)   # retry the live graph
            return
        if self._disp_quiet(eventtime) and not self._mesh_can_draw():
            self._gui_defer(eventtime)
            return
        # Split the background into strips: a single full-screen tft_rect blocks
        # the MCU for ~30ms and delays the trsync replies.
        ops = []
        for y in range(0, self.height, 20):
            h = min(20, self.height - y)
            ops.append(lambda y=y, h=h: self.cmd_rect.send(
                [0, y, self.width, h, COL_BG]))
        ops.append(lambda: self.cmd_rect.send([0, self.TOP_H, self.RAIL_W,
                                               self.height - self.TOP_H,
                                               self.gui_bar_bg]))
        for (x, y, name, action, dim) in self._gui_rail():
            col = COL_DIM if dim else COL_WHITE
            if isinstance(action, tuple) and (action[0] == 'estop' or
                                              action[0] == 'host' or
                                              action == ('scr', 'power') or
                                              action == ('scr', 'estop')):
                col = COL_ERR                 # power menu: always red
            ops.append(lambda x=x, y=y, name=name, col=col: self._gui_icon_at(
                name, x, y, col, self.gui_bar_bg, 24))
        if self.gui_screen == 'print':
            if self._print_view(eventtime):
                self._print_view_ops(ops, eventtime)
            else:
                self._gui_list_ops(ops)
        elif self.gui_screen == 'network':
            self._net_view_ops(ops, eventtime)
        elif self.gui_screen == 'ptune':
            self._ptune_view_ops(ops, eventtime)
        elif self.gui_screen == 'estop':
            self._estop_view_ops(ops, eventtime)
        elif self.gui_screen == 'mesh':
            self._mesh_view_ops(ops, eventtime)
        elif self.gui_screen == 'meshadj':
            self._adj_view_ops(ops, eventtime)
        elif self.gui_screen == 'advanced':
            self._cards_view_ops(ops, ADV_KEYS, eventtime)
        elif self.gui_screen == 'limits':
            self._cards_view_ops(ops, LIM_KEYS, eventtime)
        elif self.gui_screen == 'probe':
            self._probe_view_ops(ops, eventtime)
        elif self.gui_screen == 'pid':
            self._pid_view_ops(ops, eventtime)
        elif self.gui_screen == 'info':
            self._info_view_ops(ops, eventtime)
        elif self.gui_screen == 'filout':
            self._filout_view_ops(ops, eventtime)
        elif self.gui_screen == 'wifilist':
            self._wifi_view_ops(ops, eventtime)
        elif self.gui_screen == 'wifikey':
            self._kb_view_ops(ops, eventtime)
        g = self.gui_btn_gap
        i2 = g // 2
        for (x, y, w, h, idx, item) in self._gui_buttons():
            if item is None:
                continue
            label, icon, action = item
            fg = COL_WHITE
            if isinstance(action, tuple) and action[0] == 'beep':
                label = "Beep ON" if self.gui_beep else "Beep OFF"
                if not self.gui_beep:
                    fg = COL_DIM
            elif isinstance(action, tuple) and action[0] == 'ext':
                label = "E %gmm" % self._ext_step
            elif isinstance(action, tuple) and action[0] == 'fsens':
                en, det = self._filament_status(eventtime)
                label = "Sensor ON" if en else "Sensor OFF"
                if not en:
                    fg = COL_DIM
            elif isinstance(action, tuple) and action[0] == 'bstep':
                label = "%g" % self._BSTEPS[self._bstep_i]
            elif isinstance(action, tuple) and action[0] == 'baby' \
                    and action[1] == 0:
                try:
                    gz = self.printer.lookup_object(
                        'gcode_move').get_status(eventtime)['gcode_position']
                    label = "Baby %.3f" % float(gz[2])
                except Exception:
                    label = "Baby -"
            sc = self._scaled_icon(icon)
            iw, ih = (sc[0], sc[1]) if sc else (0, 0)
            bx, by = x + i2, y + i2
            bw, bh = w - g, h - g
            iy = by + max(4, (bh - (ih + 8 + 16)) // 2)
            ty = iy + ih + 8
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self._gui_round(
                bx, by, bw, bh, self.gui_btn_bg))
            ops.append(lambda bx=bx, bw=bw, iy=iy, icon=icon, iw=iw, fg=fg:
                       self._gui_icon(icon, bx + (bw - iw) // 2, iy,
                                      fg, self.gui_btn_bg))
            ops.append(lambda bx=bx, bw=bw, ty=ty, label=label:
                       self._gui_text_center(bx, bw, ty, label, COL_WHITE,
                                             self.gui_btn_bg, 1))
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, idx=idx:
                       self.cmd_rect.send([bx + 10, by + bh - 13, bw - 20, 5,
                                           self._gc(idx)]))
        ops.append(lambda et=eventtime: self._gui_topbar(et))
        ops.append(lambda et=eventtime: self._gui_bottombar(et))
        if self.gui_screen == 'tcal':
            self._tcal_ops(ops)
        elif getattr(self, '_choice', None):
            self._choice_ops(ops)
        elif getattr(self, '_notice', None):
            self._notice_ops(ops)
        self._gui_enqueue(ops)
    def _raw_to_screen(self, rx, ry):
        if self.touch_swap:
            rx, ry = ry, rx
        nx = (rx - self.raw_x_min) / float(self.raw_x_max - self.raw_x_min)
        ny = (ry - self.raw_y_min) / float(self.raw_y_max - self.raw_y_min)
        if self.touch_inv_x:
            nx = 1.0 - nx
        if self.touch_inv_y:
            ny = 1.0 - ny
        return int(nx * self.width), int(ny * self.height)
    # Z stays >= 0 (the IR trigger) so the endstop never starts triggered.
    AXIS_LIMITS = {'X': (0.0, 320.0), 'Y': (0.0, 320.0), 'Z': (0.0, 400.0)}
    def _move_gcode(self, axis, sign):
        # Use a *relative* move: absolute gcode Z differs from the toolhead Z by
        # the bed-mesh offset. Clamp in toolhead (kinematic) coordinates.
        th = self.printer.lookup_object('toolhead')
        amt = self._gui_step * sign
        if axis in self.AXIS_LIMITS:
            lo, hi = self.AXIS_LIMITS[axis]
            if axis.lower() not in th.get_status(0).get('homed_axes', ''):
                return "G28 %s" % axis
            cur = th.get_position()[{'X': 0, 'Y': 1, 'Z': 2}[axis]]
            amt = max(lo, min(hi, cur + amt)) - cur
            feed = 600 if axis == 'Z' else 3000
            return "G91\nG1 %s%.3f F%d\nG90" % (axis, amt, feed)
        return "G91\nG1 %s%.3f F300\nG90" % (axis, amt)
    # Actions that leave the panel muted for a while (heating, homing, a
    # config save...): these get the centred "PLEASE WAIT" overlay.
    _BUSY_TOKENS = ('M190', 'M109', 'G28', 'G29', 'SAVE_CONFIG', 'RESTART',
                    'PROBE_CALIBRATE', 'BED_MESH_CALIBRATE', 'LOAD_FILAMENT',
                    'UNLOAD_FILAMENT')
    _MOVE_TOKENS = ('G28', 'G29', 'G1', 'G2', 'G3', 'SDCARD_PRINT_FILE',
                    'PROBE_CALIBRATE', 'BED_MESH_CALIBRATE', 'TESTZ',
                    'LOAD_FILAMENT', 'UNLOAD_FILAMENT', 'RESTART',
                    'CANCEL_PRINT', 'SET_GCODE_OFFSET', 'SAVE_CONFIG',
                    'Z_OFFSET_APPLY_PROBE')
    def _gui_run_action(self, script):
        # Run GUI gcode in one serialised greenlet (beep + action together), so
        # two actions never interleave, and mark the display busy meanwhile.
        if not script:
            return
        reactor = self.printer.get_reactor()
        if any(t in script for t in self._MOVE_TOKENS):
            # Moving: stay off the wire for a moment after dispatching.
            self._gui_grace_until = reactor.monotonic() + 2.5
        self._gui_action_active = True
        # Tell the user straight away that taps will be ignored from now on:
        # the hourglass plus the message on the bottom bar (sent directly - a
        # queued redraw would wait for the action to finish).
        try:
            self._draw_hourglass(True)
            if self._gui_msg:
                self._gui_bottombar(reactor.monotonic())
            if any(t in script for t in self._BUSY_TOKENS):
                self._gui_busy()
        except Exception:
            pass
        def _run(et, s=script):
            try:
                self.gcode.run_script_from_command(s)
            except Exception:
                logging.exception("st7796: GUI action failed")
            finally:
                self._gui_action_active = False
                if self._pid_active:
                    self._pid_active = False
                    self._pid_done = True
                    self._gui_msg = "PID done - Save to keep it"
                    self._gui_msg_until = reactor.monotonic() + 600.
                self._gui_defer(reactor.monotonic(), 0.2)
        reactor.register_async_callback(_run)
    # --- hot-end safeguard -------------------------------------------------
    _E_WORD_RE = re.compile(r"E-?[0-9.]")
    _FEED_MACROS = ('LOAD_FILAMENT', 'UNLOAD_FILAMENT')
    def _nozzle_temp(self, eventtime):
        try:
            return self.printer.lookup_object('extruder').get_status(
                eventtime)['temperature']
        except Exception:
            return None
    def _needs_hot_end(self, script):
        # True for anything that pushes/pulls filament (E moves, load/unload).
        if not script:
            return False
        if any(m in script for m in self._FEED_MACROS):
            # These macros heat the nozzle themselves (M109), so they are
            # never blocked by the cold-extrusion guard.
            return not re.search(r"\bM10[49]\b", script)
        for line in script.split('\n'):
            line = line.split(';')[0].upper().strip()
            if line.startswith('G1') and self._E_WORD_RE.search(line):
                return True
        return False
    def _gui_warn(self, text):
        logging.info("st7796: %s", text)
        try:
            self.gcode.respond_info("st7796: " + text)
        except Exception:
            pass
        self._gui_msg = text
        self._gui_msg_until = self.printer.get_reactor().monotonic() + 4.
        self._gui_next = 0.          # refresh the bottom bar on the next poll
        if self.gui_beep and not self._gui_action_active:
            self._gui_run_action("M300 S600 P40")
    # --- tune / network helpers -------------------------------------------
    def _tune_gcode(self, what, sign, eventtime):
        gm = self.printer.lookup_object('gcode_move').get_status(eventtime)
        if what == 'fan':
            s = float(self.printer.lookup_object('fan').get_status(
                eventtime).get('speed') or 0.)
            s = max(0., min(1., s + sign * 0.2))
            return "M106 S%d" % int(round(s * 255))
        if what == 'flow':
            f = float(gm.get('extrude_factor') or 1.) + sign * 0.01
            return "M221 S%d" % int(round(max(0.5, min(2.0, f)) * 100))
        if what == 'speed':
            f = float(gm.get('speed_factor') or 1.) + sign * 0.05
            return "M220 S%d" % int(round(max(0.25, min(2.0, f)) * 100))
        if what == 'etemp':
            t = self.printer.lookup_object('extruder').get_status(
                eventtime)['target'] + sign * 5.
            return "M104 S%d" % int(max(0., min(270., t)))
        if what == 'btemp':
            t = self.printer.lookup_object('heater_bed').get_status(
                eventtime)['target'] + sign * 5.
            return "M140 S%d" % int(max(0., min(120., t)))
        return None
    def _net_info(self):
        now = self.printer.get_reactor().monotonic()
        if self._net_cache is not None and now - self._net_t < 10.:
            return self._net_cache
        self._net_t = now
        try:
            with open('/proc/sys/kernel/hostname') as f:
                host = f.read().strip() or socket.gethostname()
        except Exception:
            host = socket.gethostname()
        if not host.endswith('.local'):
            host += '.local'
        info = {'ssid': '-', 'ip': '-', 'qual': -1, 'host': host}
        try:
            out = subprocess.check_output(['hostname', '-I'], text=True,
                                          timeout=3)
            ips = [a for a in out.split()
                   if ':' not in a and not a.startswith('127.')]
            if ips:
                info['ip'] = ips[0]
        except Exception:
            pass
        try:
            with open('/proc/net/wireless') as f:
                lines = f.read().splitlines()[2:]
            for line in lines:
                p = line.replace(':', ' ').split()
                if len(p) >= 4:
                    try:
                        info['qual'] = min(100, int(
                            float(p[2].rstrip('.')) * 100 / 70))
                    except Exception:
                        pass
                    ssid = self._ssid()
                    if ssid:
                        info['ssid'] = ssid
                    break
        except Exception:
            pass
        self._net_cache = info
        return info
    def _ssid(self):
        # NetworkManager first (the usual source on current Raspberry Pi OS).
        try:
            out = subprocess.run(['nmcli', '-t', '-f', 'active,ssid', 'dev',
                                  'wifi'], capture_output=True, timeout=3)
            for line in out.stdout.decode(errors='ignore').splitlines():
                if line.startswith('yes:'):
                    return line.split(':', 1)[1].strip()
        except Exception:
            pass
        try:
            for p in glob.glob('/etc/NetworkManager/system-connections/*'):
                with open(p) as f:
                    m = re.search(r'^ssid=(.+)$', f.read(), re.M)
                if m:
                    return m.group(1).strip()
        except Exception:
            pass
        try:
            with open('/etc/wpa_supplicant/wpa_supplicant.conf') as f:
                m = re.search(r'ssid="([^"]+)"', f.read())
            if m:
                return m.group(1)
        except Exception:
            pass
        return None
    def _net_announce(self):
        # SSDP NOTIFY - announce this printer to UPnP/SSDP browsers on the LAN.
        try:
            info = self._net_info()
            ip = info.get('ip') or '0.0.0.0'
            uid = 'uuid:4b6c6970-7065-7200-0000-4d696e676461'
            msgs = []
            for nt in ('upnp:rootdevice', uid,
                       'urn:schemas-upnp-org:device:basic:1'):
                msgs.append(
                    'NOTIFY * HTTP/1.1\r\n'
                    'HOST: 239.255.255.250:1900\r\n'
                    'CACHE-CONTROL: max-age=1800\r\n'
                    'LOCATION: http://%s:7125/\r\n'
                    'SERVER: Klipper/Moonraker UPnP/1.0\r\n'
                    'NT: %s\r\nNTS: ssdp:alive\r\n'
                    'USN: %s::%s\r\n\r\n' % (ip, nt, uid, nt))
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
                for m in msgs:
                    s.sendto(m.encode(), ('239.255.255.250', 1900))
            finally:
                s.close()
            return ip
        except Exception:
            logging.exception("st7796: network announce failed")
            return None
    def _btn_ops(self, ops, x, y, w, h, icon, label, col=COL_WHITE,
                 accent=None):
        g = self.gui_btn_gap
        i2 = g // 2
        bx, by, bw2, bh2 = x + i2, y + i2, w - g, h - g
        sz = 0
        sc = self._scaled_icon(icon)
        iw, ih = (sc[0], sc[1]) if sc else (0, 0)
        if ih + 42 > bh2:                     # short button: shrink the icon
            sz = max(16, bh2 - 42)
            iw = ih = sz
        iy = by + max(4, (bh2 - (ih + 8 + 16)) // 2)
        ty = iy + ih + 8
        ops.append(lambda bx=bx, by=by, bw2=bw2, bh2=bh2:
                   self._gui_round(bx, by, bw2, bh2, self.gui_btn_bg))
        if sz:
            ops.append(lambda bx=bx, bw2=bw2, iy=iy, icon=icon, iw=iw,
                       col=col, sz=sz: self._gui_icon_at(
                           icon, bx + (bw2 - iw) // 2, iy, col,
                           self.gui_btn_bg, sz))
        else:
            ops.append(lambda bx=bx, bw2=bw2, iy=iy, icon=icon, iw=iw,
                       col=col: self._gui_icon(
                           icon, bx + (bw2 - iw) // 2, iy, col,
                           self.gui_btn_bg))
        ops.append(lambda bx=bx, bw2=bw2, ty=ty, label=label:
                   self._gui_text_center(bx, bw2, ty, label, COL_WHITE,
                                         self.gui_btn_bg, 1))
        if accent is not None:
            ops.append(lambda bx=bx, by=by, bw2=bw2, bh2=bh2, accent=accent:
                       self.cmd_rect.send([bx + 10, by + bh2 - 9, bw2 - 20, 5,
                                           accent]))
    _NET_BTNS = (('scan', 'refresh', 'Scan'), ('down', 'power', 'Disconnect'),
                 ('hotspot', 'network', 'Hotspot'),
                 ('host', 'settings', 'Hostname'),
                 ('ann', 'network', 'Announce'), ('back', 'back', 'Back'))
    def _net_btns(self):
        bw = (self.width - self.RAIL_W - 8) // 3
        y0 = self.height - self.STRIP_H - 106
        x0 = self.RAIL_W + 4
        out = []
        for i, (kind, icon, lab) in enumerate(self._NET_BTNS):
            out.append((kind, icon, lab, x0 + (i % 3) * bw,
                        y0 + (i // 3) * 52, bw - 6, 46))
        return out
    def _net_view_ops(self, ops, eventtime):
        self._gui_defer(eventtime, 3.0)      # keep SSID/IP/signal live
        info = self._net_info()
        ix0 = self.RAIL_W + 4
        ix1 = self.width - 8
        q = info['qual']
        lines = [
            ("SSID", str(info['ssid'])[:20], COL_C1),
            ("IP", str(info['ip']), COL_C3),
            ("Signal", ("%d%%" % q) if q >= 0 else "-", COL_C4),
            ("Host", str(info['host']), COL_C2),
            ("Port", "7125 (Moonraker)", COL_ACTIVE),
        ]
        y0 = self.TOP_H
        line_h = max(26, (self.height - self.STRIP_H - y0 - 120)
                     // max(1, len(lines)))
        for i, (lab, val, col) in enumerate(lines):
            self._info_line(ops, ix0, y0 + i * line_h, ix1, lab, val, col)
        link = self._wifi_link()
        for (kind, icon, lab, x, y, w, h) in self._net_btns():
            if kind == 'down':
                lab = "Disconnect" if link else "Connect"
                icon = 'power' if link else 'refresh'
            self._btn_ops(ops, x, y, w, h, icon, lab)
    def _net_tap(self, sx, sy, eventtime):
        for (kind, icon, lab, x, y, w, h) in self._net_btns():
            if x <= sx < x + w and y <= sy < y + h:
                if kind == 'back':
                    self._gui_do(('scr', 'more'), eventtime)
                elif kind == 'host':
                    self._gui_do(('kbhost',), eventtime)
                elif kind == 'ann':
                    self._gui_do(('net', 'announce'), eventtime)
                else:
                    if kind == 'down':
                        kind = 'down' if self._wifi_link() else 'up'
                    self._gui_do(('wifi', kind), eventtime)
                return True
        return False
    _PTUNE = ('flow', 'speed', 'fan')
    def _ptune_value(self, eventtime):
        try:
            if self._ptune == 'fan':
                v = float(self.printer.lookup_object('fan').get_status(
                    eventtime).get('speed') or 0.)
                return "%d%%" % int(round(v * 100))
            gm = self.printer.lookup_object('gcode_move').get_status(eventtime)
            if self._ptune == 'speed':
                v = float(gm.get('speed_factor') or 1.)
            else:
                v = float(gm.get('extrude_factor') or 1.)
            return "%d%%" % int(round(v * 100))
        except Exception:
            return "--"
    _TUNE_ROWS = (('Nozzle', 'etemp', 5.), ('Bed', 'btemp', 5.),
                  ('Flow', 'flow', 1.))
    def _tune_row_btns(self):
        # (label, value, colour, key, row_y, row_h, plus_rect, minus_rect)
        try:
            ex = self.printer.lookup_object('extruder').get_status(0)
            bd = self.printer.lookup_object('heater_bed').get_status(0)
            gm = self.printer.lookup_object('gcode_move').get_status(0)
        except Exception:
            return []
        vals = {
            'etemp': ("%d/%d" % (ex['temperature'], ex['target']),
                      self._temp_color(ex['temperature'], ex['target'])),
            'btemp': ("%d/%d" % (bd['temperature'], bd['target']),
                      self._temp_color(bd['temperature'], bd['target'])),
            'flow': ("%d%%" % int(round(float(
                gm.get('extrude_factor') or 1.) * 100)), COL_C4),
        }
        x1 = self.width
        y0, y1 = self.TOP_H, self.height - self.STRIP_H
        rh = (y1 - y0) // len(self._TUNE_ROWS)
        bw = 84
        bh = min(64, rh - 14)
        out = []
        for i, (lab, key, step) in enumerate(self._TUNE_ROWS):
            val, col = vals[key]
            ry = y0 + i * rh
            by = ry + (rh - bh) // 2
            plus = (x1 - 2 * bw - 22, by, bw, bh, key, step)
            minus = (x1 - bw - 10, by, bw, bh, key, -step)
            out.append((lab, val, col, key, ry, rh, plus, minus))
        return out
    def _sign_btn(self, ops, x, y, w, h, sign, accent):
        ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
            x, y, w, h, self.gui_btn_bg))
        tw = len(sign) * 8 * 3
        ops.append(lambda x=x, y=y, w=w, h=h, sign=sign, tw=tw:
                   self._gui_text(x + max(0, (w - tw) // 2),
                                  y + max(0, (h - 48) // 2), sign,
                                  COL_WHITE, self.gui_btn_bg, 3))
        if accent is not None:
            ops.append(lambda x=x, y=y, w=w, h=h, accent=accent:
                       self.cmd_rect.send([x + 10, y + h - 11, w - 20, 5,
                                           accent]))
    def _ptune_view_ops(self, ops, eventtime):
        # Table: name + current/target value on the left, +/- buttons on the
        # right (fixed step per row).
        for (lab, val, col, key, ry, rh, plus, minus) in self._tune_row_btns():
            ops.append(lambda ry=ry, lab=lab: self._gui_text(
                self.RAIL_W + 10, ry + 8, lab, COL_WHITE, COL_BG, 1))
            ops.append(lambda ry=ry, val=val, col=col: self._gui_text(
                self.RAIL_W + 10, ry + 30, val, col, COL_BG, 2))
            p = plus
            self._sign_btn(ops, p[0], p[1], p[2], p[3], "+", self._gc(0))
            m = minus
            self._sign_btn(ops, m[0], m[1], m[2], m[3], "-", self._gc(1))
    def _ptemp_view_ops(self, ops, eventtime):
        try:
            ex = self.printer.lookup_object('extruder').get_status(eventtime)
            bd = self.printer.lookup_object('heater_bed').get_status(eventtime)
        except Exception:
            return
        bw = (self.width - self.RAIL_W) // 4
        iy0 = self.TOP_H
        for lab, st, cx in (("Bed", bd, self.RAIL_W),
                            ("Nozzle", ex, self.RAIL_W + 2 * bw)):
            col = self._temp_color(st['temperature'], st['target'])
            val = "%d/%d" % (st['temperature'], st['target'])
            ops.append(lambda cx=cx, bw=bw, iy0=iy0, lab=lab: self._gui_text_center(
                cx, 2 * bw, iy0 + 22, lab, COL_WHITE, COL_BG, 2))
            ops.append(lambda cx=cx, bw=bw, iy0=iy0, val=val, col=col:
                       self._gui_text_center(cx, 2 * bw, iy0 + 62, val, col,
                                             COL_BG, 3))
        for (x, y, w, h, idx, item) in self._gui_buttons():
            if idx == 4:
                self._btn_ops(ops, x, y, w, h, 'bed', "Bed +")
            elif idx == 5:
                self._btn_ops(ops, x, y, w, h, 'bed', "Bed -")
            elif idx == 6:
                self._btn_ops(ops, x, y, w, h, 'fire', "Nozzle +")
            elif idx == 7:
                self._btn_ops(ops, x, y, w, h, 'fire', "Nozzle -")
    def _big_btn(self, ops, x, y, w, h, label, bg, fg):
        ops.append(lambda x=x, y=y, w=w, h=h, bg=bg: self._gui_round(
            x, y, w, h, bg))
        tw = len(label) * 32
        tx = x + max(0, (w - tw) // 2)
        ty = y + max(0, (h - 64) // 2)
        ops.append(lambda tx=tx, ty=ty, label=label, bg=bg, fg=fg:
                   self._gui_text(tx, ty, label, fg, bg, 4))
    # --- notifications -----------------------------------------------------
    def _notify(self, text):
        path = '/home/mingda/printer_data/config/telegram.sh'
        if not os.path.exists(path):
            return

        def _run():
            try:
                subprocess.run(['/bin/sh', path, text], timeout=15,
                               capture_output=True)
            except Exception:
                logging.exception("st7796: telegram failed")
        threading.Thread(target=_run, daemon=True).start()
    # --- Filament ---------------------------------------------------------
    def _notice_ok_btn(self):
        return (160, 42)
    @staticmethod
    def _wrap(text, n=44):
        out, cur = [], ''
        for word in str(text).split():
            if cur and len(cur) + 1 + len(word) > n:
                out.append(cur)
                cur = word
            else:
                cur = (cur + ' ' + word) if cur else word
        if cur:
            out.append(cur)
        return out
    def _notice_ops(self, ops):
        lines = []
        for t in (self._notice or ()):
            lines.extend(self._wrap(t))
        lines = lines[:3]
        bg = self.gui_bar_bg
        w, h = 380, 180
        x = (self.width - w) // 2
        y = self.TOP_H + (self.height - self.STRIP_H - self.TOP_H - h) // 2
        # plain square box, no outline
        ops.append(lambda: self.cmd_rect.send([x, y, w, h, bg]))
        icon = getattr(self, '_notice_icon', 'filnout')
        icol = COL_OK if icon == 'check' else COL_WARN
        ops.append(lambda icon=icon, icol=icol: self._gui_icon_at(
            icon, x + (w - 56) // 2, y + 8, icol, bg, 56))
        for i, txt in enumerate(lines[:2]):
            ops.append(lambda i=i, txt=txt, x=x, w=w, y=y, bg=bg:
                       self._gui_text_center(x, w, y + 68 + i * 20, txt,
                                             COL_WHITE if i == 0 else COL_DIM2,
                                             bg, 1))
        bw, bh = self._notice_ok_btn()
        bx = x + (w - bw) // 2
        by = y + h - bh - 12
        ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self._gui_round(
            bx, by, bw, bh, self.gui_btn_bg, bg))
        ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self._gui_text_center(
            bx, bw, by + (bh - 16) // 2, "OK", COL_WHITE, self.gui_btn_bg, 1))
        ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self.cmd_rect.send(
            [bx + 10, by + bh - 9, bw - 20, 5, COL_OK]))
    def _filout_btns(self):
        # 4 across, on the bottom row of a 2x4 grid; the text sits on top.
        bw = (self.width - self.RAIL_W) // 4
        bh = 108
        y = self.height - self.STRIP_H - bh - 8
        return [(k, self.RAIL_W + i * bw, y, bw, bh)
                for i, k in enumerate(('unload', 'load', 'resume', 'cancel'))]
    def _filout_view_ops(self, ops, eventtime):
        cx = self.RAIL_W + (self.width - self.RAIL_W) // 2
        ops.append(lambda: self._gui_icon_at('filnout', cx - 28,
                                             self.TOP_H + 2, COL_WARN,
                                             COL_BG, 56))
        ops.append(lambda: self._gui_text_center(
            self.RAIL_W, self.width - self.RAIL_W, self.TOP_H + 62,
            "FILAMENT RUNOUT", COL_WARN, COL_BG, 2))
        ops.append(lambda: self._gui_text_center(
            self.RAIL_W, self.width - self.RAIL_W, self.TOP_H + 98,
            "Print paused", COL_DIM2, COL_BG, 1))
        for (kind, x, y, w, h) in self._filout_btns():
            icon, acc = {'unload': ('unload', COL_WARN),
                         'load': ('load', COL_C3),
                         'resume': ('play48', COL_OK),
                         'cancel': ('x48', COL_ERR)}[kind]
            self._btn_ops(ops, x, y, w, h, icon, kind.capitalize(),
                          accent=acc)
    def _print_watch(self, eventtime):
        # Finished / cancelled / failed: popup + beep (taps anywhere close it)
        ps = self._print_status(eventtime)
        if ps is None:
            return
        state = ps.get('state')
        prev = self._ps_prev
        self._ps_prev = state
        if prev not in ('printing', 'paused'):
            return
        if state not in ('complete', 'cancelled', 'error'):
            return
        name = os.path.basename(ps.get('filename') or '')[:34]
        dur = int(ps.get('print_duration') or 0)
        if dur >= 3600:
            ttxt = "%dh%02dm" % (dur // 3600, (dur % 3600) // 60)
        else:
            ttxt = "%dm" % max(1, dur // 60)
        if state == 'complete':
            msg = ("Print finished (%s)" % ttxt, name)
        elif state == 'cancelled':
            msg = ("Print cancelled (%s)" % ttxt, name)
        else:
            msg = ("Print error", (ps.get('message') or name)[:40])
        self._notice = msg
        self._notify({'complete': '\u2705 Print finished in %s: %s',
                      'cancelled': '\u26d4 Print cancelled after %s: %s',
                      'error': '\u274c Print error (%s): %s'}[state]
                     % (ttxt, name or msg[1]))
        self._notice_icon = {'complete': 'check',
                             'cancelled': 'x48'}.get(state, 'alert')
        self._gui_msg = msg[0]
        self._gui_msg_until = eventtime + 120.
        self.gcode.respond_info("GUI: %s %s" % (msg[0], name))
        if self.gui_beep:
            self._gui_run_action("M300 S500 P60\nM300 S700 P80")
        self._gui_render(eventtime)
    def _fil_watch(self, eventtime):
        # Runout while printing: Klipper pauses (pause_on_runout); show the
        # panel with the load/unload choices.
        en, det = self._filament_status(eventtime)
        if not en or det is None:
            return
        if det:
            self._fil_lost = False
            return
        ps = self._print_status(eventtime)
        state = (ps or {}).get('state')
        if state not in ('printing', 'paused'):
            self._fil_lost = False
            return
        if self._fil_lost or state != 'paused':
            return
        self._fil_lost = True
        self.gcode.respond_info("GUI: filament runout - showing the panel")
        self._notify("\u26a0\ufe0f Filament runout - the print is paused")
        if self.gui_screen != 'filout':
            self.gui_screen = 'filout'
            self._gui_render(eventtime)
    # --- Klipper error panel ---------------------------------------------
    def _err_btns(self):
        w = (self.width - self.RAIL_W - 24) // 2
        y = self.height - self.STRIP_H - 58
        return [('fw', self.RAIL_W + 8, y, w, 48),
                ('host', self.RAIL_W + 16 + w, y, w, 48)]
    def _err_panel(self, eventtime):
        try:
            msg = self.printer.get_state_message() or 'Klipper stopped'
        except Exception:
            msg = 'Klipper stopped'
        msg = ' '.join(str(msg).split())
        if self._err_shown == msg:
            return
        self._err_shown = msg
        bg = self.gui_bar_bg
        for y in range(0, self.height, 20):
            self.cmd_rect.send([0, y, self.width,
                                min(20, self.height - y), COL_BG])
        self.cmd_rect.send([0, self.TOP_H, self.RAIL_W,
                            self.height - self.TOP_H, bg])
        self._gui_icon_at('alert', self.RAIL_W + 10, self.TOP_H + 8, COL_ERR,
                          COL_BG, 34)
        self._gui_text(self.RAIL_W + 52, self.TOP_H + 12, "KLIPPER ERROR",
                       COL_ERR, COL_BG, 2)
        y = self.TOP_H + 56
        for line in self._wrap(msg, 46)[:7]:
            self._gui_text(self.RAIL_W + 8, y, line, COL_WHITE, COL_BG, 1)
            y += 17
        for (kind, x, y, w, h) in self._err_btns():
            self._gui_round(x, y, w, h, self.gui_btn_bg)
            lab = "Firmware Restart" if kind == 'fw' else "Host Reboot"
            self._gui_text_center(x, w, y + (h - 16) // 2, lab, COL_WHITE,
                                  self.gui_btn_bg, 1)
            self.cmd_rect.send([x + 8, y + h - 9, w - 16, 4,
                                COL_OK if kind == 'fw' else COL_WARN])

    # --- update check -----------------------------------------------------
    def _upd_check(self, eventtime):
        if self._upd_busy or eventtime < self._upd_next:
            return
        self._upd_busy = True
        self._upd_next = eventtime + 300.

        def _run():
            n = 0
            try:
                with urllib.request.urlopen(
                        'http://127.0.0.1:7125/machine/update/status'
                        '?refresh=false', timeout=10) as r:
                    d = json.loads(r.read().decode())['result']
                for name, vi in (d.get('version_info') or {}).items():
                    if vi.get('commits_behind'):
                        n += 1
            except Exception:
                n = self._upd_n
            self._upd_n = n
            self._upd_busy = False
        threading.Thread(target=_run, daemon=True).start()
    def _upd_text(self):
        try:
            with urllib.request.urlopen(
                    'http://127.0.0.1:7125/machine/update/status'
                    '?refresh=false', timeout=8) as r:
                d = json.loads(r.read().decode())['result']
            out = []
            for name, vi in (d.get('version_info') or {}).items():
                n = len(vi.get('commits_behind') or [])
                if n:
                    out.append("%s: %d behind" % (name, n))
            return " / ".join(out) or "everything is up to date"
        except Exception:
            return "cannot read the update status"

    # --- file choice popup ------------------------------------------------
    def _choice_box(self):
        w, h = 400, 250
        x = (self.width - w) // 2
        y = self.TOP_H + (self.height - self.STRIP_H - self.TOP_H - h) // 2
        return x, y, w, h
    def _choice_btns(self):
        x, y, w, h = self._choice_box()
        bw, bh = 150, 46
        by = y + h - bh - 14
        bx = x + (w - 2 * bw - 16) // 2
        return [('print', bx, by, bw, bh),
                ('cancel', bx + bw + 16, by, bw, bh)]
    def _choice_ops(self, ops):
        bg = self.gui_bar_bg
        x, y, w, h = self._choice_box()
        ops.append(lambda: self._gui_round(x, y, w, h, bg))
        # the object preview, centred at the top (print icon if there is none)
        iw, ih = 130, 104
        ix = x + (w - iw) // 2
        iy = y + 12
        bits = self._choice.get('bits')
        if bits:
            bw2, bh2, bdata = bits
            bx2 = ix + max(0, (iw - bw2) // 2)
            by2 = iy + max(0, (ih - bh2) // 2)
            ops.append(lambda bx2=bx2, by2=by2, bw2=bw2, bh2=bh2, bdata=bdata:
                       self._bmp_at((bw2, bh2, bdata), bx2, by2, COL_PREVIEW,
                                    bg, ('chp', bw2, bh2)))
        else:
            isz = 72
            ops.append(lambda ix=ix, iy=iy, isz=isz: self._gui_icon_at(
                'print', ix + (iw - isz) // 2, iy + (ih - isz) // 2,
                COL_WHITE, bg, isz))
        name = self._choice.get('name', '')
        ops.append(lambda: self._gui_text_center(
            x, w, iy + ih + 10, name[-44:], COL_WHITE, bg, 1))
        eta = self._choice.get('eta')
        sub = ('estimated %s' % eta) if eta else ''
        if sub:
            ops.append(lambda: self._gui_text_center(
                x, w, iy + ih + 30, sub, COL_DIM2, bg, 1))
        for (kind, bx, by, bw, bh) in self._choice_btns():
            lab = "Print" if kind == 'print' else "Cancel"
            acc = COL_OK if kind == 'print' else COL_ERR
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self._gui_round(
                bx, by, bw, bh, self.gui_btn_bg, bg))
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, lab=lab:
                       self._gui_text_center(bx, bw, by + (bh - 16) // 2,
                                             lab, COL_WHITE, self.gui_btn_bg,
                                             1))
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, acc=acc:
                       self.cmd_rect.send([bx + 8, by + bh - 9, bw - 16, 4,
                                           acc]))
    def _choice_open(self, name, eventtime):
        self._choice = {'name': name, 'eta': None}
        self._gui_render(eventtime)

        def _run():
            try:
                q = urllib.parse.quote(name)
                with urllib.request.urlopen(
                        'http://127.0.0.1:7125/server/files/metadata'
                        '?filename=' + q, timeout=10) as r:
                    d = json.loads(r.read().decode())['result']
                est = int(d.get('estimated_time') or 0)
            except Exception:
                est = 0
            bits = None
            try:
                d = self._sd_dir()
                if d:
                    bw2, bh2, bdata = tft_thumb.thumbnail_bitmap(
                        os.path.join(d, name), 120)
                    if bdata:
                        bits = (bw2, bh2, bdata)
            except Exception:
                bits = None
            if self._choice is not None:
                self._choice = {
                    'name': name,
                    'eta': ('%dh%02dm' % (est // 3600, (est % 3600) // 60)
                            if est > 0 else None),
                    'bits': bits}
            self._gui_pending = time.monotonic() + 0.2
        threading.Thread(target=_run, daemon=True).start()
    # --- custom macros (panel_macros.json) --------------------------------
    def _panel_macros(self):
        path = os.path.expanduser('~/printer_data/config/panel_macros.json')
        try:
            mt = os.stat(path).st_mtime
        except OSError:
            return []
        if self._macros_cache[0] == mt:
            return self._macros_cache[1]
        try:
            with open(path) as f:
                data = json.load(f)
            out = []
            for it in data:
                if isinstance(it, dict) and it.get('label') and it.get('gcode'):
                    ico = str(it.get('icon') or 'script')
                    if ico not in tft_icons.ICONS and ico not in EXTRA_ICONS:
                        ico = 'script'
                    out.append((str(it['label'])[:10], ico, str(it['gcode'])))
        except Exception:
            out = []
        self._macros_cache = (mt, out)
        return out
    def _macro_items(self):
        items = list(self._panel_macros())[:7]
        items.append(("Back", "back", ('scr', 'more')))
        return items

    # --- touch calibration wizard -----------------------------------------
    TCAL_STEPS = 4
    def _tcal_targets(self):
        r = self.RAIL_W + 42
        top = self.TOP_H + 42
        bot = self.height - self.STRIP_H - 42
        return [(r, top), (self.width - 42, top),
                (r, bot), (self.width - 42, bot)]
    def _tcal_ops(self, ops):
        if self._tcal is None:
            self._tcal = {'pts': [], 'res': None}
        t = self._tcal
        bg = COL_BG
        res = t.get('res')
        if res:
            x0, x1, y0, y1, swap, invx, invy = res
            lines = [("raw_x_min: %d" % x0, COL_WHITE),
                     ("raw_x_max: %d" % x1, COL_WHITE),
                     ("raw_y_min: %d" % y0, COL_WHITE),
                     ("raw_y_max: %d" % y1, COL_WHITE),
                     ("touch_swap_xy: %s" % swap, COL_WARN if swap else COL_DIM2),
                     ("touch_invert_x: %s" % invx, COL_WARN if invx else COL_DIM2),
                     ("touch_invert_y: %s" % invy, COL_WARN if invy else COL_DIM2)]
            ops.append(lambda: self._gui_text(self.RAIL_W + 14, self.TOP_H + 14,
                                              "Paste under [display]:",
                                              COL_DIM2, bg, 1))
            y = self.TOP_H + 40
            for txt, col in lines:
                ops.append(lambda txt=txt, y=y, col=col:
                           self._gui_text(self.RAIL_W + 14, y, txt, col, bg, 1))
                y += 22
            ops.append(lambda: self._gui_text(self.RAIL_W + 14, y + 8,
                                              "tap anywhere to finish",
                                              COL_DIM2, bg, 1))
            return
        n = len(t['pts'])
        tx, ty = self._tcal_targets()[min(n, 3)]
        ops.append(lambda: self._gui_text_center(
            self.RAIL_W, self.width - self.RAIL_W, self.TOP_H + 6,
            "Touch calibration", COL_WHITE, bg, 1))
        ops.append(lambda: self._gui_text_center(
            self.RAIL_W, self.width - self.RAIL_W, self.TOP_H + 24,
            "tap the crosshair (%d of 4)" % (n + 1), COL_DIM2, bg, 1))
        ops.append(lambda: self.cmd_rect.send([tx - 1, ty - 24, 3, 48, COL_WARN]))
        ops.append(lambda: self.cmd_rect.send([tx - 24, ty - 1, 48, 3, COL_WARN]))
    def _tcal_tap(self, rx, ry, eventtime):
        t = self._tcal
        if t is None:
            return
        if t.get('res'):
            self._tcal = None
            self._gui_do(('scr', 'more'), eventtime)
            return
        t['pts'].append((rx, ry))
        if len(t['pts']) >= 4:
            ax, ay = t['pts'][0]
            bx, by = t['pts'][1]
            cx, cy = t['pts'][2]
            dx2, dy2 = t['pts'][3]
            swap = abs(ay - by) > abs(ax - bx)
            if swap:
                xs = [ay, by, cy, dy2]; ys = [ax, bx, cx, dx2]
            else:
                xs = [ax, bx, cx, dx2]; ys = [ay, by, cy, dy2]
            invx = (by < ay) if not swap else (bx < ax)
            invy = (cx < ax) if not swap else (cy < ay)
            t['res'] = (min(xs), max(xs), min(ys), max(ys), swap, invx, invy)
        self._gui_render(eventtime)

    # --- on-screen keyboard ----------------------------------------------
    _KB_LETTERS = (list('qwertyuiop'),
                   list('asdfghjkl') + ['BK'],
                   ['SH'] + list('zxcvbnm') + ['SY', '.'])
    _KB_SYMBOLS = (list('1234567890'),
                   list('-_.@#!$%&*'),
                   ['SH'] + list('+/:;=,?()') + ['AB'])
    def _kb_rows(self):
        return self._KB_SYMBOLS if self._kb_sym else self._KB_LETTERS
    def _kb_cells(self):
        cw = (self.width - self.RAIL_W) // 10
        ch, y0 = 46, self.TOP_H + 58
        out = []
        for r, row in enumerate(self._kb_rows()):
            for c, lab in enumerate(row):
                out.append((self.RAIL_W + c * cw + 2, y0 + r * ch + 2,
                            cw - 4, ch - 4, lab))
        y = y0 + 3 * ch
        out.append((self.RAIL_W + 2, y + 2, 4 * cw - 4, ch - 4, 'SPACE'))
        out.append((self.RAIL_W + 4 * cw + 2, y + 2, 3 * cw - 4, ch - 4,
                    'CANCEL'))
        out.append((self.RAIL_W + 7 * cw + 2, y + 2, 3 * cw - 4, ch - 4,
                    'OK'))
        return out
    def _kb_disp(self, lab):
        if lab in ('BK', 'SH', 'SY', 'AB'):
            return {'BK': '<-', 'SH': 'SH', 'SY': '1#?', 'AB': 'abc'}[lab]
        if lab in ('SPACE', 'CANCEL', 'OK'):
            return lab
        return lab.upper() if self._kb_shift and lab.isalpha() else lab
    def _kb_view_ops(self, ops, eventtime):
        bg = self.gui_btn_bg
        ops.append(lambda: self._gui_text(self.RAIL_W + 8, self.TOP_H + 6,
                                          self._kb_title[:28], COL_C3,
                                          COL_BG, 1))
        shown = ('*' * len(self._kb_text)
                 if self._kb_mode == 'psk' and not self._kb_show
                 else self._kb_text)
        ops.append(lambda: self.cmd_rect.send(
            [self.RAIL_W + 6, self.TOP_H + 24, self.width - self.RAIL_W - 12,
             26, self.gui_bar_bg]))
        ops.append(lambda: self._gui_text(
            self.RAIL_W + 10, self.TOP_H + 30, shown[-28:], COL_WHITE,
            self.gui_bar_bg, 1))
        if self._kb_mode == 'psk':
            bx, by, bw, bh = self._kb_eye_btn()
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self._gui_round(
                bx, by, bw, bh, bg))
            lab = "HIDE" if self._kb_show else "SHOW"
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh, lab=lab:
                       self._gui_text_center(bx, bw, by + (bh - 16) // 2,
                                             lab, COL_WHITE, bg, 1))
        for (x, y, w, h, lab) in self._kb_cells():
            ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
                x, y, w, h, bg))
            txt = self._kb_disp(lab)
            ops.append(lambda x=x, y=y, w=w, h=h, txt=txt:
                       self._gui_text_center(x, w, y + (h - 16) // 2, txt,
                                             COL_WHITE, bg, 1))
            if lab == 'OK':
                ops.append(lambda x=x, y=y, w=w, h=h: self.cmd_rect.send(
                    [x + 8, y + h - 7, w - 16, 4, COL_OK]))
            elif lab == 'CANCEL':
                ops.append(lambda x=x, y=y, w=w, h=h: self.cmd_rect.send(
                    [x + 8, y + h - 7, w - 16, 4, COL_ERR]))
    def _kb_apply(self, eventtime):
        if self._kb_mode == 'psk':
            psk = self._kb_text
            if len(psk) < 8:
                self._gui_warn("Password needs 8+ characters")
                return
            self.gui_screen = 'network'
            self._gui_render(eventtime)
            self._gui_msg = "Connecting to %s..." % self._kb_ssid
            self._gui_msg_until = eventtime + 60.
            self._wifi_call('connect', self._kb_ssid, psk)
            return
        name = self._kb_text.strip().lower()
        if not name or len(name) > 63 or any(
                c not in 'abcdefghijklmnopqrstuvwxyz0123456789-'
                for c in name):
            self._gui_warn("Hostname: a-z, 0-9 and - only")
            return
        self.gui_screen = 'network'
        self._gui_render(eventtime)
        self._gui_msg = "Hostname -> %s" % name
        self._gui_msg_until = eventtime + 30.
        self._wifi_call('hostname', name)
    def _kb_key(self, lab, eventtime):
        if lab == 'BK':
            self._kb_text = self._kb_text[:-1]
        elif lab == 'SH':
            self._kb_shift = not self._kb_shift
        elif lab == 'SY':
            self._kb_sym = True
        elif lab == 'AB':
            self._kb_sym = False
        elif lab == 'SPACE':
            if len(self._kb_text) < 63:
                self._kb_text += ' '
        elif lab == 'CANCEL':
            self.gui_screen = self._kb_back
        elif lab == 'OK':
            self._kb_apply(eventtime)
            return
        elif len(self._kb_text) < 63:
            self._kb_text += (lab.upper() if (self._kb_shift and lab.isalpha())
                              else lab)
        self._gui_render(eventtime)
    def _kb_tap(self, sx, sy, eventtime):
        if self._kb_mode == 'psk':
            bx, by, bw, bh = self._kb_eye_btn()
            if bx <= sx < bx + bw and by <= sy < by + bh:
                self._kb_show = not self._kb_show
                self._gui_render(eventtime)
                return True
        for (x, y, w, h, lab) in self._kb_cells():
            if x <= sx < x + w and y <= sy < y + h:
                self._kb_key(lab, eventtime)
                return True
        return False
    def _kb_open(self, mode, title, init, back, ssid=''):
        self._kb_mode = mode
        self._kb_title = title
        self._kb_text = init
        self._kb_back = back
        self._kb_ssid = ssid
        self._kb_shift = False
        self._kb_sym = False
        self._kb_show = False
        self.gui_screen = 'wifikey'

    def _wifi_link(self):
        try:
            with open('/sys/class/net/wlan0/operstate') as f:
                return f.read().strip() == 'up'
        except Exception:
            return False
    def _kb_eye_btn(self):
        return (self.width - 76, self.TOP_H + 24, 70, 26)
    # --- WiFi setup -------------------------------------------------------
    def _wifi_call(self, *args):
        if self._wifi_busy:
            self._gui_warn("Network busy - wait")
            return
        self._wifi_busy = True
        self._wifi_out = None
        self._gui_pending = time.monotonic() + 0.3

        def _run():
            out, ok = '', False
            try:
                r = subprocess.run(
                    ['sudo', '-n', '/usr/local/sbin/klipper-net'] + list(args),
                    capture_output=True, text=True, timeout=60)
                out = ((r.stdout or '') + (r.stderr or '')).strip()
                ok = r.returncode == 0
            except Exception as exc:
                out = str(exc)
            self._wifi_busy = False
            if args and args[0] in ('connect', 'open', 'down', 'up',
                                    'hostname', 'forget'):
                self._net_cache = None        # re-read SSID/IP at once
            if args and args[0] == 'scan':
                nets, seen = [], set()
                for line in out.splitlines():
                    parts = line.rsplit(':', 2)
                    if len(parts) != 3 or not parts[0]:
                        continue
                    ssid, sig, sec = parts
                    try:
                        sig = int(sig)
                    except ValueError:
                        sig = 0
                    if ssid in seen:
                        continue
                    seen.add(ssid)
                    nets.append((ssid, sig, sec not in ('', '--')))
                nets.sort(key=lambda n: -n[1])
                self._wifi_nets = nets
                self._wifi_page = 0
            elif args and args[0] in ('connect', 'open'):
                self._notice = (("WiFi connected" if ok else "WiFi failed"),
                                args[1] if ok else out[:40])
                self._notice_icon = 'check' if ok else 'alert'
                self._gui_msg = ("Connected: %s" % args[1]) if ok else out[:60]
                self._gui_msg_until = time.monotonic() + 60.
            elif args and args[0] == 'hostname':
                self._notice = (("Hostname set" if ok else "Hostname failed"),
                                args[1] if ok else out[:40])
                self._notice_icon = 'check' if ok else 'alert'
                self._gui_msg = ("Hostname: %s" % args[1]) if ok else out[:60]
                self._gui_msg_until = time.monotonic() + 30.
            self._gui_pending = time.monotonic() + 0.3
        threading.Thread(target=_run, daemon=True).start()
    def _wifi_rows(self):
        per = 5
        start = self._wifi_page * per
        rows = []
        for i, (ssid, sig, sec) in enumerate(self._wifi_nets[start:start + per]):
            rows.append((self.RAIL_W + 4, self.TOP_H + 6 + i * 36,
                         self.width - self.RAIL_W - 8, 34,
                         start + i, ssid, sig, sec))
        return rows
    def _wifi_btns(self):
        bw = (self.width - self.RAIL_W) // 4
        y = self.height - self.STRIP_H - 52
        return [('up', self.RAIL_W + 2, y, bw - 4, 46),
                ('down', self.RAIL_W + bw + 2, y, bw - 4, 46),
                ('back', self.RAIL_W + 2 * bw + 2, y, 2 * bw - 4, 46)]
    def _wifi_view_ops(self, ops, eventtime):
        bg = self.gui_btn_bg
        if self._wifi_busy:
            ops.append(lambda: self._gui_text_center(
                self.RAIL_W, self.width - self.RAIL_W,
                self.TOP_H + 60, "scanning...", COL_WARN, COL_BG, 2))
        elif not self._wifi_nets:
            ops.append(lambda: self._gui_text_center(
                self.RAIL_W, self.width - self.RAIL_W,
                self.TOP_H + 60, "no networks", COL_DIM2, COL_BG, 2))
        for (x, y, w, h, idx, ssid, sig, sec) in self._wifi_rows():
            ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
                x, y, w, h, bg))
            ops.append(lambda x=x, y=y, w=w, h=h, idx=idx: self.cmd_rect.send(
                [x, y, 4, h, self._gc(idx)]))
            tag = "%d%%%s" % (sig, ' *' if sec else '')
            sx_sig = x + w - len(tag) * 8 - 8
            name = ssid[:26]
            # centre the name between the colour stripe and the signal
            tx = x + 12 + max(0, ((sx_sig - 8) - (x + 12) - len(name) * 8) // 2)
            ops.append(lambda tx=tx, y=y, h=h, name=name: self._gui_text(
                tx, y + (h - 16) // 2, name, COL_WHITE, bg, 1))
            ops.append(lambda sx_sig=sx_sig, y=y, h=h, tag=tag: self._gui_text(
                sx_sig, y + (h - 16) // 2, tag,
                COL_C3 if sec else COL_C4, bg, 1))
        for (kind, x, y, w, h) in self._wifi_btns():
            ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
                x, y, w, h, bg))
            if kind == 'back':
                ops.append(lambda x=x, y=y, w=w, h=h: self._gui_text_center(
                    x, w, y + (h - 16) // 2, "Back", COL_WHITE, bg, 1))
            else:
                iw = (self._icon_at(kind, 20) or (0, 0))[0]
                ops.append(lambda x=x, y=y, w=w, h=h, kind=kind, iw=iw:
                           self._gui_icon_at(kind, x + (w - iw) // 2,
                                             y + (h - 20) // 2, COL_WHITE,
                                             bg, 20))
    def _wifi_tap(self, sx, sy, eventtime):
        for (x, y, w, h, idx, ssid, sig, sec) in self._wifi_rows():
            if x <= sx < x + w and y <= sy < y + h:
                if sec:
                    self._kb_open('psk', 'password for ' + ssid, '',
                                  'wifilist', ssid)
                    self._gui_render(eventtime)
                else:
                    self._gui_msg = "Connecting to %s..." % ssid
                    self._gui_msg_until = eventtime + 60.
                    self._wifi_call('open', ssid)
                return True
        for (kind, x, y, w, h) in self._wifi_btns():
            if x <= sx < x + w and y <= sy < y + h:
                if kind == 'up' and self._wifi_page > 0:
                    self._wifi_page -= 1
                elif kind == 'down' and (self._wifi_page + 1) * 5 < len(
                        self._wifi_nets):
                    self._wifi_page += 1
                elif kind == 'back':
                    self.gui_screen = 'network'
                self._gui_render(eventtime)
                return True
        return False
    # --- Info -------------------------------------------------------------
    def _info_lines(self, eventtime):
        out = [("Release", str(self.gui_version or '-'), COL_C1)]
        try:
            kv = self.printer.get_start_args().get('software_version') or '-'
        except Exception:
            kv = '-'
        out.append(("Klipper", kv, COL_C3))
        mv = '-'
        try:
            p = os.path.expanduser('~/mainsail/.version')
            if os.path.exists(p):
                mv = (open(p).read().strip() or '-')[:28]
        except Exception:
            pass
        out.append(("Mainsail", mv, COL_C4))
        try:
            kn = os.uname().release
        except Exception:
            kn = '-'
        out.append(("Kernel", kn, COL_C2))
        try:
            hn = os.uname().nodename
        except Exception:
            hn = '-'
        out.append(("Host", hn, COL_ACTIVE))
        out.append(("Licence", "GPL-3.0", COL_WARN))
        return out
    def _info_view_ops(self, ops, eventtime):
        x0 = self.RAIL_W + 10
        y0 = self.TOP_H + 8
        lines = self._info_lines(eventtime)
        step = max(30, (self.height - self.STRIP_H - y0 - 40) //
                   max(1, len(lines)))
        for i, (lab, val, col) in enumerate(lines):
            yy = y0 + i * step
            # colour stripe on the left, like the print info list
            ops.append(lambda yy=yy, col=col: self.cmd_rect.send(
                [x0, yy + 1, 4, 26, col]))
            ops.append(lambda yy=yy, lab=lab: self._gui_text(
                x0 + 12, yy, lab, COL_DIM2, COL_BG, 1))
            ops.append(lambda yy=yy, val=val, col=col: self._gui_text(
                x0 + 12, yy + 14, val, col, COL_BG, 1))
        ops.append(lambda: self._gui_text_center(
            0, self.width, self.height - self.STRIP_H - 20, "by peekpt",
            COL_C3, COL_BG, 1))
    # --- PID tuning -------------------------------------------------------
    # A live temperature graph: the display stays awake for this screen (the
    # heater only runs PWM, no stepper timing to protect).
    def _pid_btns(self):
        # Right hand column of icon buttons; the graph takes the other three.
        bw, bh = 132, 108
        x = self.width - bw - 8
        y0 = self.TOP_H + 10
        return [('save', x, y0, bw, bh), ('abort', x, y0 + bh + 12, bw, bh)]
    def _pid_status(self, eventtime):
        try:
            st = self.printer.lookup_object(
                self._pid_heater or 'extruder').get_status(eventtime)
            return (float(st.get('temperature') or 0.),
                    float(st.get('target') or 0.),
                    float(st.get('power') or 0.))
        except Exception:
            return None
    def _pid_view_ops(self, ops, eventtime):
        x0 = self.RAIL_W + 8
        x1 = self._pid_btns()[0][1] - 8          # three of the four columns
        now = self.printer.get_reactor().monotonic()
        st = self._pid_status(eventtime)
        if st is None:
            return
        temp, tgt, pwr = st
        if self._pid_active:
            if now - self._pid_last >= 1.2:
                self._pid_samples.append(temp)
                del self._pid_samples[:-120]
                self._pid_last = now
            self._gui_defer(eventtime, 1.2)      # keep the graph ticking
        name = "PID hotend" if self._pid_heater == 'extruder' else "PID bed"
        col = self._temp_color(temp, tgt)
        ops.append(lambda: self._gui_text(x0, self.TOP_H + 6, name, COL_C3,
                                          COL_BG, 1))
        ops.append(lambda: self._gui_text(x0, self.TOP_H + 22,
                                          "%d/%dC" % (temp, tgt), col,
                                          COL_BG, 2))
        ops.append(lambda: self._gui_text(
            x0 + 170, self.TOP_H + 26, "PWM %d%%" % int(pwr * 100. + .5),
            COL_WARN, COL_BG, 1))
        el = int(now - self._pid_t0) if self._pid_t0 else 0
        ops.append(lambda el=el: self._gui_text(
            x1 - 48, self.TOP_H + 6, "%02d:%02d" % (el // 60, el % 60),
            COL_DIM, COL_BG, 1))
        gy0 = self.TOP_H + 56
        gy1 = self.height - self.STRIP_H - 10
        gw = x1 - x0
        gh = gy1 - gy0
        ops.append(lambda: self.cmd_rect.send([x0, gy0, gw, gh,
                                               self.gui_bar_bg]))
        tmax = max(50., tgt + 25.)
        ty = gy1 - int(min(1., tgt / tmax) * (gh - 2))
        ops.append(lambda ty=ty: self.cmd_rect.send([x0, ty, gw, 1, COL_DIM]))
        n = max(1, min(120, gw // 3))
        smp = self._pid_samples[-n:]
        cw = max(1, gw // n)
        bars = []
        for i, t in enumerate(smp):
            h = int(min(1., max(0., t / tmax)) * (gh - 2))
            if h > 0:
                bars.append((x0 + i * cw, gy1 - h, max(1, cw - 1), h))
        for (bx, by, bw, bh) in bars:
            ops.append(lambda bx=bx, by=by, bw=bw, bh=bh: self.cmd_rect.send(
                [bx, by, bw, max(1, bh), COL_HEAT]))
        for (kind, bx, by, bw, bh) in self._pid_btns():
            if kind == 'save':
                self._btn_ops(ops, bx, by, bw, bh, 'save', "Save",
                              accent=COL_OK)
            else:
                self._btn_ops(ops, bx, by, bw, bh, 'x48', "Abort",
                              accent=COL_ERR)
    # --- Z-Probe (manual probe calibrate) ---------------------------------
    # Layout follows the adjustment popup: [-][+][step] on top, then the
    # Start / Apply / Save / Cancel row underneath.
    def _probe_btns(self):
        x0 = self.RAIL_W + 8
        w = self.width - self.RAIL_W - 16
        bw1 = (w - 16) // 3
        bw2 = (w - 24) // 4
        y1 = self.TOP_H + 76
        h1 = 68
        y2 = y1 + h1 + 8
        h2 = self.height - self.STRIP_H - 6 - y2
        out = [('minus', x0, y1, bw1, h1),
               ('plus', x0 + bw1 + 8, y1, bw1, h1),
               ('step', x0 + 2 * (bw1 + 8), y1, bw1, h1)]
        for i, k in enumerate(('start', 'apply', 'save', 'cancel')):
            out.append((k, x0 + i * (bw2 + 8), y2, bw2, h2))
        return out
    def _probe_read(self, eventtime):
        # During PROBE_CALIBRATE show the nozzle Z being adjusted, otherwise
        # the saved probe z_offset.
        try:
            mp = self.printer.lookup_object('manual_probe').get_status(
                eventtime)
        except Exception:
            mp = {}
        if mp.get('is_active'):
            return "Nozzle Z", float(mp.get('z_position') or 0.)
        try:
            return "Z offset", float(self.printer.lookup_object(
                'probe').get_status(eventtime).get('z_offset') or 0.)
        except Exception:
            return "Z offset", None
    def _probe_view_ops(self, ops, eventtime):
        x0 = self.RAIL_W + 8
        y0 = self.TOP_H + 8
        bg = self.gui_btn_bg
        ops.append(lambda: self._gui_icon_at('zprobe', x0, y0, COL_WHITE,
                                             COL_BG, 40))
        lab, z = self._probe_read(eventtime)
        val = "%+.3f" % z if z is not None else "--"
        ops.append(lambda lab=lab: self._gui_text(x0 + 48, y0 + 2, lab,
                                                  COL_C3, COL_BG, 1))
        ops.append(lambda val=val: self._gui_text(x0 + 48, y0 + 18, val,
                                                  COL_C1, COL_BG, 3))

        ops.append(lambda: self._gui_text(x0 + 48 + 190, y0 + 2,
                                          "step %g mm" % Z_STEPS[
                                              self._zstep_i],
                                          COL_DIM, COL_BG, 1))
        for (kind, x, y, w, h) in self._probe_btns():
            if kind in ('minus', 'plus'):
                sign = '-' if kind == 'minus' else '+'
                acc = self._gc(1) if kind == 'minus' else self._gc(0)
                ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
                    x, y, w, h, bg))
                ty = y + max(4, (h - 48 - 14) // 2)
                ops.append(lambda x=x, y=y, w=w, sign=sign, ty=ty:
                           self._gui_text(x + (w - 24) // 2, ty, sign,
                                          COL_WHITE, bg, 3))
                ops.append(lambda x=x, y=y, w=w, h=h, acc=acc:
                           self.cmd_rect.send([x + 10, y + h - 11, w - 20,
                                               5, acc]))
            elif kind == 'step':
                lab = "%g" % Z_STEPS[self._zstep_i]
                ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
                    x, y, w, h, bg))
                ops.append(lambda x=x, y=y, w=w, lab=lab:
                           self._gui_text_center(x, w, y + 16, lab,
                                                 COL_WHITE, bg, 2))
                ops.append(lambda x=x, y=y, w=w, h=h:
                           self.cmd_rect.send([x + 10, y + h - 11, w - 20,
                                               5, COL_C3]))
            else:
                icon, acc = {'start': ('probe', COL_OK),
                             'apply': ('check', COL_OK),
                             'save': ('save', COL_OK),
                             'cancel': ('x48', COL_ERR)}[kind]
                lab = kind.capitalize()
                ops.append(lambda x=x, y=y, w=w, h=h: self._gui_round(
                    x, y, w, h, bg))
                isz = 30
                iw = (self._icon_at(icon, isz) or (0, 0))[0]
                iy = y + max(6, (h - (isz + 6 + 16)) // 2 - 6)
                ops.append(lambda x=x, y=y, w=w, icon=icon, iw=iw, iy=iy,
                           isz=isz: self._gui_icon_at(
                               icon, x + (w - iw) // 2, iy, COL_WHITE, bg,
                               isz))
                ops.append(lambda x=x, y=y, w=w, iy=iy, isz=isz, lab=lab:
                           self._gui_text_center(x, w, iy + isz + 6, lab,
                                                 COL_WHITE, bg, 1))
                ops.append(lambda x=x, y=y, w=w, h=h, acc=acc:
                           self.cmd_rect.send([x + 10, y + h - 10, w - 20,
                                               5, acc]))
    def _estop_btns(self):
        bw = (self.width - self.RAIL_W) // 4
        y = self.TOP_H + 104
        h = self.height - self.STRIP_H - y - 8
        return [(self.RAIL_W + 6, y, 2 * bw - 12, h, 'no'),
                (self.RAIL_W + 2 * bw + 6, y, 2 * bw - 12, h, 'yes')]
    def _estop_view_ops(self, ops, eventtime):
        ops.append(lambda: self._gui_text_center(
            0, self.width, self.TOP_H + 26, "CONFIRM?", COL_WARN, COL_BG, 3))
        for (x, y, w, h, kind) in self._estop_btns():
            if kind == 'yes':
                self._big_btn(ops, x, y, w, h, "YES", self.gui_btn_bg,
                              COL_WHITE)
            else:
                self._big_btn(ops, x, y, w, h, "NO", self.gui_btn_bg,
                              COL_WHITE)
            acc = COL_ERR if kind == 'yes' else COL_DIM
            ops.append(lambda x=x, y=y, w=w, h=h, acc=acc: self.cmd_rect.send(
                [x + 14, y + h - 14, w - 28, 6, acc]))
    def _host_power(self, what):
        # Runs in a worker thread: ask Moonraker (it holds the privileges).
        try:
            req = urllib.request.Request(
                'http://127.0.0.1:7125/machine/%s' % what, data=b'',
                method='POST')
            with urllib.request.urlopen(req, timeout=8) as r:
                r.read()
            logging.info("st7796: host %s ok", what)
            return True
        except Exception:
            logging.exception("st7796: host %s failed", what)
            return False
    def _gui_do(self, action, eventtime):
        script = None
        now = self.printer.get_reactor().monotonic()
        if isinstance(action, tuple) and action[0] == 'scr':
            if self._popup is not None:
                # rail back / other navigation: ignore the pending change
                self._popup_close(eventtime, cancel=True)
                if action[1] == self.gui_screen:
                    return
            self.gui_screen = action[1]
            if action[1] == 'mesh':
                self._mesh_done = -1
                self._mesh_arm = 0.
                self._mesh_forget()
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'step':
            i = self._gui_steps.index(self._gui_step)
            self._gui_step = self._gui_steps[(i + 1) % len(self._gui_steps)]
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'beep':
            self.gui_beep = not self.gui_beep
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'ext':
            i = self._ext_steps.index(self._ext_step)
            self._ext_step = self._ext_steps[(i + 1) % len(self._ext_steps)]
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'baby':
            amt = self._BSTEPS[self._bstep_i] * action[1]
            self.gcode.respond_info("GUI baby step: %+.3f" % amt)
            self._gui_msg = "Baby step %+.3f (Save p/ fixar)" % amt
            self._gui_msg_until = (
                self.printer.get_reactor().monotonic() + 4.)
            self._baby_dirty = True
            script = ('SET_GCODE_OFFSET Z_ADJUST=%.3f MOVE=1' % amt)
        elif isinstance(action, tuple) and action[0] == 'bstep':
            self._bstep_i = (self._bstep_i + 1) % len(self._BSTEPS)
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'pid':
            if self._pid_active:
                if self._pid_heater == action[1]:
                    # already tuning this heater: just show the graph again
                    self.gui_screen = 'pid'
                    self._gui_render(eventtime)
                else:
                    self._gui_warn("PID already running")
                return
            heater = action[1]
            target = 200 if heater == 'extruder' else 60
            self._pid_heater = heater
            self._pid_samples = []
            self._pid_t0 = now
            self._pid_last = now
            self._pid_active = True
            self._pid_done = False
            self.gui_screen = 'pid'
            self._pid_last = 0.          # take the first sample at once
            self._gui_msg = "PID %s %dC - running" % (
                "hotend" if heater == 'extruder' else "bed", target)
            self._gui_msg = ("Homing, Z+50, fan 60%%, then PID %dC..."
                             % target)
            self._gui_msg_until = now + 1200.
            # home, lift the nozzle clear of the bed, run the fan at 60 %
            # (same conditions as a print) and only then tune the PID
            script = ('G28\nG91\nG1 Z50 F600\nG90\nM106 S153\n'
                      'PID_CALIBRATE HEATER=%s TARGET=%d\nM106 S0'
                      % (heater, target))
            self._gui_render(eventtime)      # the graph, before the run starts
        elif isinstance(action, tuple) and action[0] == 'zp':
            kind = action[1]
            now = self.printer.get_reactor().monotonic()
            if kind == 'step':
                self._zstep_i = (self._zstep_i + 1) % len(Z_STEPS)
                self._gui_render(eventtime)
                return
            if kind in ('minus', 'plus'):
                amt = Z_STEPS[self._zstep_i] * (
                    -1. if kind == 'minus' else 1.)
                self._gui_msg = "TESTZ %+.3f" % amt
                self._gui_msg_until = now + 5.
                script = 'TESTZ Z=%+g' % amt
            elif kind == 'start':
                # PROBE_CALIBRATE (macros.cfg) already preheats, homes and
                # centres: do not home again here.
                try:
                    if self.printer.lookup_object(
                            'manual_probe').get_status(now).get('is_active'):
                        self._gui_warn("Calibration already running")
                        return
                except Exception:
                    pass
                self._gui_msg = "Preheating, homing, centring..."
                self._gui_msg_until = now + 900.
                script = 'PROBE_CALIBRATE'
            elif kind == 'apply':
                self._gui_msg = "Z offset accepted (ACCEPT)"
                self._gui_msg_until = now + 8.
                script = 'ACCEPT'
            elif kind == 'save':
                self._gui_msg = "Homing, then SAVE_CONFIG..."
                self._gui_msg_until = now + 240.
                script = 'G28\nSAVE_CONFIG'
            elif kind == 'cancel':
                self._gui_msg = "Cancelled: heaters OFF"
                self._gui_msg_until = now + 8.
                self.gui_screen = 'main'
                self._gui_render(eventtime)
                script = 'M104 S0\nM140 S0\nABORT'
        elif isinstance(action, tuple) and action[0] == 'bsave':
            if not self._baby_dirty:
                # Nothing changed - just leave the menu.
                self.gui_screen = 'print'
                self._gui_render(eventtime)
                return
            self.gcode.respond_info("GUI: gravar o baby step na probe")
            self._gui_msg = "Saving the baby step..."
            self._gui_msg_until = (
                self.printer.get_reactor().monotonic() + 20.)
            self._baby_dirty = False
            script = 'Z_OFFSET_APPLY_PROBE\nSAVE_CONFIG'
        elif isinstance(action, tuple) and action[0] == 'wifi':
            kind = action[1]
            if kind == 'scan':
                self._wifi_nets = []
                self._wifi_page = 0
                self.gui_screen = 'wifilist'
                self._gui_render(eventtime)
                self._wifi_call('scan')
            elif kind == 'down':
                self._gui_msg = "Disconnecting WiFi..."
                self._gui_msg_until = now + 30.
                self._wifi_call('down')
            elif kind == 'up':
                self._gui_msg = "Reconnecting to the saved network..."
                self._gui_msg_until = now + 60.
                self._wifi_call('up')
            else:
                self._gui_msg = "Starting hotspot MINGDA_SETUP..."
                self._gui_msg_until = now + 30.
                self._wifi_call('hotspoton')
        elif isinstance(action, tuple) and action[0] == 'tgtest':
            if not os.path.exists(
                    '/home/mingda/printer_data/config/telegram.sh'):
                self._gui_warn("Telegram helper missing")
                return
            self._notify("\U0001f514 Test from the Mingda panel")
            self._gui_msg = "Telegram test sent"
            self._gui_msg_until = now + 8.
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'kbhost':
            self._kb_open('text', 'hostname', socket.gethostname(), 'network')
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'filo':
            kind = action[1]
            if kind == 'resume':
                en, det = self._filament_status(eventtime)
                if en and det is False:
                    self._gui_warn("Load the filament first")
                    return
                self.gui_screen = 'print'
                self._gui_render(eventtime)
                script = 'RESUME'
            elif kind == 'cancel':
                self.gui_screen = 'print'
                self._gui_render(eventtime)
                script = 'CANCEL_PRINT'
            elif kind == 'load':
                self._gui_msg = "Loading filament..."
                self._gui_msg_until = now + 120.
                script = 'LOAD_FILAMENT'
            else:
                self._gui_msg = "Unloading filament..."
                self._gui_msg_until = now + 120.
                script = 'UNLOAD_FILAMENT'
        elif isinstance(action, tuple) and action[0] == 'fil':
            try:
                st = self.printer.lookup_object('print_stats').get_status(
                    eventtime)['state']
            except Exception:
                st = 'ready'
            if action[1] == 'load':
                self._gui_msg = "Loading filament (~100mm)..."
                script = 'LOAD_FILAMENT'
            else:
                self._gui_msg = "Unloading filament..."
                script = ('PAUSE\n' if st == 'printing' else '')
                script += 'UNLOAD_FILAMENT'
            try:
                self._gui_msg_until = (
                    self.printer.get_reactor().monotonic() + 20.)
            except Exception:
                pass
            self._gui_defer(eventtime, 1.0)
        elif isinstance(action, tuple) and action[0] == 'estop':
            if action[1] == 'yes':
                self.gcode.respond_info("GUI: EMERGENCY STOP (M112)")
                self._gui_msg = "EMERGENCY STOP !"
                self._gui_msg_until = (
                    self.printer.get_reactor().monotonic() + 6.)
                script = 'M112'
            else:
                self.gui_screen = 'power'
                self._gui_render(eventtime)
                return
        elif isinstance(action, tuple) and action[0] == 'host':
            what = 'reboot' if action[1] == 'reboot' else 'shutdown'
            self.gcode.respond_info("GUI: host %s" % what)
            try:
                self._gui_msg = ("Rebooting the host..." if what == 'reboot'
                                 else "Shutting the host down...")
                self._gui_msg_until = (
                    self.printer.get_reactor().monotonic() + 15.)
            except Exception:
                pass
            self._gui_next = 0.
            try:
                threading.Thread(target=self._host_power, args=(what,),
                                 daemon=True).start()
            except Exception:
                logging.exception("st7796: host %s thread failed", what)
            return
        elif isinstance(action, tuple) and action[0] == 'ptv':
            i = self._PTUNE.index(self._ptune)
            self._ptune = self._PTUNE[(i + 1) % len(self._PTUNE)]
            self.gcode.respond_info("GUI tune -> %s" % self._ptune)
            self._gui_render(eventtime)
        elif isinstance(action, tuple) and action[0] == 'tune':
            script = self._tune_gcode(action[1], action[2], eventtime)
            if script:
                self.gcode.respond_info("GUI tune: %s" % script)
        elif isinstance(action, tuple) and action[0] == 'net':
            ip = self._net_announce()
            if ip:
                self.gcode.respond_info(
                    "st7796: anuncio SSDP enviado na rede (%s)" % ip)
            else:
                self._gui_warn("Network announce failed")
        elif isinstance(action, tuple) and action[0] == 'fsens':
            en, det = self._filament_status(eventtime)
            new = 0 if en else 1
            script = "SET_FILAMENT_SENSOR SENSOR=%s ENABLE=%d" % (
                self.filament_sensor, new)
            self.gcode.respond_info("GUI filamento: sensor %s"
                                    % ("ON" if new else "OFF"))
            self._gui_defer(eventtime, 0.3)     # refresh the label
        elif isinstance(action, tuple) and action[0] == 'ex':
            script = "G91\nG1 E%.3f F300\nG90" % (self._ext_step * action[1])
            self.gcode.respond_info("GUI extrude: %g mm"
                                    % (self._ext_step * action[1]))
        elif isinstance(action, tuple) and action[0] == 'sd':
            try:
                ps = self.printer.lookup_object('print_stats').get_status(
                    eventtime)
                state = ps['state']
            except Exception:
                state = 'ready'
            if state in ('printing', 'paused'):
                self._gui_warn("Printing - cancel first")
                return
            en, det = self._filament_status(eventtime)
            if en and not det:
                self.gcode.respond_info("GUI: no filament - print blocked")
                self._notice = ("No filament detected.",
                                "Load it, then pick the file again.")
                self._notice_icon = 'filnout'
                self._gui_render(eventtime)
                return
            fname = str(action[1]).replace('"', '')
            self.gcode.respond_info("GUI print: %s" % fname)
            # Clear any stale file first: a cancelled print can leave the
            # virtual sdcard busy ("SD busy" on the next print).
            script = ('SDCARD_RESET_FILE\n'
                      'SDCARD_PRINT_FILE FILENAME="%s"' % fname)
        elif isinstance(action, tuple) and action[0] == 'mv':
            script = self._move_gcode(action[1], action[2])
            self.gcode.respond_info("GUI move: %s" % script.replace('\n', ' '))
        elif action:
            script = action
        if isinstance(script, str) and script.strip().upper().startswith(
                'M84'):
            try:
                st = self.printer.lookup_object('print_stats').get_status(
                    eventtime)['state']
            except Exception:
                st = 'ready'
            if st in ('printing', 'paused'):
                self._gui_warn("Printing - M84 blocked")
                return
        if (isinstance(script, str) and self.extrude_min_temp > 0
                and self._needs_hot_end(script)):
            temp = self._nozzle_temp(eventtime)
            if temp is not None and temp < self.extrude_min_temp:
                self._gui_warn("AVISO: bico %.0fC (min %.0fC) - extrusao"
                               " bloqueada" % (temp, self.extrude_min_temp))
                return
        if self.gui_beep:
            script = "M300 S600 P12\n" + (script or "")
        self._gui_run_action(script)
    def _gui_tap(self, rx, ry, eventtime):
        sx0, sy0 = self._raw_to_screen(rx, ry)
        if self.printer.is_shutdown():
            for (kind, x, y, w, h) in self._err_btns():
                if x <= sx0 < x + w and y <= sy0 < y + h:
                    try:
                        if kind == 'fw':
                            self.gcode.run_script_from_command(
                                'FIRMWARE_RESTART')
                        else:
                            self._host_power('reboot')
                    except Exception:
                        logging.exception("st7796: error action failed")
                    return
            return
        if (self.width - 156) <= sx0 < (self.width - 136) and 2 <= sy0 < 28:
            self._notice = ("Updates available", self._upd_text()[:40])
            self._notice_icon = 'refresh'
            self._gui_render(eventtime)
            return
        if self.gui_screen == 'tcal':
            try:
                self._tcal_tap(rx, ry, eventtime)
            except Exception:
                logging.exception("st7796: touch calibration failed")
            return
        if self._choice is not None:
            for (kind, x, y, w, h) in self._choice_btns():
                if x <= sx0 < x + w and y <= sy0 < y + h:
                    name = self._choice.get('name', '')
                    self._choice = None
                    if kind == 'print':
                        self._gui_do(('sd', name), eventtime)
                    else:
                        self._gui_render(eventtime)
                    return
            self._choice = None
            self._gui_render(eventtime)
            return
        if self._notice:
            self._notice = None
            self._gui_render(eventtime)
            return
        if self._gui_action_active and self.gui_screen != 'pid':
            self.gcode.respond_info("GUI: busy - tap ignored")
            return
        sx, sy = self._raw_to_screen(rx, ry)
        self._tcal = None
        if self._popup is not None:
            # A popup is modal: taps outside are ignored.
            self._popup_tap(sx, sy, eventtime)
            return
        # top bar: the filament sensor icon opens the filament menu
        if (self.width - 132) <= sx < (self.width - 100) and 2 <= sy < 28:
            self.gcode.respond_info("GUI: Filamento")
            self._gui_do(('scr', 'filament'), eventtime)
            return
        for (x, y, w, h, lab, val) in self._gui_strip():
            if x <= sx < x + w and y <= sy < y + h:
                if isinstance(val, str):
                    self.gcode.respond_info("GUI: %s" % lab)
                    script = val
                    if self.gui_beep:
                        script = "M300 S600 P12\n" + script
                    self._gui_run_action(script)
                else:
                    self._gui_step = val
                    self.gcode.respond_info("GUI step: %g mm" % val)
                    self._gui_render(eventtime)
                    self._gui_run_action(
                        "M300 S600 P12" if self.gui_beep else None)
                return
        if self.gui_screen == 'estop':
            for (x, y, w, h, kind) in self._estop_btns():
                if x <= sx < x + w and y <= sy < y + h:
                    self.gcode.respond_info("GUI: %s" % kind)
                    self._gui_do(('estop', kind), eventtime)
                    return
        if self.gui_screen == 'ptune':
            for (lab, val, col, key, ry, rh, plus, minus) in \
                    self._tune_row_btns():
                for (bx, by, bw, bh, k, step) in (plus, minus):
                    if bx <= sx < bx + bw and by <= sy < by + bh:
                        self.gcode.respond_info("GUI tune %s %+g" % (k, step))
                        self._gui_do(('tune', k, 1 if step > 0 else -1),
                                     eventtime)
                        return
        if self.gui_screen == 'meshadj':
            if self._adj_tap(sx, sy, eventtime):
                return
        if self.gui_screen in ('advanced', 'limits'):
            keys = ADV_KEYS if self.gui_screen == 'advanced' else LIM_KEYS
            if self._cards_tap(sx, sy, keys, eventtime):
                return
        if self.gui_screen == 'mesh':
            ax, ay, aw, ah = self._mesh_adj_btn()
            if ax <= sx < ax + aw and ay <= sy < ay + ah:
                if self._mesh_run > 0:
                    self.gcode.respond_info(
                        "GUI: nivelamento em curso - AJUSTAR desligado")
                    return
                self.gcode.respond_info("GUI: adjust mesh points")
                self._adj_open(eventtime)
                return
            for (x, y, w, h, kind) in self._mesh_btns():
                if not (x <= sx < x + w and y <= sy < y + h):
                    continue
                running = self._mesh_run > 0
                now = self.printer.get_reactor().monotonic()
                if kind == 'start':
                    if running:
                        self.gcode.respond_info(
                            "GUI: nivelamento em curso - INICIAR desligado")
                        return
                    self.gcode.respond_info("GUI nivelar: INICIAR")
                    self._gui_do('G29', eventtime)
                    return
                if running:
                    # The printer has no native abort: two taps -> M112.
                    if now < self._mesh_arm:
                        self.gcode.respond_info(
                            "GUI: ABORTAR nivelamento (M112 - FIRMWARE_RESTART)")
                        self._gui_msg = "Leveling aborted (M112)"
                        self._gui_msg_until = now + 15.
                        self._mesh_arm = 0.
                        self._gui_run_action("M112")
                    else:
                        self._mesh_arm = now + 5.
                        self.gcode.respond_info("GUI: ABORTAR? toca outra vez")
                        self._gui_msg = "Tap again to ABORT (M112)"
                        self._gui_msg_until = now + 6.
                        self._gui_render(now)
                else:
                    self.gcode.respond_info("GUI nivelar: CANCELAR")
                    self._gui_do(('scr', 'print'), eventtime)
                return
        if self.gui_screen == 'wifikey':
            if self._kb_tap(sx, sy, eventtime):
                return
        if self.gui_screen == 'wifilist':
            if self._wifi_tap(sx, sy, eventtime):
                return
        if self.gui_screen == 'filout':
            for (kind, x, y, w, h) in self._filout_btns():
                if x <= sx < x + w and y <= sy < y + h:
                    self.gcode.respond_info("GUI filout: %s" % kind)
                    self._gui_do(('filo', kind), eventtime)
                    return
        if self.gui_screen == 'pid':
            for (kind, x, y, w, h) in self._pid_btns():
                if x <= sx < x + w and y <= sy < y + h:
                    self.gcode.respond_info("GUI pid: %s" % kind)
                    if kind == 'save':
                        if not self._pid_done:
                            self._gui_warn("PID still running")
                            return
                        self._gui_do('SAVE_CONFIG', eventtime)
                    else:
                        self._gui_do(('scr', 'calibrate'), eventtime)
                    return
        if self.gui_screen == 'probe':
            for (kind, x, y, w, h) in self._probe_btns():
                if x <= sx < x + w and y <= sy < y + h:
                    self.gcode.respond_info("GUI zprobe: %s" % kind)
                    self._gui_do(('zp', kind), eventtime)
                    return
        if self.gui_screen == 'network':
            if self._net_tap(sx, sy, eventtime):
                return
        if self.gui_screen == 'print':
            if self._print_view(eventtime):
                ps = self._print_status(eventtime) or {}
                paused = ps.get('state') == 'paused'
                if self._popup is None:
                    # list rows open the same inline panel the tiles used to
                    for (rx, ry, rw, rh, key) in self._print_list_rows():
                        if rx <= sx < rx + rw and ry <= sy < ry + rh:
                            self.gcode.respond_info("GUI: ajuste %s"
                                                    % POPUP_ITEMS[key]['name'])
                            self._popup_open(key, eventtime)
                            return
                for (x, y, w, h, idx) in self._print_btns():
                    if x <= sx < x + w and y <= sy < y + h:
                        if idx == 2:
                            self.gcode.respond_info(
                                "GUI: %s" % ("Resume" if paused
                                             else "Pause"))
                            self._gui_do('RESUME' if paused else 'PAUSE',
                                         eventtime)
                            self._gui_defer(eventtime, 0.8)
                        else:
                            self.gcode.respond_info("GUI: Cancelar")
                            self._gui_do('CANCEL_PRINT', eventtime)
                        return
            else:
                for (bx, by, bw, bh, kind) in self._list_btns():
                    if bx <= sx < bx + bw and by <= sy < by + bh:
                        self.gcode.respond_info("GUI file: %s" % kind)
                        self._list_press(kind, eventtime)
                        return
                for (rx, ry, rw, rh, k, name) in self._list_rows():
                    if rx <= sx < rx + rw and ry <= sy < ry + rh:
                        self._sd_sel = k
                        self.gcode.respond_info("GUI file sel: %s" % name)
                        self._gui_render(eventtime)
                        self._gui_run_action("M300 S600 P12"
                                             if self.gui_beep else None)
                        return
        for (x, y, name, action, dim) in self._gui_rail():
            if x - 4 <= sx < x + 28 and y - 4 <= sy < y + 28:
                if action and not dim:
                    self._gui_do(action, eventtime)
                return
        for (x, y, w, h, idx, item) in self._gui_buttons():
            if item is None:
                continue
            if x <= sx < x + w and y <= sy < y + h:
                label, icon, action = item
                self.gcode.respond_info("GUI: %s" % label)
                self._gui_do(action, eventtime)
                return
    # --- helpers ---
    def _wcmd(self, v):
        self.cmd_cmd.send([v & 0xFF])
    def _wdata(self, v):
        self.cmd_data.send([v & 0xFFFF])
    def _cover_cell(self, col, row):
        self.cmd_rect.send([col * self.cell_w, row * self.cell_h,
                            self.cell_w, self.cell_h, self.bg])
    def _draw_cell(self, col, row, ch):
        self._cover_cell(col, row)
        fg = self.fg
        if self.row_colors:
            fg = self.row_colors[row % len(self.row_colors)]
        x = col * self.cell_w + max(0, (self.cell_w - 8 * self.scale) // 2)
        y = row * self.cell_h + self.vpad
        self.cmd_char.send([x, y, self.scale, ch, fg, self.bg])


def load_config(config):
    return ST7796(config)
